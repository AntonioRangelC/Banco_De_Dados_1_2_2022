-- ---------- << TF - Tema 1 - Clinica de Terapia >> ----------
--
--                    SCRIPT DE CONTROLE
--
-- Data Criacao ...........: 12/09/2022
-- Autor(es) ..............: Gabriel Mariano da Silva, Cibele Freitas Goudinho, Daniel Barcelos Moreira e Artur Seppa Reiman
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1A_danielmoreira
--
-- Ultimas Alteracoes
--   18/09/2022 => Alterando o nome da base de dados
--              => Adicionando novas tabelas criadas no projeto para cada ROLE
--              => Retirando tabelas removidas do projeto
--              => Criando usuários (6 ao todo)
--              => Adicionando ROLEs para cada usuario (2 usuarios por ROLE)
--              => Alterando contagem de tabelas do cabecalho do script
--
-- PROJETO => 01 Base de Dados
--         => 23 Tabelas
--         => 03 Roles
--         => 06 Usuarios
--
-- ---------------------------------------------------------

-- BASE DE DADOS

USE TF_1A_danielmoreira;

-- ========== << PERFIS >> ==========

-- PERFIL: ADMIN

CREATE ROLE ADMIN;

GRANT ALL PRIVILEGES ON 
	TF_1A_danielmoreira TO ADMIN;

-- PERFIL: TERAPEUTA

CREATE ROLE TERAPEUTA;

GRANT INSERT, DELETE, UPDATE, SELECT ON 
	PESSOA to TERAPEUTA;
    
GRANT INSERT, DELETE, UPDATE, SELECT ON 
	ENDERECO to TERAPEUTA;
    
GRANT INSERT, DELETE, UPDATE, SELECT ON 
	PACIENTE to TERAPEUTA;
    
GRANT INSERT, DELETE, UPDATE, SELECT ON 
	CONSULTA to TERAPEUTA;

GRANT INSERT, DELETE, UPDATE, SELECT ON 
	queixa to TERAPEUTA;
    
GRANT INSERT, DELETE, UPDATE, SELECT ON 
	TESTE to TERAPEUTA;
    
GRANT INSERT, DELETE, UPDATE, SELECT ON 
	PROTOCOLO to TERAPEUTA;

GRANT INSERT, DELETE, UPDATE, SELECT ON 
	RECEITA to TERAPEUTA;
    
GRANT INSERT, DELETE, UPDATE, SELECT ON 
	FARMACO to TERAPEUTA;
    
GRANT INSERT, DELETE, UPDATE, SELECT ON 
	detem to TERAPEUTA;

GRANT INSERT, DELETE, UPDATE, SELECT ON 
	agrega to TERAPEUTA;

GRANT INSERT, DELETE, UPDATE, SELECT ON 
	PRODUTO to TERAPEUTA;

GRANT INSERT, DELETE, UPDATE, SELECT ON 
	tem to TERAPEUTA;

GRANT INSERT, DELETE, UPDATE, SELECT ON 
	VENDA to TERAPEUTA;

GRANT INSERT, DELETE, UPDATE, SELECT ON 
	SESSAO to TERAPEUTA;

GRANT INSERT, DELETE, UPDATE, SELECT ON 
	TRATAMENTO to TERAPEUTA;
    
-- PERFIL: PALESTRANTE

CREATE ROLE PALESTRANTE;

GRANT INSERT, DELETE, UPDATE, SELECT ON 
	PESSOA to PALESTRANTE;
    
GRANT INSERT, DELETE, UPDATE, SELECT ON 
	PALESTRANTE to PALESTRANTE;
    
GRANT INSERT, DELETE, UPDATE, SELECT ON 
	ESTUDO to PALESTRANTE;
    
GRANT INSERT, DELETE, UPDATE, SELECT ON 
	CERTIFICADO to PALESTRANTE;
    
GRANT INSERT, DELETE, UPDATE, SELECT ON 
	da to PALESTRANTE;
    
GRANT INSERT, DELETE, UPDATE, SELECT ON 
	CURSO to PALESTRANTE;
    
GRANT INSERT, DELETE, UPDATE, SELECT ON 
	AULA to PALESTRANTE;

GRANT INSERT, DELETE, UPDATE, SELECT ON 
	ENDERECO to PALESTRANTE;
    
GRANT INSERT, DELETE, UPDATE, SELECT ON 
	DIPLOMA to PALESTRANTE;
    
-- ========== << USUARIOS >> ==========

-- Usuarios com ROLE ADMIN

CREATE USER 'databaseAdmin'
	IDENTIFIED BY 'Dba@1234';
    
GRANT ADMIN 
	TO 'databaseAdmin';

CREATE USER 'programador'
	IDENTIFIED BY 'Developer*123';
    
GRANT ADMIN 
	TO 'programador';

-- Usuarios com ROLE TERAPEUTA

CREATE USER 'AntoniaGoudinho'
	IDENTIFIED BY 'Antonia123*';
    
GRANT TERAPEUTA 
	TO 'AntoniaGoudinho';

CREATE USER 'FuncionariaTerapeuta'
	IDENTIFIED BY 'Terapeuta321*';
    
GRANT TERAPEUTA 
	TO 'FuncionariaTerapeuta';

-- Usuarios com ROLE PALESTRANTE
    
CREATE USER 'DraAntonia'
	IDENTIFIED BY 'DraAntonia123*';
    
GRANT PALESTRANTE
	TO 'DraAntonia';
    
CREATE USER 'PalestranteConvidado'
	IDENTIFIED BY 'Palestrante321*';
    
GRANT PALESTRANTE 
	TO 'PalestranteConvidado';
    
