-- ---------- << TF - Tema 1 - Clínica de Terapia >> ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 30/08/2022
-- Autor(es) ..............: Gabriel Mariano da Silva, Cibele Freitas Goudinho, Daniel Barcelos Moreira e Artur Seppa Reiman
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1A_danielmoreira
--
-- Ultimas Alteracoes
--   11/09/2022 => Alterando tabelas para atualização do projeto conforme a documentacao
--              => Adicionando Unique Keys as tabelas
--              => Alterando nome da base de dados
--              => Adicionando restricoes para as FKs
--
--   19/09/2022 => Alterando tabela PALESTRANTE
--              => Adicionando tabela DIPLOMA
--              => Adicionando atributo valorCurso na tabela CURSO
--              => Excluindo tabela cursa
--              => Alterando nome da tabela RELATORIO para PROTOCOLO
--              => Excluindo atributo posologia da tabela RECEITA
--              => Alterando atributos da tabela FARMACO
--              => Adicionando tabela ESTUDO
--              => Adicionando tabela CERTIFICADO
--              => Adicionando tabela detem
--              => Alterando o nome da base de dados e a quantidade de tabelas
--
-- PROJETO => 01 Base de Dados
--         => 23 Tabelas
--         => 03 Roles
--         => 06 Usuarios
--
-- ---------------------------------------------------------

-- DATABASE
CREATE DATABASE
	IF NOT EXISTS TF_1A_danielmoreira;
    
USE TF_1A_danielmoreira;

-- TABLES
CREATE TABLE ENDERECO(
	cep				INT(8)		NOT NULL,
    rua				VARCHAR(30) NOT NULL,
    numero			INT 		NOT NULL,
    cidade			VARCHAR(30) NOT NULL,
    complemento		VARCHAR(50) NOT NULL,
    CONSTRAINT ENDERECO_PK PRIMARY KEY (cep, rua, numero)
) ENGINE = InnoDB;

CREATE TABLE PESSOA(
	documento	    BIGINT(11)	                  NOT NULL,
    tipoDocumento   ENUM('CPF', 'RG')             NOT NULL, 
    nome		    VARCHAR(45)                   NOT NULL,
    dtNasc		    DATE                  		  NOT NULL,
    sexo		    ENUM('M', 'F')                NOT NULL,
    telefone	    BIGINT(12)	                  NOT NULL,
    email		    VARCHAR(45)                   NOT NULL,
    profissao	    VARCHAR(30)                   NOT NULL,
    tipoPessoa	    ENUM('PCT', 'PLT', 'PCT_PLT') NOT NULL,
    cep			    INT(8)		                  NOT NULL,
    rua			    VARCHAR(30)                   NOT NULL,
    numero		    INT			                  NOT NULL,
    CONSTRAINT PESSOA_PK PRIMARY KEY (documento, tipoDocumento),
    CONSTRAINT PESSOA_ENDERECO_FK FOREIGN KEY (cep, rua, numero)
    REFERENCES ENDERECO (cep, rua, numero) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT PESSOA_nome_dtNasc_sexo_UK UNIQUE KEY (nome, dtNasc, sexo)
) ENGINE = InnoDB;

CREATE TABLE PALESTRANTE(
    idPalestrante         INT         		NOT NULL  AUTO_INCREMENT,
    documento	          BIGINT(11)        NOT NULL,
    tipoDocumento         ENUM('CPF', 'RG') NOT NULL, 
    CONSTRAINT PALESTRANTE_PK PRIMARY KEY (idPalestrante),
    CONSTRAINT PALESTRANTE_PESSOA_FK FOREIGN KEY (documento, tipoDocumento)
    REFERENCES PESSOA (documento, tipoDocumento) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT PALESTRANTE_documento_tipoDocumento_UK 
    UNIQUE KEY (documento, tipoDocumento)
) ENGINE = InnoDB  AUTO_INCREMENT = 1;

CREATE TABLE DIPLOMA(
	idPalestrante         INT         		NOT NULL,
    dataConclusao         DATE         		NOT NULL,
    descDiploma			  VARCHAR(100)      NOT NULL,
    nomeDiploma		  	  VARCHAR(50)       NOT NULL,
    CONSTRAINT DIPLOMA_PALESTRANTE_FK FOREIGN KEY (idPalestrante)
    REFERENCES PALESTRANTE (idPalestrante) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT DIPLOMA_nomeDiploma_idPalestrante_UK UNIQUE KEY (nomeDiploma, idPalestrante)
) ENGINE = InnoDB;

CREATE TABLE CURSO(
    nomeCurso      VARCHAR(30) 	NOT NULL,
    dtInicioCurso  DATE		   	NOT NULL,
    conteudoCurso  VARCHAR(30) 	NOT NULL,
    cargaHoraria   INT(2)	   	NOT NULL,
    valorCurso	   DECIMAL(7,2)	NOT NULL,
    CONSTRAINT CURSO_PK PRIMARY KEY (nomeCurso, dtInicioCurso)
) ENGINE = InnoDB;

CREATE TABLE da(
	idPalestrante  INT         NOT NULL,
    nomeCurso      VARCHAR(30) NOT NULL,
    dtInicioCurso  DATE		   NOT NULL,
    CONSTRAINT da_PALESTRANTE_FK FOREIGN KEY (idPalestrante) 
    REFERENCES PALESTRANTE (idPalestrante) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT da_CURSO_FK FOREIGN KEY (nomeCurso, dtInicioCurso)
    REFERENCES CURSO (nomeCurso, dtInicioCurso) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT da_idPalestrante_nomeCurso_UK UNIQUE KEY (idPalestrante, nomeCurso)
) ENGINE = InnoDB;

CREATE TABLE AULA(
	conteudoAula  VARCHAR(30) NOT NULL,
	dtAula		  DATE		  NOT NULL,
    horarioAula	  TIME		  NOT NULL,
    duracaoAula   INT(2)	  NOT NULL,
    cep			  INT(8)	  NOT NULL,
    rua		      VARCHAR(30) NOT NULL,
    numero		  INT		  NOT NULL,
    nomeCurso     VARCHAR(30) NOT NULL,
    dtInicioCurso DATE		  NOT NULL,
    CONSTRAINT AULA_PK PRIMARY KEY (dtAula, horarioAula, conteudoAula),
    CONSTRAINT AULA_ENDERECO_FK	FOREIGN KEY (cep, rua, numero) 
    REFERENCES ENDERECO (cep, rua, numero) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT AULA_CURSO_FK	FOREIGN KEY (nomeCurso, dtInicioCurso) 
    REFERENCES CURSO (nomeCurso, dtInicioCurso) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE = InnoDB;

CREATE TABLE PACIENTE(
	idPaciente		INT                       NOT NULL   AUTO_INCREMENT,
    tpSanguineo		ENUM('A', 'B', 'AB', 'O') NOT NULL,
    fatorRh			ENUM('+', '-')            NOT NULL,
    estadoCivil		VARCHAR(12) 	          NOT NULL,
    documento	    BIGINT(11)	              NOT NULL,
    tipoDocumento   ENUM('CPF', 'RG')         NOT NULL,
    CONSTRAINT PACIENTE_PK PRIMARY KEY (idPaciente),
    CONSTRAINT PACIENTE_PESSOA_FK FOREIGN KEY (documento, tipoDocumento)
    REFERENCES PESSOA (documento, tipoDocumento) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT PACIENTE_documento_tipoDocumento_UK UNIQUE KEY (documento, tipoDocumento)
) ENGINE = InnoDB  AUTO_INCREMENT = 1;

CREATE TABLE CONSULTA(
	idConsulta		INT   		NOT NULL  AUTO_INCREMENT,
    dtConsulta		DATE  		NOT NULL,
    horaConsulta	TIME  		NOT NULL,
    idPaciente		INT			NOT NULL,
    cep				INT(8)		NOT NULL,
    rua				VARCHAR(30) NOT NULL,
    numero			INT			NOT NULL,
    CONSTRAINT CONSULTA_PK PRIMARY KEY (idConsulta),
    CONSTRAINT CONSULTA_ENDERECO_FK FOREIGN KEY (cep, rua, numero)
    REFERENCES ENDERECO (cep, rua, numero) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT CONSULTA_PACIENTE_FK FOREIGN KEY (idPaciente)
    REFERENCES PACIENTE (idPaciente) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT CONSULTA_dtConsulta_horaConsulta_idPaciente_UK UNIQUE KEY (dtConsulta, horaConsulta, idPaciente)
) ENGINE = InnoDB  AUTO_INCREMENT = 1;

CREATE TABLE queixa(
	queixa			VARCHAR(100)	NOT NULL,
    idConsulta		INT				NOT NULL,
    CONSTRAINT queixa_CONSULTA_FK FOREIGN KEY (idConsulta)
    REFERENCES CONSULTA (idConsulta) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT queixa_queixa_idConsulta_UK UNIQUE KEY (queixa, idConsulta)
) ENGINE = InnoDB;

CREATE TABLE TESTE(
	idTeste		INT		    NOT NULL	AUTO_INCREMENT,
    nomeTeste	VARCHAR(60)	NOT NULL,
    resultado	VARCHAR(75) NOT NULL,
    idConsulta	INT	    	NOT NULL,
    CONSTRAINT TESTE_PK PRIMARY KEY (idTeste),
    CONSTRAINT TESTE_CONSULTA_FK FOREIGN KEY (idConsulta)
    REFERENCES CONSULTA (idConsulta) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT TESTE_nomeTeste_idConsulta_UK UNIQUE KEY (nomeTeste, idConsulta)
) ENGINE = InnoDB  AUTO_INCREMENT = 1;

CREATE TABLE PROTOCOLO(
	idProtocolo	    INT		     NOT NULL	AUTO_INCREMENT,
    dtEmissao		DATE	     NOT NULL,
    orientacao		VARCHAR(500) NOT NULL,
    idConsulta		INT		     NOT NULL,
    CONSTRAINT PROTOCOLO_PK PRIMARY KEY (idProtocolo),
    CONSTRAINT PROTOCOLO_CONSULTA_FK FOREIGN KEY (idConsulta) 
    REFERENCES CONSULTA (idConsulta) ON UPDATE CASCADE
) ENGINE = InnoDB  AUTO_INCREMENT = 1;

CREATE TABLE RECEITA(
	idReceita       INT		     NOT NULL	AUTO_INCREMENT,
    dtEmissao		DATE	     NOT NULL,
    idProtocolo	    INT		     NOT NULL,
    CONSTRAINT RECEITA_PK PRIMARY KEY (idReceita),
    CONSTRAINT RECEITA_PROTOCOLO_FK FOREIGN KEY (idProtocolo)
    REFERENCES PROTOCOLO (idProtocolo) ON UPDATE CASCADE
) ENGINE = InnoDB	AUTO_INCREMENT = 1;

CREATE TABLE FARMACO(
	nomeFarmaco	   VARCHAR(40)  NOT NULL,
    volumeFarmaco  INT		    NOT NULL,
    formatoFarmaco VARCHAR(30)  NOT NULL,
	CONSTRAINT FARMACO_PK PRIMARY KEY (nomeFarmaco, volumeFarmaco)
) ENGINE = InnoDB;

CREATE TABLE TRATAMENTO(
	nomeTratamento    VARCHAR(35)	NOT NULL,
    precoTratamento   DECIMAL(7,2)	NOT NULL,
    CONSTRAINT TRATAMENTO_PK PRIMARY KEY (nomeTratamento)
) ENGINE = InnoDB;

CREATE TABLE VENDA(
	idVenda			INT		       NOT NULL  AUTO_INCREMENT,
    dtVenda			DATE	       NOT NULL,
    tipoPagamento   VARCHAR(35)    NOT NULL,
    nomeComprador	VARCHAR(35),
    valorVenda	    DECIMAL(7,2)   NOT NULL,
    CONSTRAINT VENDA_PK PRIMARY KEY (idVenda)
) ENGINE = InnoDB  AUTO_INCREMENT = 1;

CREATE TABLE SESSAO(
	numeroSessao	INT            NOT NULL    AUTO_INCREMENT,
    dtInicio	    DATE           NOT NULL,
    horaInicio	    TIME           NOT NULL,
    duracaoTotal	INT(2)	       NOT NULL,
    valorSessao	    DECIMAL(7,2)   NOT NULL,
    nomeTratamento  VARCHAR(35)    NOT NULL,
    idProtocolo	    INT            NOT NULL,
    idVenda	        INT            NOT NULL,
    cep				INT(8)         NOT NULL,
    numero			INT            NOT NULL,
    rua				VARCHAR(30)    NOT NULL,
    CONSTRAINT SESSAO_PK PRIMARY KEY (numeroSessao),
    CONSTRAINT SESSAO_TRATAMENTO_FK FOREIGN KEY (nomeTratamento)
    REFERENCES TRATAMENTO (nomeTratamento) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT SESSAO_PROTOCOLO_FK FOREIGN KEY (idProtocolo)
    REFERENCES PROTOCOLO (idProtocolo) ON UPDATE CASCADE,
    CONSTRAINT SESSAO_VENDA_FK FOREIGN KEY (idVenda)
    REFERENCES VENDA (idVenda) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT SESSAO_ENDERECO_FK FOREIGN KEY (cep, rua, numero) 
    REFERENCES ENDERECO (cep, rua, numero) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT SESSAO_dtInicio_horaInicio_nomeTratamento_idProtocolo_UK 
    UNIQUE KEY (dtInicio, horaInicio, nomeTratamento, idProtocolo)
) ENGINE = InnoDB  AUTO_INCREMENT = 1;

CREATE TABLE PRODUTO(
	nomeMed      VARCHAR(30)       NOT NULL,
	volumeMed    INT    	  	   NOT NULL,
    formatoMed   VARCHAR(30)       NOT NULL,
    descricao	 VARCHAR(50)	   NOT NULL,
    precoCusto   DECIMAL(6,2)      NOT NULL,
    precoVenda   DECIMAL(6,2)      NOT NULL,
    qtdEstoque   INT               NOT NULL,
    CONSTRAINT PRODUTO_PK PRIMARY KEY (nomeMed, volumeMed, formatoMed)
) ENGINE = InnoDB;

CREATE TABLE agrega(
    posologiaProduto  VARCHAR(75)       NOT NULL,
	idReceita         INT		        NOT NULL,
    nomeMed           VARCHAR(30)       NOT NULL,
	volumeMed         INT    	  	    NOT NULL,
    formatoMed        VARCHAR(30)       NOT NULL,
    CONSTRAINT agrega_RECEITA_FK FOREIGN KEY (idReceita)
    REFERENCES RECEITA (idReceita) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT agrega_PRODUTO_FK FOREIGN KEY (nomeMed, volumeMed, formatoMed)
    REFERENCES PRODUTO (nomeMed, volumeMed, formatoMed) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT agrega_idReceita_nomeMed_volumeMed_formatoMed_UK UNIQUE KEY (idReceita, nomeMed, volumeMed, formatoMed)
) ENGINE = InnoDB;


CREATE TABLE tem(
    qtdVendida	    INT           NOT NULL,
    valorSubtotal	DECIMAL(7,2)  NOT NULL,
	idVenda			INT           NOT NULL,
    nomeMed         VARCHAR(30)   NOT NULL,
	volumeMed       INT    	  	  NOT NULL,
    formatoMed      VARCHAR(30)   NOT NULL,
    CONSTRAINT tem_VENDA_FK FOREIGN KEY (idVenda)
    REFERENCES VENDA (idVenda) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT tem_PRODUTO_FK FOREIGN KEY (nomeMed, volumeMed, formatoMed)
    REFERENCES PRODUTO (nomeMed, volumeMed, formatoMed) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT tem_idVenda_nomeMed_volumeMed_formatoMed_UK UNIQUE KEY (idVenda, nomeMed, volumeMed, formatoMed)
) ENGINE = InnoDB;

CREATE TABLE ESTUDO(
	idEstudo	   int				   NOT NULL		AUTO_INCREMENT,
	documento	   BIGINT(11)	       NOT NULL,
    tipoDocumento  ENUM('CPF', 'RG')   NOT NULL,
    nomeCurso      VARCHAR(30)         NOT NULL,
    dtInicioCurso  DATE		           NOT NULL,
	CONSTRAINT ESTUDO_PK PRIMARY KEY (idEstudo),
    CONSTRAINT ESTUDO_PESSOA_FK FOREIGN KEY (documento, tipoDocumento) 
    REFERENCES PESSOA (documento, tipoDocumento) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT ESTUDO_CURSO_FK FOREIGN KEY (nomeCurso, dtInicioCurso)
    REFERENCES CURSO (nomeCurso, dtInicioCurso) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT ESTUDO_documento_nomeCurso_UK UNIQUE KEY (documento, nomeCurso)
) ENGINE = InnoDB;

CREATE TABLE CERTIFICADO(
	descCertificado	   VARCHAR(100)	NOT NULL,
	dataConclusao	   DATE	       	NOT NULL,
    cargaHoraria  	   INT(2)      	NOT NULL,
    nomeCertificado    VARCHAR(40)  NOT NULL,
    idEstudo  		   INT		    NOT NULL,
    CONSTRAINT CERTIFICADO_ESTUDO_FK FOREIGN KEY (idEstudo) 
    REFERENCES ESTUDO (idEstudo) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT CERTIFICADO_nomeCertificado_idEstudo_UK UNIQUE KEY (nomeCertificado, idEstudo)
) ENGINE = InnoDB;

CREATE TABLE detem(
	posologia	   VARCHAR(100)		NOT NULL,
	idReceita	   INT	       		NOT NULL,
    nomeFarmaco	   VARCHAR(40)    	NOT NULL,
    volumeFarmaco  INT  			NOT NULL,
    CONSTRAINT detem_RECEITA_FK FOREIGN KEY (idReceita) 
    REFERENCES RECEITA (idReceita) ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT detem_FARMACO_FK FOREIGN KEY (nomeFarmaco, volumeFarmaco) 
    REFERENCES FARMACO (nomeFarmaco, volumeFarmaco) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT detem_idReceita_nomeFarmaco_volumeFarmaco_UK UNIQUE KEY (idReceita, nomeFarmaco, volumeFarmaco)
) ENGINE = InnoDB;