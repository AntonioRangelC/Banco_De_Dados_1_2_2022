-- ---------- << TF - Tema 1 - Clínica de Terapia >> ----------
--
--                    SCRIPT DE POPULACAO
--
-- Data Criacao ...........: 31/08/2022
-- Autor(es) ..............: Gabriel Mariano da Silva, Cibele Freitas Goudinho, Daniel Barcelos Moreira e Artur Seppa Reiman
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1A_danielmoreira
--
-- Ultimas Alteracoes
--   11/09/2022 => Alterando tabelas para atualização do projeto conforme a documentacao
--              => Alterando nome da base de dados
--              => Adicionando dados conforme os novos atributos das tabelas
--
--   19/09/2022 => Alterando tuplas da tabela PALESTRANTE
--              => Adicionando tuplas na tabela DIPLOMA
--              => Adicionando tuplas na tabela ESTUDO
--              => Adicionando tuplas na tabela CERTIFICADO
--              => Adicionando tuplas tabela detem
--              => Alterando o nome da base de dados e a quantidade de tabelas
--              => Alterando tabelas para atualização do projeto conforme a documentacao
--               
-- PROJETO => 01 Base de Dados
--         => 23 Tabelas
--         => 03 Roles
--         => 06 Usuarios
--
-- ---------------------------------------------------------
-- BASE DE DADOS

USE TF_1A_danielmoreira;

-- POPULANDO

INSERT INTO ENDERECO (cep, rua, numero, cidade, complemento) VALUES
	(73100020, 'Rua dos Cristais', 123, 'Brasília', 'Próximo ao Posto'),
    (73031673, 'Rua das Laranjeiras', 321, 'Brasília', 'Proximo ao Correio'),
    (72005103, 'Rua das Macieiras', 456, 'Brasília', 'Próximo ao Clube'),
    (70636240, 'Rua das Mangueiras', 654, 'Brasília', 'Próximo a Praça'),
    (72460240, 'Rua das Videiras', 789, 'Gama', 'Próximo ao Mercado'),
	(73100010, 'Rua dos Cristais', 573, 'Brasília', 'Próximo ao Posto'),
    (73031643, 'Rua das Laranjeiras', 920, 'Brasília', 'Proximo ao Correio'),
    (72005113, 'Rua das Macieiras', 459, 'Brasília', 'Próximo ao Clube'),
    (70636270, 'Rua das Mangueiras', 674, 'Brasília', 'Próximo a Praça'),
    (72460290, 'Rua das Videiras', 189, 'Gama', 'Próximo ao Mercado');
    
INSERT INTO PESSOA (documento, tipoDocumento, nome, dtNasc, sexo, telefone, email, profissao, tipoPessoa, cep, rua, numero) VALUES
	(4683512, 'RG', 'Manuel Mayer', '1980-01-03', 'M', 61995625267, 'manuel@email.com', 'Terapeuta', 'PCT_PLT', 72005103, 'Rua das Macieiras', 456),
    (4654654, 'RG', 'Felipe Senna', '1985-03-14', 'M', 61946845349, 'felipe@email.com', 'Medico', 'PCT_PLT', 72005103, 'Rua das Macieiras', 456),
    (8645321, 'RG', 'Maria Mattar', '1970-05-12', 'F', 61946546489, 'maria_m@email.com', 'Professor', 'PCT_PLT', 70636240, 'Rua das Mangueiras', 654),
    (1564487, 'RG', 'Fernando Mar', '1995-07-10', 'M', 61912368468, 'fernando@email.com', 'Atleta', 'PCT_PLT', 70636240, 'Rua das Mangueiras', 654),
    (4689628, 'RG', 'Arturo Vidal', '1976-10-08', 'M', 61998754396, 'arturo@email.com', 'Ator', 'PCT_PLT', 72460240, 'Rua das Videiras', 789),
    (9987546, 'RG', 'Fernando Fernandes', '1976-06-04', 'M', 6192468759, 'arturo@email.com', 'Padre', 'PCT', 73100020, 'Rua dos Cristais', 123),
    (5642182, 'RG', 'Luís Hamilton', '1996-07-08', 'M', 61993728426, 'luis@email.com', 'Terapeuta', 'PCT', 73031673, 'Rua das Laranjeiras', 321),
    (3546566, 'RG', 'Jorge Russo', '1999-10-23', 'M', 61967283495, 'jorge@email.com', 'Fisioterapeuta', 'PCT', 73100020, 'Rua dos Cristais', 123),
    (7564189, 'RG', 'Valter Barcelos', '1995-04-08', 'M', 61985628165, 'valter@email.com', 'Terapeuta', 'PCT', 72460240, 'Rua das Videiras', 789),
    (6574846, 'RG', 'Carlos Sainz', '1978-01-01', 'M', 61985376125, 'carlos@email.com', 'Terapeuta', 'PCT', 73031673, 'Rua das Laranjeiras', 321),
	(1187546, 'RG', 'Ana Fernandes', '1976-01-05', 'F', 6192468891, 'anafernandes@email.com', 'Medica', 'PCT_PLT', 73100010, 'Rua dos Cristais', 573),
    (2242182, 'RG', 'Carolina Batista', '1986-06-06', 'F', 61993729240, 'carolbatista@email.com', 'Terapeuta', 'PCT_PLT', 73031643, 'Rua das Laranjeiras', 920),
    (3346566, 'RG', 'Gabriel Dornelas', '1999-05-20', 'M', 61967285671, 'gabriel@email.com', 'Fisioterapeuta', 'PCT_PLT', 72005113, 'Rua das Macieiras', 459),
    (4964189, 'RG', 'Thais Nunes', '1993-06-03', 'F', 61985629327, 'thais@email.com', 'Terapeuta', 'PCT_PLT', 70636270, 'Rua das Mangueiras', 674),
    (5174846, 'RG', 'Rafael Carvalho', '1979-03-03', 'M', 61985376555, 'rafaelcarvalho@email.com', 'Terapeuta', 'PCT_PLT', 72460290, 'Rua das Videiras', 189);
    
INSERT INTO PALESTRANTE	(documento, tipoDocumento) VALUES
	(4683512, 'RG'),
    (4654654, 'RG'),
    (8645321, 'RG'),
    (1564487, 'RG'),
    (4689628, 'RG'),
	(1187546, 'RG'),
    (2242182, 'RG'),
    (3346566, 'RG'),
    (4964189, 'RG'),
    (5174846, 'RG');
    
INSERT INTO DIPLOMA (idPalestrante, dataConclusao, descDiploma, nomeDiploma) VALUES
	(1, '2022-10-10', 'Formação em Fisioterapia', 'Fisioterapia'),
    (2, '2023-05-06', 'Formação em Medicina', 'Medicina'),
    (3, '2023-12-12', 'Formação em Farmácia', 'Farmácia'),
    (4, '2024-05-10', 'Bacharelado em Química', 'Química'),
    (5, '2024-07-06', 'Formação em Farmácia', 'Farmácia'),
    (6, '2023-09-02', 'Bacharelado em Química', 'Química'),
    (7, '2024-03-05', 'Formação em Farmácia', 'Farmácia'),
    (8, '2024-04-08', 'Bacharelado em Química', 'Química'),
    (9, '2024-07-02', 'Formação em Medicina', 'Medicina'),
    (10, '2024-02-02', 'Bacharelado em Química', 'Química');
    
INSERT INTO CURSO (nomeCurso, dtInicioCurso, conteudoCurso, cargaHoraria, valorCurso) VALUES
	('Fenômenos Psicológicos', '2022-05-01', 'Fenômenos da Mente', 4, 500.0),
    ('Benefícios da Proteína', '2022-05-10', 'Benefícios Proteicos', 2, 400.0),
    ('Pedagogia do Oprimido', '2022-06-05', 'Livro de Paulo Freire', 8, 300.0),
    ('Futebol no Primário', '2022-06-23', 'Ensino Primário', 2, 250.0),
    ('Psicologia Cênica', '2022-08-09', 'Princípios da arte', 4, 450.0),
	('Introdução a Psicologia', '2022-10-01', 'Conceitos da psicologia', 4, 500.0),
    ('Benefícios dos Florais', '2022-11-10', 'Florais quanticos', 2, 400.0),
    ('O que é o autocuidado', '2022-12-05', 'Como ter autocuidado', 8, 300.0),
    ('Infância Saudável', '2023-09-23', 'Hábitos na infância', 2, 250.0),
    ('Estudo da mente', '2023-08-09', 'Mente de um humano', 4, 450.0);

INSERT INTO da (idPalestrante, nomeCurso, dtInicioCurso) VALUES
	(1, 'Fenômenos Psicológicos', '2022-05-01'),
    (2, 'Benefícios da Proteína', '2022-05-10'),
    (3, 'Pedagogia do Oprimido', '2022-06-05'),
    (4, 'Futebol no Primário', '2022-06-23'),
    (5, 'Psicologia Cênica', '2022-08-09'),
	(6, 'Introdução a Psicologia', '2022-10-01'),
    (7, 'Benefícios dos Florais', '2022-11-10'),
    (8, 'O que é o autocuidado', '2022-12-05'),
    (9, 'Infância Saudável', '2023-09-23'),
    (10, 'Estudo da mente', '2023-08-09');
    
INSERT INTO AULA (conteudoAula, dtAula, horarioAula, duracaoAula, cep, rua, numero, nomeCurso, dtInicioCurso) VALUES
	('Análise de Fenômenos', '2022-05-01', '14:00', 4, 73100020, 'Rua dos Cristais', 123, 'Fenômenos Psicológicos', '2022-05-01'),
    ('Whey Protein', '2022-05-10', '16:00', 2, 73031673, 'Rua das Laranjeiras', 321, 'Benefícios da Proteína', '2022-05-10'),
    ('Leitura Conjunta', '2022-06-05', '08:00', 8, 72005103, 'Rua das Macieiras', 456, 'Pedagogia do Oprimido', '2022-06-05'),
    ('Benefícios do Futebol', '2022-06-23', '14:00', 2, 70636240, 'Rua das Mangueiras', 654, 'Futebol no Primário', '2022-06-23'),
    ('A décima arte', '2022-08-09', '14:00', 4, 72460240, 'Rua das Videiras', 789, 'Psicologia Cênica', '2022-08-09'),
	('Conceitos da Psicologia', '2022-10-01', '14:00', 4, 73100020, 'Rua dos Cristais', 123, 'Introdução a Psicologia', '2022-10-01'),
    ('O que são os florais', '2022-11-10', '16:00', 2, 73031673, 'Rua das Laranjeiras', 321, 'Benefícios dos Florais', '2022-11-10'),
    ('Iniciando uma autoreflexão', '2022-12-05', '08:00', 8, 72005103, 'Rua das Macieiras', 456, 'O que é o autocuidado', '2022-12-05'),
    ('O EU do passado', '2023-09-23', '14:00', 2, 70636240, 'Rua das Mangueiras', 654, 'Infância Saudável', '2023-09-23'),
    ('Reflita e analise', '2023-08-09', '14:00', 4, 72460240, 'Rua das Videiras', 789, 'Estudo da mente', '2023-08-09');
    
INSERT INTO PACIENTE (tpSanguineo, fatorRh, estadoCivil, documento, tipoDocumento) VALUES
	('A', '-', 'Solteiro', 9987546, 'RG'),
    ('B', '+', 'Casado', 5642182, 'RG'),
    ('AB', '-', 'Solteiro', 3546566, 'RG'),
    ('O', '-', 'Casado', 7564189, 'RG'),
    ('A', '-', 'Solteiro', 6574846, 'RG'),
	('B', '-', 'Solteiro', 1187546, 'RG'),
    ('A', '+', 'Casado', 2242182, 'RG'),
    ('AB', '-', 'Solteiro', 3346566, 'RG'),
    ('O', '-', 'Casado', 4964189, 'RG'),
    ('A', '-', 'Solteiro', 5174846, 'RG');

INSERT INTO CONSULTA (dtConsulta, horaConsulta, idPaciente, cep, rua, numero) VALUES
	('2022-04-05', '16:00', 1, 73100020, 'Rua dos Cristais', 123),
    ('2022-05-10', '18:00', 2, 73100020, 'Rua dos Cristais', 123),
    ('2022-06-12', '10:00', 3, 73100020, 'Rua dos Cristais', 123),
    ('2022-07-07', '09:00', 4, 73100020, 'Rua dos Cristais', 123),
    ('2022-08-01', '08:00', 5, 73100020, 'Rua dos Cristais', 123),
	('2023-04-05', '16:00', 6, 73100020, 'Rua dos Cristais', 123),
    ('2023-05-10', '18:00', 7, 73100020, 'Rua dos Cristais', 123),
    ('2023-06-12', '10:00', 8, 73100020, 'Rua dos Cristais', 123),
    ('2023-07-07', '09:00', 9, 73100020, 'Rua dos Cristais', 123),
    ('2023-08-01', '08:00', 10, 73100020, 'Rua dos Cristais', 123);

INSERT INTO queixa (queixa, idConsulta) VALUES
	('Dor nas Costas', 1),
    ('Enxaqueca', 2),
    ('Fraqueza', 3),
    ('Sonolência', 4),
    ('Dor nas Pernas', 5),
	('Dor nas Costas', 6),
    ('Enxaqueca', 7),
    ('Fraqueza', 8),
    ('Sonolência', 9),
    ('Dor nas Pernas', 10);
    
INSERT INTO TESTE (nomeTeste, resultado, idConsulta) VALUES
	('Contaminação por Mercúrio', 'positivo', 1),
    ('Contaminação por Cobre', 'negativo', 2),
    ('Contaminação por Alumínio', 'positivo', 3),
    ('Contaminação por Chumbo', 'negativo', 4),
    ('Contaminação por Agrotóxico', 'positivo', 5),
	('Contaminação por Mercúrio', 'positivo', 6),
    ('Contaminação por Cobre', 'negativo', 7),
    ('Contaminação por Alumínio', 'positivo', 8),
    ('Contaminação por Chumbo', 'negativo', 9),
    ('Contaminação por Agrotóxico', 'positivo', 10);    

INSERT INTO PROTOCOLO (dtEmissao, orientacao, idConsulta) VALUES
	('2022-04-05', 'Tomar medicação presente na receita', 1),
    ('2022-05-10', 'Repouso e ingestão de líquidos', 2),
    ('2022-06-12', 'Evitar alimentos não-orgânicos', 3),
    ('2022-07-07', 'Repouso e ingestão de líquidos', 4),
    ('2022-08-01', 'Lavar alimentos antes de comer e dar preferência a orgânicos', 5),
	('2023-04-05', 'Tomar medicação presente na receita', 6),
    ('2023-05-10', 'Repouso e ingestão de líquidos', 7),
    ('2023-06-12', 'Evitar alimentos não-orgânicos', 8),
    ('2023-07-07', 'Repouso e ingestão de líquidos', 9),
    ('2023-08-01', 'Lavar alimentos antes de comer e dar preferência a orgânicos', 10);

INSERT INTO RECEITA (dtEmissao, idProtocolo) VALUES
	('2022-04-05', 1),
    ('2022-05-10', 2),
    ('2022-06-12', 3),
    ('2022-07-07', 4),
    ('2022-08-01', 5),
	('2023-04-05', 6),
    ('2023-05-10', 7),
    ('2023-06-12', 8),
    ('2023-07-07', 9),
    ('2023-08-01', 10);

INSERT INTO FARMACO (nomeFarmaco, volumeFarmaco, formatoFarmaco) VALUES
	('Dorflex', 1, 'comprimido'),
    ('Soro caseiro', 300, 'ml'),
    ('Biotonico', 50, 'ml'),
    ('Cafeina em Capsulas', 4, 'capsulas'),
    ('Potassio em Capsulas', 5, 'capsulas'),
	('Polivitaminico', 2, 'capsulas'),
    ('Zinco em capsulas', 3, 'capsulas'),
    ('Ferro em capsulas', 4, 'capsulas'),
    ('Alivium', 1, 'comprimido'),
    ('Celestamine', 1, 'comprimido');

INSERT INTO TRATAMENTO (nomeTratamento, precoTratamento) VALUES
	('Terapia de Heiki', 250.0),
    ('Barra de Axis', 175.0),
    ('Terapia com Florais', 200.0),
    ('Terapia com Fármacos', 100.0),
    ('Terapia Quântica', 150.0),
	('Argiloterapia', 250.0),
    ('Reflexologia', 175.0),
    ('Escalda pés', 200.0),
    ('Gomagem', 100.0),
    ('Hidromassagem', 150.0);

INSERT INTO VENDA (dtVenda, tipoPagamento, nomeComprador, valorVenda) VALUES
	('2022-04-05', 'A vista', 'Gabriel', 250.0),
    ('2022-05-10', 'Parcelado', 'Mariano', 175.0),
    ('2022-06-12', 'PIX', 'Felipe', 200.0),
    ('2022-07-07', 'A vista', 'Luisa', 100.0),
    ('2022-08-01', 'PIX', 'Manuela', 150.0),
    ('2022-08-01', 'PIX', 'Luis', 73.0),
    ('2022-07-07', 'A vista', 'Cristiano', 47.0),
    ('2022-05-10', 'Parcelado', 'Marta', 47.0),
    ('2022-08-01', 'PIX', 'Jose', 69.0),
    ('2022-07-07', 'PIX', 'Carlos', 73.0),
	('2022-04-01', 'PIX', 'Ana', 73.0),
    ('2022-07-08', 'A vista', 'Carolina', 47.0),
    ('2022-05-03', 'Parcelado', 'Lucas', 47.0),
    ('2022-08-02', 'PIX', 'Bruno', 69.0),
    ('2022-07-05', 'PIX', 'Ricardo', 73.0),
	('2023-04-01', 'PIX', 'Luiza', 73.0),
    ('2023-07-08', 'A vista', 'Danilo', 47.0),
    ('2023-05-03', 'Parcelado', 'Tereza', 47.0),
    ('2023-08-02', 'PIX', 'Marcos', 69.0),
    ('2023-07-05', 'PIX', 'Matheus', 73.0);

INSERT INTO SESSAO (dtInicio, horaInicio, duracaoTotal, valorSessao, nomeTratamento, idProtocolo, idVenda, cep, rua, numero) VALUES
	('2022-04-05', '10:00', 2, 250.0, 'Terapia de Heiki', 1, 1, 73100020, 'Rua dos Cristais', 123),
    ('2022-05-10', '16:00', 2, 175.0, 'Barra de Axis', 2, 2, 73100020, 'Rua dos Cristais', 123),
    ('2022-06-12', '14:00', 2, 200.0, 'Terapia com Florais', 3, 3, 73100020, 'Rua dos Cristais', 123),
    ('2022-07-07', '18:00', 2, 100.0, 'Terapia com Fármacos', 4, 4, 73100020, 'Rua dos Cristais', 123),
    ('2022-08-01', '08:00', 2, 150.0, 'Terapia Quântica', 5, 5, 73100020, 'Rua dos Cristais', 123),
	('2022-08-01', '10:00', 2, 250.0, 'Argiloterapia', 6, 11, 73100020, 'Rua dos Cristais', 123),
    ('2022-07-07', '16:00', 2, 175.0, 'Reflexologia', 7, 12, 73100020, 'Rua dos Cristais', 123),
    ('2022-05-10', '14:00', 2, 200.0, 'Escalda pés', 8, 13, 73100020, 'Rua dos Cristais', 123),
    ('2022-08-01', '18:00', 2, 100.0, 'Gomagem', 9, 14, 73100020, 'Rua dos Cristais', 123),
    ('2022-07-07', '08:00', 2, 150.0, 'Hidromassagem', 10, 15, 73100020, 'Rua dos Cristais', 123);

INSERT INTO PRODUTO (nomeMed, volumeMed, formatoMed, precoVenda, descricao, precoCusto, qtdEstoque) VALUES
	('ADAPT-E', 100, 'ml', 73.0, 'Floral', 68.0, 101),
    ('AFINATUM', 50, 'gel', 47.0, 'Floral', 40.0, 202),
    ('ALCALYN', 50, 'ml', 47.0, 'Floral', 39.5, 50),
    ('CRONIFLAN', 100, 'ml', 69.0, 'Floral', 60.0, 30),
    ('ARTRALIS', 100, 'ml', 73.0, 'Floral', 70.0, 15),
	('ALIVIC', 50, 'ml', 54.0, 'Floral', 40.0, 30),
    ('BIOMAMA', 50, 'ml', 57.0, 'Floral', 42.0, 40),
    ('CALMALLIS', 50, 'ml', 47.0, 'Floral', 37.0, 50),
    ('CLIMATOX', 50, 'ml', 80.0, 'Floral', 70.0, 55),
    ('COMPLEXO B', 100, 'ml', 90.0, 'Floral', 80.0, 40);

INSERT INTO agrega (posologiaProduto, idReceita, nomeMed, volumeMed, formatoMed) VALUES
	('Aplicar de 3 em 3 horas', 1, 'ADAPT-E', 100, 'ml'),
    ('Aplicar quando sentir desconforto', 2, 'AFINATUM', 50, 'gel'),
    ('Aplicar na testa quando sentir enxaqueca', 3, 'ALCALYN', 50, 'ml'),
    ('Inalar quando sentir mal estar', 4, 'CRONIFLAN', 100, 'ml'),
	('Aplicar de 8 em 8 horas', 5, 'ARTRALIS', 100, 'ml'),
	('Aplicar de 3 em 3 horas', 6, 'ALIVIC', 50, 'ml'),
    ('Aplicar quando sentir desconforto', 7, 'BIOMAMA', 50, 'ml'),
    ('Aplicar na testa quando sentir enxaqueca', 8, 'CALMALLIS', 50, 'ml'),
    ('Inalar quando sentir mal estar', 9, 'CLIMATOX', 50, 'ml'),
    ('Tomar de 8 em 8 horas', 10, 'COMPLEXO B', 100, 'ml');

INSERT INTO tem (qtdVendida, valorSubtotal, idVenda, nomeMed, volumeMed, formatoMed) VALUES
	(1, 73.0, 6, 'ADAPT-E', 100, 'ml'),
    (1, 47.0, 7, 'AFINATUM', 50, 'gel'),
    (1, 47.0, 8, 'ALCALYN', 50, 'ml'),
    (1, 69.0, 9, 'CRONIFLAN', 100, 'ml'),
    (1, 73.0, 10, 'ARTRALIS', 100, 'ml'),
    (1, 54.0, 16, 'ALIVIC', 50, 'ml'),
    (1, 57.0, 17, 'BIOMAMA', 50, 'ml'),
    (1, 47.0, 18,'CALMALLIS', 50, 'ml'),
    (1, 80.0, 19,'CLIMATOX', 50, 'ml'),
    (1, 90.0, 20,'COMPLEXO B', 100, 'ml');
    
INSERT INTO ESTUDO (documento, tipoDocumento, nomeCurso, dtInicioCurso) VALUES
	(9987546, 'RG', 'Fenômenos Psicológicos', '2022-05-01'),
    (5642182, 'RG', 'Benefícios da Proteína', '2022-05-10'),
    (3546566, 'RG', 'Pedagogia do Oprimido', '2022-06-05'),
    (7564189, 'RG', 'Futebol no Primário', '2022-06-23'),
    (6574846, 'RG', 'Psicologia Cênica', '2022-08-09'),
	(1187546, 'RG', 'Introdução a Psicologia', '2022-10-01'),
    (2242182, 'RG', 'Benefícios dos Florais', '2022-11-10'),
    (3346566, 'RG', 'O que é o autocuidado', '2022-12-05'),
    (4964189, 'RG', 'Infância Saudável', '2023-09-23'),
    (5174846, 'RG', 'Estudo da mente', '2023-08-09');
    
INSERT INTO CERTIFICADO (descCertificado, dataConclusao, cargaHoraria, nomeCertificado, idEstudo) VALUES
    ('Certificado em Reiki', '2023-01-01', 10, 'Reki', 1),
    ('Certificado em Barra de Access', '2023-02-02', 10, 'Barra de Access', 2),
	('Certificado em Terapia Quântica', '2023-03-03', 10, 'Terapia Quântica', 3),
    ('Certificado em Terapia com Florais', '2023-04-04', 10, 'Terapia com Florais', 4),
	('Certificado em Reiki', '2023-05-05', 10, 'Reiki', 5),
    ('Certificado em Barra de Access', '2023-06-06', 10, 'Barra de Access', 6),
	('Certificado em Reiki', '2023-07-07', 10, 'Reiki', 7),
    ('Certificado em Barra de Access', '2023-08-08', 10, 'Barra de Access', 8),
	('Certificado em Reiki', '2023-09-09', 10, 'Reiki', 9),
    ('Certificado em Barra de Access', '2023-10-10', 10, 'Barra de Access', 10);

INSERT INTO detem (posologia, idReceita, nomeFarmaco, volumeFarmaco) VALUES
	('Tomar de 8 em 8 horas', 1, 'Dorflex', 1),
    ('Tomar de 8 em 8 horas', 2, 'Soro caseiro', 300),
    ('Tomar de 8 em 8 horas', 3, 'Biotonico', 50),
    ('Tomar de 12 em 12 horas', 4, 'Cafeina em Capsulas', 4),
	('Tomar de 8 em 8 horas', 5, 'Potassio em Capsulas', 5),
	('Tomar de 8 em 8 horas', 6, 'Polivitaminico', 2),
    ('Tomar de 8 em 8 horas', 7, 'Zinco em capsulas', 3),
    ('Tomar de 8 em 8 horas', 8, 'Ferro em capsulas', 4),
    ('Tomar de 8 em 8 horas', 9, 'Alivium', 1),
	('Tomar de 8 em 8 horas em caso de alergia', 10, 'Celestamine', 1);