-- ---------- << TF - Tema 1 - Clínica de Terapia >> ----------
--
--                    SCRIPT DE DELECAO
--
-- Data Criacao ...........: 31/08/2022
-- Autor(es) ..............: Gabriel Mariano da Silva, Cibele Freitas Goudinho, Daniel Barcelos Moreira e Artur Seppa Reiman
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1A_danielmoreira
--
-- Ultimas Alteracoes
--   11/09/2022 => Alterando tabelas para atualização do projeto conforme a documentacao
--              => Alterando nome da base de dados
--              => Alterando ordem das delecoes
--
--   19/09/2022 => Adicionando drop da tabela DIPLOMA
--              => Removendo drop da tabela cursa
--              => Alterando nome de drop tabela RELATORIO para PROTOCOLO
--              => Adicionando drop da tabela ESTUDO
--              => Adicionando drop da tabela CERTIFICADO
--              => Adicionando drop da tabela detem
--              => Alterando o nome da base de dados e a quantidade de tabelas
--
-- PROJETO => 01 Base de Dados
--         => 23 Tabelas
--         => 03 Roles
--         => 06 Usuarios
--
-- ---------------------------------------------------------

-- BASE DE DADOS
USE TF_1A_danielmoreira;

-- APAGANDO
DROP TABLE detem;

DROP TABLE CERTIFICADO;

DROP TABLE ESTUDO;

DROP TABLE tem;

DROP TABLE agrega;

DROP TABLE PRODUTO;

DROP TABLE SESSAO;

DROP TABLE VENDA;

DROP TABLE TRATAMENTO;

DROP TABLE FARMACO;

DROP TABLE RECEITA;

DROP TABLE PROTOCOLO;

DROP TABLE TESTE;

DROP TABLE queixa;

DROP TABLE CONSULTA;

DROP TABLE PACIENTE;

DROP TABLE AULA;

DROP TABLE da;

DROP TABLE CURSO;

DROP TABLE DIPLOMA;

DROP TABLE PALESTRANTE;

DROP TABLE PESSOA;

DROP TABLE ENDERECO;
