-- 
--              SCRIPT APAGA
--
-- Data Criacao .......: 31/08/2022
-- Autor ..............: Mariana Rio, Vitor Ribeiro, Nilvan Costa
-- Banco de Dados .....: MySQL 8.0
-- Base de Dados ......: TF_3A_NilvanCosta
--
--
-- PROJETO => 01 Base de Dados 
--         => 21 Tabelas
-- Ultimas alteracoes
-- 18/09/2022 => remocao do tabela alugado


USE TF_3A_NilvanCosta;

DROP TABLE le;
DROP TABLE orienta;
DROP TABLE contem;
DROP TABLE possui;
DROP TABLE email;
DROP TABLE telefone;
DROP TABLE MONITOR;
DROP TABLE GARCOM;
DROP TABLE FUNCIONARIO;
DROP TABLE MERCADORIA;
DROP TABLE COMPRA;
DROP TABLE LANCHE;
DROP TABLE CLUBE;
DROP TABLE SEMANAL;
DROP TABLE QUADRINHO;
DROP TABLE PONTUACAO;
DROP TABLE MESA;
DROP TABLE COMANDA;
DROP TABLE ALUGUEL;
DROP TABLE JOGO;
DROP TABLE CLIENTE;