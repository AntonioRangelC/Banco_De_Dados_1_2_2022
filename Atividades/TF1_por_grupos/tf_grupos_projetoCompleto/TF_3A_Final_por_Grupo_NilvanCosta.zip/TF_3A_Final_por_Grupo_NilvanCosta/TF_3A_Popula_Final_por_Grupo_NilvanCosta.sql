-- 
--              SCRIPT DE POPULA (DML) 
--
-- Data Criacao .......: 31/08/2022
-- Ultima Alteracao ....: 19/09/2022
-- Autor ..............: Mariana Rio, Vitor Ribeiro
-- Banco de Dados .....: MySQL 8.0
-- Base de Dados ......: TF_3A2_marianario
--
--
-- PROJETO => 01 Base de Dados
--         => 21 Tabelas
USE TF_3A_NilvanCosta;

INSERT INTO CLIENTE
	(nomeCliente)
VALUES
	('Claudio Peres'),
    ('Maria Amelia Campos'),
    ('Karla Dias'),
    ('Luisa Peres'),
    ('Marco Paulo'),
    ('Paulo Santillo'),
    ('Isadora Mello'),
    ('Guilherme Cembranel'),
    ('Murilo Ruff'),
    ('Gero Bordori'),
    ('Leticia Silva'),
    ('Henrique Amorim'),
    ('Beatriz Chaveiro'),
    ('Paulo Coelho'),
    ('Ronan Wilk'),
    ('José Pereira'),
    ('João Campos'),
    ('Luana Carstens'),
    ('Pedro Guimaraes'),
    ('Igor Peixoto');
    
    
INSERT INTO JOGO
	(nomeJogo, editora, numeroCopia, categoria, situacao)
VALUES
	('Xadrez','BESPORTBLE', 09, 'Azul', 'D'),
    ('Monopoly', 'Hasbro', 07, 'Amarelo', 'D'),
    ('Catan', 'Grow Jogos', 02, 'Dourado', 'D'),
    ('Jogo da Vida', 'Estrela', 05, 'Amarelo', 'D'),
    ('Clue', 'Hasbro', 04, 'Amarelo', 'D'),
    ('Detetive', 'Estrela', 02, 'Rosa', 'D'),
    ('Combate', 'Estrela', 03, 'Azul', 'D'),
    ('War', 'Grow Jogos', 05, 'Amarelo', 'D'),
    ('Cara a Cara', 'Estrela', 01, 'Dourada', 'D'),
    ('Pandemic', 'Galápagos Jogos', 03, 'Dourada', 'D'),
    ('Dixit', 'Galápagos Jogos', 02, 'Azul', 'D'),
    ('Código Secreto', 'Devir', 04, 'Amarela', 'D'),
    ('Ludo', 'Carimbras', 02, 'Amarela', 'D'),
    ('Cluedo', 'Hasbro Gaming', 01, 'Dourada', 'D'),
    ('Ubongo', 'Devir', 02, 'Amarela', 'D'),
    ('Tinco', 'Devir', 01, 'Dourada', 'D'),
    ('Santorini', 'Galápagos Jogos', 04, 'Amarela', 'D'),
    ('Fantasma Blitz', 'Devir', 03, 'Amarela', 'D'),
    ('Speed Cups', 'PaperGames', 02, 'Azul', 'D'),
    ('Dark City', 'Devir', 03, 'Dourada', 'D');
    
INSERT INTO ALUGUEL
	(idCliente, cpf, rg, dataNascimento, assinaturaCliente, logradouro, bairro, cep)
VALUES
	(1, 12445338909, 62004403, '1989-04-10', '1', 'Rua Alameda dos Ipes', 'Gama-DF', 60711230),
	(2, 31425338989, 42304403, '1997-07-04', '1', 'Rua dos Pinheiros', 'Gama-DF', 60715430),
    (3, 42665338960, 22430503, '1998-07-25', '1', 'Rua Chiara', 'Gama-DF', 60445440),
    (4, 52222338905, 21460563, '1998-08-31', '1', 'Rua Lobo', 'Gama-DF', 63245440),
    (5, 42335338960, 22430503, '2000-03-25', '1', 'Rua Chiara', 'Gama-DF', 60445440),
    (6, 03921201195, 59706054, '1998-08-13', '1', 'Rua Bernado Sayao', 'Gama-DF', 75080080),
    (7, 78811929172, 22430503, '1965-03-20', '1', 'Rua Macarana', 'Gama-DF', 70746500),
    (8, 16529799120, 22430503, '2002-08-23', '1', 'Rua CCSW2', 'Sudoeste', 70766520),
    (9, 06948321119, 03659182, '1987-01-27', '1', 'Rua Leopoldo de Bulhões', 'Cruzeiro', 70299080),
    (10, 14495120115, 12956841, '1996-01-24', '1', 'Rua SQS 411', 'Asa sul', 70740769),
	(11, 98531909155, 11800306, '1992-05-12', '1', 'Quadra EQNL', 'Taguatinga-DF', 72155502),
	(12, 07142910135, 13228361, '1999-12-12', '1', 'Arapoanga', 'Planaltina-DF', 73368580),
    (13, 51831980126, 36864872, '1979-10-25', '1', 'Setor Habitacional Arniqueira', 'Águas Claras-DF', 71994325),
    (14, 02388691133, 18268873, '1974-04-05', '1', 'CSC 1', 'Taguantinga-DF', 72016015),
    (15, 59443423154, 39974212, '2003-11-05', '1', 'CLS 212', 'Asa Sul-DF', 72145504),
    (16, 74548676180, 21866473, '1998-05-12', '1', 'SHIGS 703', 'Asa Sul-DF', 70331704),
    (17, 19931102160, 15661574, '1969-10-20', '1', 'QS 601', 'Samambaia-DF', 72331500),
    (18, 73448910180, 50451102, '2005-05-13', '1', 'SQN 211', 'Asa Norte-DF', 70863080),
    (19, 06948145119, 03818442, '1988-04-27', '1', 'Segunda Avenida Bloco 1520', 'Núcleo Bandeirante-DF', 70650278),
    (20, 19351228115, 12874841, '1997-03-24', '1', 'SHCES Quadra 207', 'Cruzeiro Novo-DF', 70740769);
    
INSERT INTO COMANDA
	(dataComanda)
VALUES
	('2022-07-11'),
	('2022-08-12'),
	('2022-04-08'),
	('2022-03-25'),
	('2022-09-01'),
    ('2022-09-01'),
    ('2022-09-06'),
    ('2022-09-18'),
    ('2022-09-02'),
    ('2022-09-02');
    

INSERT INTO MESA
	(limpa, idJogo, idComanda)
VALUES
	(0, 1, 2),
    (1, 2, 4),
    (1, 3, 3),
    (1, 4, 1),
    (1, 5, 5),
	(0, 6, 9),
    (1, 7, 7),
    (1, 8, 6),
    (1, 9, 10),
    (1, 10, 8);
    
    
INSERT INTO PONTUACAO
	(pontuacaoMes, pontuacaoTotal, idCliente, idJogo)
VALUES
	(9892, 9892, 2, 1),
	(8912, 992831, 3, 2),
    (90122, 90122, 1, 4),
    (9823, 312334, 4, 3),
    (8990, 8990, 5, 5),
	(4500, 9892, 7, 10),
	(9820, 92831, 10, 7),
    (5210, 9022, 6, 8),
    (4680, 32334, 8, 6),
    (3895, 85690, 9, 9);

INSERT INTO QUADRINHO
	(nomeQuadrinho, editora, numeroCopia, situacao)
VALUES
	('Haikyuu vol. 1', 'Selecta Vísion', 01, 'D'),
    ('Haikyuu vol. 2', 'Selecta Vísion', 01, 'D'),
    ('Kimetsu no Yaiba vol. 1', 'Planet Manga', 01, 'D'),
    ('Naruto vol. 1', ' Masashi Kishimoto', 01, 'D'),
    ('One Piece vol.1', 'Weekly Shōnen Jump', 01, 'D'),
	('Haikyuu vol. 3', 'Selecta Vísion', 01, 'D'),
    ('Kimetsu no Yaiba vol. 3', 'Planet Manga', 04, 'D'),
    ('Naruto Shippuden vol. 5', ' Masashi Kishimoto', 07, 'D'),
    ('One Piece vol.3', 'Weekly Shōnen Jump', 04, 'D'),
    ('One Piece vol.4', 'Weekly Shōnen Jump', 06, 'D');
    
INSERT INTO SEMANAL
	(numAluguel, prazoDevolucao, valor, multa, idJogo, idQuadrinho)
VALUES
	(1, '2022-09-01', 35.00, 0.0, 1, 2),
    (2, '2022-08-02', 55.00, 0.0, 3, 1),
    (3, '2022-08-20', 75.00, 0.0, 2, 3),
	(4, '2022-07-30', 55.00, 0.0, 5, 4),
    (5, '2022-05-04', 55.00, 0.0, 4, 5),
	(10, '2022-12-03', 60.30, 0.0, 7, 6),
    (7, '2022-10-02', 88.30, 0.0, 9, 7),
    (6, '2022-09-30', 65.04, 0.0, 10, 8),
	(8, '2022-09-27', 104.30, 0.0, 8, 9),
    (9, '2022-09-26', 66.31, 0.0, 6, 10);
    
INSERT INTO CLUBE
	(numAluguel, tipoPlano, dataRenovacao, numeroCartao, nomeCartao, codigoSeguranca, dataVencimentoCartao, multa)
VALUES
	(1, 'C', '2022-04-10', 7894565656585232, 'Jose Elmar Pereira', 423, '03/27', 0.0),
    (2, 'C', '2022-09-02', 6844565268585243, 'Paulo Lorenzo Carlos', 063, '11/28', 0.0),
    (3, 'B', '2022-03-10', 3234123268858522, 'Ana Paula Pimenta', 022, '01/27', 0.0),
    (4, 'B', '2022-04-15', 8894123268858762, 'Carlos Andrade', 252, '06/30', 0.0),
    (5, 'H', '2022-12-10', 2351465268585243, 'Daniel Almeida', 833, '12/31', 0.0),
	(10, 'C', '2022-06-11', 5859465656585232, 'Ronan Guimaraes Wilk', 415, '04/27', 0.0),
    (9, 'C', '2022-12-10', 6548975268585243, 'Igor Peixoto Alves', 082, '10/26', 0.0),
    (8, 'B', '2023-01-11', 3239749868858522, 'Pedro Lucas Pereira', 932, '05/25', 0.0),
    (7, 'B', '2022-10-20', 8894236448888762, 'Isadora Viera Mello', 759, '04/26', 0.0),
    (6, 'H', '2022-10-26', 2351462654854885, 'Luana Campos Carstens', 852, '10/24', 0.0);
INSERT INTO LANCHE
	(valorUnitario, nomeLanche)
VALUES
	(15.90, 'Crepe de Calabresa'),
	(15.90, 'Crepe de Frango c/ Queijo'),
	(15.90, 'Crepe de Nutela'),
    (7.90, 'Suco'),
	(5.90, 'Refrigerante'),
	(15.90, 'Crepe de Carne'),
	(16.80, 'Crepe 4 Queijs'),
	(17.90, 'Crepe de Bana c/ Chocolate'),
    (9.90, 'Suco Polpa'),
	(5.90, 'Refrigerante');
    
INSERT INTO COMPRA
	(dataCompra, formaPagamento)
VALUES
	('2022-08-29', 'Dinheiro'),
	('2022-08-28', 'Cartão'),
	('2022-08-30', 'Dinheiro'),
	('2022-09-02', 'Cartão'),
	('2022-08-10', 'Cartão'),
	('2022-09-2', 'Pix'),
	('2022-09-4', 'Dinheiro'),
	('2022-09-15', 'Cartão'),
	('2022-08-10', 'Pix'),
	('2022-07-15', 'Dinheiro');
    
INSERT INTO MERCADORIA
	(valorUnitario, nomeMercadoria)
VALUES
	(155.99, 'Boneco Geek Naruto'),
	(155.99, 'Boneco Geek Sasuke'),
	(155.99, 'Boneco Geek Kimetsu no Yaiba'),
	(49.99, 'Quadrinho Kimetsu no Yaiba vol. 1'),
	(255.99, 'Jogo Monopoly'),
	(89.59, 'Jogo da Vida'),
	(200.50, 'Jogo detetive'),
	(15.99, 'Caneca Geek Zoro'),
	(49.99, 'Camiseta Geek Marvel'),
	(75.00, 'Jogo Xadrez');
    
INSERT INTO FUNCIONARIO
	(nomeFuncionario, dataContratacao, dataNascimento)
VALUES
	('Roger Moacir', '2022-08-03',  '1997-08-15'),
    ('Luisa Almirante', '2022-03-01',  '1998-10-12'),
    ('Aroldo Borges', '2022-04-10',  '1998-08-12'),
    ('Cleiton Varges', '2021-10-18',  '1989-02-10'),
    ('Carlos Moreira', '2021-12-02',  '2000-01-01'),
    ('Fernando dos Reis', '2022-07-03',  '1997-09-15'),
    ('Miguel Carvalho', '2022-04-10',  '1998-11-25'),
    ('Jessica Alves', '2022-05-20',  '1999-01-12'),
    ('Jorge Machado', '2022-09-12',  '1995-03-17'),
    ('Paulo Rabelo', '2022-09-05',  '2001-02-18'),
	('Pedro Pires', '2022-05-04',  '1997-08-15'),
    ('João Coelho', '2022-05-01',  '1998-10-12'),
    ('Fernando Lima', '2022-06-12',  '1998-08-12'),
    ('Leticia Vieira', '2021-07-18',  '1989-02-10'),
    ('Julia Isis', '2021-10-12',  '2000-01-01'),
    ('Lucas Pinto', '2022-08-13',  '1997-09-15'),
    ('Emanoel Ferreira', '2022-10-12',  '1998-11-25'),
    ('Jessica Alves', '2022-06-18',  '1999-01-12'),
    ('Gabriel Souza', '2022-08-11',  '1995-03-17'),
    ('Matheus Oliveira', '2022-06-04',  '2001-02-18');
    
INSERT INTO GARCOM
	(idMatricula, descricaoFuncao, idMesa, idComanda)
VALUES
	(1, 'Servir mesa', 1, 1),
    (2, 'Limpar mesa', 2, 2),
    (3, 'Limpar mesa', 3, 3),
    (4, 'Servir mesa', 4, 4),
    (5, 'Servir e Limpar mesas', 5, 5),
	(11, 'Servir mesa', 6, 6),
    (12, 'Limpar mesa', 7, 7),
    (13, 'Limpar mesa', 8, 8),
    (14, 'Servir mesa', 9, 9),
    (15, 'Servir e Limpar mesas', 10, 10);
INSERT INTO MONITOR
	(idMatricula, turno, descricaoFuncao)
VALUES
	(6, 'matutino', 'Orientar jogadores'),
    (7, 'matutino', 'Orientar jogadores'),
    (8, 'vespertino', 'Orientar jogadores'),
    (9, 'vespertino', 'Orientar jogadores'),
    (10, 'matutino', 'Orientar jogadores'),
	(16, 'matutino', 'Orientar jogadores'),
    (17, 'matutino', 'Orientar jogadores'),
    (18, 'vespertino', 'Orientar jogadores'),
    (19, 'vespertino', 'Orientar jogadores'),
    (20, 'matutino', 'Orientar jogadores');
INSERT INTO telefone
	(idCliente, telefone)
VALUES
	(1, 61999899819),
    (2, 62994754419),
    (3, 61995236899),
    (4, 61999123754),
    (5, 61997283059),
	(6, 61986651689),
    (7, 61985754419),
    (8, 619255836849),
    (9, 619895892454),
    (10, 61987233049);
INSERT INTO email
	(idCliente, email)
VALUES
	(1, 'claudio01@gmail.com'),
    (2, 'maria.campos@hotmail.com'),
    (3, 'karla.dd@gmail.com'),
    (4, 'luisa.peres@gmail.com'),
    (5, 'marco.paulao@hotmail.com'),
	(6, 'paulo.santillo@gmail.com'),
    (7, 'isadora_mell00@gmail.com'),
    (8, 'gm_cembranel@gmail.com'),
    (9, 'murilo_HufF@yahoo.com.br'),
    (10, 'gero_bordori@outlook.com');
INSERT INTO possui
	(idCompra, idMercadoria)
VALUES
	(1, 2),
    (3, 4),
    (1, 3),
    (2, 5),
    (5, 1),
	(10, 6),
    (9, 7),
    (6, 8),
    (8, 9),
    (7, 10);
    
INSERT INTO contem
	(idComanda, idLanche)
VALUES
	(1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5),
	(6, 10),
    (7, 9),
    (8, 8),
    (9, 7),
    (10, 6);
INSERT INTO orienta
	(idMatricula, idMesa)
VALUES
	(6, 1),
    (7, 3),
    (8, 2),
    (9, 5),
    (10, 4),
	(16, 6),
    (17, 8),
    (18, 7),
    (19, 10),
    (20, 9);
INSERT INTO le
	(idCliente, idQuadrinho)
VALUES
	(1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5),	
    (6, 6),
    (7, 7),
    (8, 8),
    (9, 9),
    (10, 10);

    
    
    