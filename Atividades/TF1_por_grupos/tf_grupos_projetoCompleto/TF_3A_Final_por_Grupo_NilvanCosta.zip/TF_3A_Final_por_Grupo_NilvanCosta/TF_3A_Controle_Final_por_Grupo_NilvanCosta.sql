-- --------  << TRABALHO FINAL >>  ----------
--
--            SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 12/09/2022
-- Autor(es) ..............: Vitor Diniz Pagani Vieira Ribeiro, Mariana Rio, NilvanCosta
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_3A_NilvanCosta
--
--
-- PROJETO => 01 Base de Dados
--         => 21 Tabelas
--         => 04 Papeis			
--         => 12 Usuarios

-- Ultimas alteracoes
-- 19/09/2022  => Criacao dos papeis de usuarios e usuarios
-- -------------------------------------------------------

USE TF_3A_NilvanCosta;

CREATE ROLE 'administrador'@'localhost';

CREATE ROLE 'gerente'@'localhost';

CREATE ROLE 'monitor'@'localhost';

CREATE ROLE 'garcom'@'localhost';
 
CREATE USER Charlon IDENTIFIED BY 'admincharlon2022';

CREATE USER Leticia IDENTIFIED BY 'leticia2022';

CREATE USER Artur IDENTIFIED BY 'artur2022';

CREATE USER Carlos IDENTIFIED BY 'carlos2022';

CREATE USER Pedro IDENTIFIED BY 'pedro2022';

CREATE USER Jorge IDENTIFIED BY 'jorge2022';

CREATE USER Luiza IDENTIFIED BY 'luiza2022';

CREATE USER Joao IDENTIFIED BY 'joao2022';

CREATE USER Antonio IDENTIFIED BY 'antonio2022'; 

CREATE USER Sergio IDENTIFIED BY 'sergio2022';

CREATE USER Amir IDENTIFIED BY 'amir2022';

CREATE USER Luis IDENTIFIED BY 'luis2022';

GRANT ALL PRIVILEGES 
	ON tf_3a_nilvancosta.*
    TO 'administrador'@'localhost';
    
GRANT SELECT, INSERT, UPDATE 
	ON tf_3a_nilvancosta.*
    TO 'gerente'@'localhost';
    
GRANT SELECT, INSERT 
	ON tf_3a_nilvancosta.MESA
    TO 'monitor'@'localhost';
    
GRANT SELECT
	ON tf_3a_nilvancosta.COMANDA
    TO 'garcom'@'localhost';
    
GRANT 'administrador'@'localhost' TO Charlon;
GRANT 'administrador'@'localhost' TO Leticia;
GRANT 'administrador'@'localhost' TO Artur;

GRANT 'gerente'@'localhost' TO Carlos;
GRANT 'gerente'@'localhost' TO Pedro;
GRANT 'gerente'@'localhost' TO Jorge;

GRANT 'monitor'@'localhost' TO Luiza;
GRANT 'monitor'@'localhost' TO Joao;
GRANT 'monitor'@'localhost' TO Antonio;

GRANT 'garcom'@'localhost' TO Sergio;
GRANT 'garcom'@'localhost' TO Amir;
GRANT 'garcom'@'localhost' TO Luis;
