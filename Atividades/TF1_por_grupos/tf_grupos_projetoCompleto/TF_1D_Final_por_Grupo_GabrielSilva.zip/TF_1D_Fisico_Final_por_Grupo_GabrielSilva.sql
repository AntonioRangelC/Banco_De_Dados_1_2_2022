-- ---------------------   << TF_1D_GabrielSilva >>   ---------------------
--
--                         SCRIPT DE CRIAÇÃO                                  
-- 
-- Data Criacao ...........: 30/08/2022
-- Autor(es) ..............: Guilherme Silva, Gabriel Cruz, Gabriel Silva e Eduardo Farias
-- Banco de Dados .........: MySQL 8.0
-- Banco de Dados(nome) ...: TF_1D_GabrielSilva
--
-- Ultimas Alteracoes
--   11/09/2022 => Alteração do nome da base de dados.
--              => Alteração do tipo BIGINT para DECIMAL.
--              => Criação de novas tabelas: melhora, INSCRICAO, TURMA e diaAula.
--              => Exclusão da tabela FORMA_PAG, substituindo por atributo de tipo ENUM.
--              => Alteração da tabela se_inscreve para adquire.
--              => Inclusão de restrições, como check, default e on delete/on update.
--            	=> Inclusão de novos atributos em algumas tabelas: CERTIFICADO, CONSULTA, COMPRA, CURSO, estoca e prescrito_em.
--    			=> Aumento no tamanho de algumas variáveis do tipo varchar.
--   18/09/2022 => Alteração do nome da base de dados.
--              => Criação de mais duas tabelas (ORGAO e afeta).
--              => Alteração no tamanho de algumas variáveis do tipo varchar.
--
-- PROJETO => 01 Base de Dados
--         => 32 Tabelas
--  	   => 05 Perfis
--         => 25 Usuários
-- 
-- --------------------------------------------------------------------------------------------
-- Criação da base de dados
CREATE DATABASE IF NOT EXISTS TF_1D_GabrielSilva;

USE TF_1D_GabrielSilva;

-- Criação das tabelas
CREATE TABLE PESSOA (
    cpf  		DECIMAL(11,0) 	NOT NULL,
    numeroTel 	DECIMAL(9,0) 	NOT NULL,
    ddd 		DECIMAL(2,0) 	NOT NULL,
    estado 		VARCHAR(2) 		NOT NULL,
    cidade 		VARCHAR(30) 	NOT NULL,
    bairro 		VARCHAR(30) 	NOT NULL,
    rua 		VARCHAR(30) 	NOT NULL,
    numero 		INT 			NOT NULL,
    complemento	VARCHAR(100)			,
    cep			DECIMAL(8,0) 	NOT NULL,
    nome 		VARCHAR(100) 	NOT NULL,
    constraint PESSOA_PK primary key (cpf)
)ENGINE = InnoDB;

CREATE TABLE PACIENTE (
	cpfPaciente 	DECIMAL(11,0) 				NOT NULL,
    rg 				DECIMAL(7,0)						,
    profissao 		VARCHAR(30)							,
    grupoSanguineo 	ENUM('O', 'A', 'B', 'AB') 	NOT NULL,
    fatorRh 		ENUM('+', '-') 				NOT NULL,
    alergia         VARCHAR(50)                NOT NULL,
    email 			VARCHAR(50) 				NOT NULL,
    estadoCivil 	VARCHAR(20)							,
    dtNasc 			DATE 						NOT NULL,
    constraint PACIENTE_PK primary key(cpfPaciente),
    constraint PACIENTE_PESSOA_FK foreign key (cpfPaciente)
    references PESSOA(cpf) on delete cascade on update cascade,
    constraint PACIENTE_cpfPaciente_UK unique key(cpfPaciente),
    constraint PACIENTE_rg_UK unique key(rg)
)ENGINE = InnoDB;

CREATE TABLE TERAPEUTA (
    matriculaTerapeuta 	INT 			NOT NULL,
    dtContratacao 		DATE 			NOT NULL,
    cpfTerapeuta 		DECIMAL(11,0) 	NOT NULL,
    constraint TERAPEUTA_PK primary key(cpfTerapeuta),
    constraint TERAPEUTA_PESSOA_FK foreign key (cpfTerapeuta)
    references PESSOA(cpf) on delete cascade on update cascade,
    constraint TERAPEUTA_matriculaTerapeuta_UK unique key(matriculaTerapeuta),
    constraint TERAPEUTA_cpfTerapeuta_UK unique key(cpfTerapeuta)
)ENGINE = InnoDB;

CREATE TABLE CLIENTE (
	cpfCliente 	DECIMAL(11,0) 	NOT NULL,
    dtCadastro 	DATE 			NOT NULL,
    constraint CLIENTE_PK primary key(cpfCliente),
    constraint CLIENTE_PESSOA_FK foreign key (cpfCliente)
    references PESSOA(cpf) on delete cascade on update cascade,
    constraint CLIENTE_cpfCliente_UK unique key(cpfCliente)
)ENGINE = InnoDB;

CREATE TABLE ALUNO (
	cpfAluno 		DECIMAL(11,0) 	NOT NULL,
    matriculaAluno 	INT 			NOT NULL,
    constraint ALUNO_PK primary key(cpfAluno),
    constraint ALUNO_PESSOA_PK foreign key (cpfAluno)
    references PESSOA(cpf) on delete cascade on update cascade,
    constraint ALUNO_cpfAluno_UK unique key(cpfAluno),
    constraint ALUNO_matriculaAluno_UK unique key(matriculaAluno)
)ENGINE = InnoDB;

CREATE TABLE LOJA (
    idLoja 		INT 			NOT NULL AUTO_INCREMENT,
    estado 		VARCHAR(2) 		NOT NULL,
    cidade 		VARCHAR(30) 	NOT NULL,
    rua 		VARCHAR(30) 	NOT NULL,
    numero 		INT 			NOT NULL,
    complemento VARCHAR(100)			,
    cep 		DECIMAL(8,0) 	NOT NULL,
    bairro 		VARCHAR(30) 	NOT NULL,
    constraint LOJA_PK primary key (idLoja)
)ENGINE = InnoDB AUTO_INCREMENT 1;

CREATE TABLE COMPRA (
    idCompra 	INT 							NOT NULL AUTO_INCREMENT,
    dtCompra 	DATE        					NOT NULL,
    horaCompra 	TIME 		            		NOT NULL,
    desconto 	DECIMAL(5,2)							,
    cpfCliente 	DECIMAL(11,0) 					NOT NULL,
    idLoja 		INT 							NOT NULL,
    formaPag 	ENUM('P','D','CD','CC','TB')	NOT NULL,
    constraint COMPRA_PK primary key (idCompra),
    constraint COMPRA_CLIENTE_FK foreign key (cpfCliente)
    references CLIENTE(cpfCliente) on delete restrict on update cascade,
    constraint COMPRA_LOJA_FK foreign key (idLoja)
    references LOJA(idLoja) on delete cascade on update cascade,
    constraint COMPRA_desconto_CK check(desconto > 0)
)ENGINE = InnoDB AUTO_INCREMENT 1;

CREATE TABLE FORMULARIO (
    idFormulario 	INT 			NOT NULL AUTO_INCREMENT,
    cpfPaciente 	DECIMAL(11,0) 	NOT NULL,
    constraint FORMULARIO_PK primary key (idFormulario),
    constraint FORMULARIO_PACIENTE_FK foreign key (cpfPaciente)
    references PACIENTE(cpfPaciente) on delete cascade on update cascade
)ENGINE = InnoDB AUTO_INCREMENT 1;

CREATE TABLE queixa (
    idFormulario 	INT 		    NOT NULL,
    queixa 			VARCHAR(500)    NOT NULL,
    CONSTRAINT queixa_FORMULARIO_FK FOREIGN KEY (idFormulario)
    REFERENCES FORMULARIO(idFormulario) on delete cascade on update cascade
)ENGINE = InnoDB;

CREATE TABLE PRODUTO (
    idProduto 	INT 						NOT NULL AUTO_INCREMENT,
    nome 		VARCHAR(30) 				NOT NULL,
    precoCusto 	DECIMAL(5,2) 				NOT NULL,
    precoVenda 	DECIMAL(5,2) 				NOT NULL,
    tipoProduto ENUM('FQ', 'FITO', 'LO') 	NOT NULL,
    constraint PRODUTO_PK primary key (idProduto),
    constraint PRODUTO_precoCusto_CK check(precoCusto > 0),
    constraint PRODUTO_precoVenda_CK check(precoVenda >= precoCusto)
)ENGINE = InnoDB AUTO_INCREMENT 1;

CREATE TABLE FLORAL_QUANTICO (
    idElemento 			INT 		    NOT NULL AUTO_INCREMENT,
    funcionalidade 		VARCHAR(100)    NOT NULL,
    nomeElemento 		VARCHAR(100)    NOT NULL,
    frequenciaElemento	VARCHAR(15)     NOT NULL,
    idProduto 			INT 		    NOT NULL,
    constraint FLORAL_QUANTICO_PK primary key (idElemento),
    constraint FLORAL_QUANTICO_PRODUTO_FK foreign key (idProduto)
    references PRODUTO(idProduto) on delete cascade on update cascade,
    constraint FLORAL_QUANTICO_idProduto_UK unique key(idProduto)
)ENGINE = InnoDB AUTO_INCREMENT 1;

CREATE TABLE FITOTERAPICO (
	idFitoterapico 	INT 		    NOT NULL AUTO_INCREMENT,
    dsFitoterapico 	VARCHAR(100)    NOT NULL,
    idProduto 		INT 		    NOT NULL,
    constraint FITOTERAPICO_PK primary key (idFitoterapico),
    constraint FITOTERAPICO_PRODUTO_FK foreign key (idProduto)
    references PRODUTO(idProduto) on delete cascade on update cascade,
    constraint FITOTERAPICO_idProduto_UK unique key(idProduto)
)ENGINE = InnoDB AUTO_INCREMENT 1;

CREATE TABLE LINHA_ORGANICA (
    idProdOrganico 	INT 		    NOT NULL AUTO_INCREMENT,
    dsProdOrganico 	VARCHAR(100)    NOT NULL,
    idProduto 		INT 		    NOT NULL,
    constraint LINHA_ORGANICA_PK primary key (idProdOrganico),
    constraint LINHA_ORGANICA_PRODUTO_FK foreign key (idProduto)
    references PRODUTO(idProduto) on delete cascade on update cascade,
    constraint LINHA_ORGANICA_idProduto_UK unique key(idProduto)
)ENGINE = InnoDB AUTO_INCREMENT 1;

CREATE TABLE possui (
    idProduto 	INT NOT NULL,
    idCompra 	INT NOT NULL,
    quantidade 	INT NOT NULL,
    constraint possui_COMPRA_FK foreign key (idCompra)
    references COMPRA(idCompra) on delete cascade on update cascade,
    constraint possui_PRODUTO_FK foreign key (idProduto)
    references PRODUTO(idProduto) on delete restrict on update cascade,
    constraint possui_quantidade_CK check(quantidade > 0)
)ENGINE = InnoDB;

CREATE TABLE FICHA_SESSOES (
    idFicha 		INT 			NOT NULL AUTO_INCREMENT,
    quantSessoes 	INT 			NOT NULL,
    cpfPaciente 	DECIMAL(11,0) 	NOT NULL,
    constraint FICHA_SESSOES_PK primary key (idFicha),
    constraint FICHA_SESSOES_PACIENTE_FK foreign key (cpfPaciente)
    references PACIENTE(cpfPaciente) on delete cascade on update cascade,
    constraint FICHA_SESSOES_quantSessoes_CK check(quantSessoes > 0)
)ENGINE = InnoDB AUTO_INCREMENT 1;

CREATE TABLE PROCEDIMENTO (
    idProcedimento 	INT 			NOT NULL AUTO_INCREMENT,
    dsProcedimento 	VARCHAR(500) 	NOT NULL,
    valor 			DECIMAL(5,2) 	NOT NULL,
    constraint PROCEDIMENTO_PK primary key (idProcedimento),
    constraint PROCEDIMENTO_dsProcedimento_UK unique key(dsProcedimento),
    constraint PROCEDIMENTO_valor_CK check (valor > 0)
)ENGINE = InnoDB AUTO_INCREMENT 1;

CREATE TABLE ORGAO(
	idOrgao     INT             NOT NULL AUTO_INCREMENT,
    nomeOrgao   VARCHAR(100)    NOT NULL,
    constraint ORGAO_PK primary key(idOrgao),
    constraint ORGAO_nomeOrgao_UK unique key(nomeOrgao)
)ENGINE = InnoDB AUTO_INCREMENT 1;

CREATE TABLE afeta(
	idOrgao         INT NOT NULL,
    idProcedimento  INT NOT NULL,
    constraint afeta_ORGAO_FK foreign key(idOrgao)
     references ORGAO(idOrgao)
      on delete restrict
      on update cascade,
	constraint afeta_PROCEDIMENTO_FK foreign key(idProcedimento)
     references PROCEDIMENTO(idProcedimento)
      on delete cascade
      on update cascade
)ENGINE = InnoDB;

CREATE TABLE CURSO (
    idCurso 		INT 			NOT NULL AUTO_INCREMENT,
    cargaHoraria 	INT 			NOT NULL,
    idProcedimento 	INT 			NOT NULL,
    preco 			DECIMAL(6,2) 	NOT NULL,
    constraint CURSO_PK primary key (idCurso),
    constraint CURSO_PROCEDIMENTO_FK foreign key (idProcedimento)
    references PROCEDIMENTO(idProcedimento) on delete restrict on update restrict,
    constraint CURSO_preco_CK check (preco > 0)
)ENGINE = InnoDB AUTO_INCREMENT 1;

CREATE TABLE CONSULTA (
    idConsulta 		INT 							NOT NULL AUTO_INCREMENT,
    dtConsulta 		DATE 							NOT NULL,
    horaConsulta 	TIME 							NOT NULL,
    numSessao 		INT										,
    valorConsulta   DECIMAL(5,2)                    NOT NULL,
    desconto 		DECIMAL(5,2)							,
    formaPag 		ENUM('P','D','CD','CC','TB') 	NOT NULL,
    idProcedimento 	INT 							NOT NULL,
    cpfPaciente 	DECIMAL(11,0)					NOT NULL,
    cpfTerapeuta 	DECIMAL(11,0) 					NOT NULL,
    constraint CONSULTA_PK primary key (idConsulta),
    constraint CONSULTA_PACIENTE_FK foreign key (cpfPaciente)
    references PACIENTE(cpfPaciente) on delete restrict on update cascade,
    constraint CONSULTA_PROCEDIMENTO_FK foreign key (idProcedimento)
    references PROCEDIMENTO(idProcedimento) on delete restrict on update restrict,
    constraint CONSULTA_TERAPEUTA_FK foreign key (cpfTerapeuta)
    references TERAPEUTA(cpfTerapeuta) on delete restrict on update cascade,
    constraint CONSULTA_numSessao_CK check (numSessao > 0)
)ENGINE = InnoDB AUTO_INCREMENT 1;

CREATE TABLE RELATORIO (
    idRelatorio 	INT 		    NOT NULL AUTO_INCREMENT,
    dtRetorno 		DATE				    ,
    orientacao 		VARCHAR(30)     NOT NULL,
    acompanhamento 	VARCHAR(100)    NOT NULL,
    idConsulta 		INT 		    NOT NULL,
    constraint RELATORIO_PK primary key (idRelatorio),
    constraint RELATORIO_CONSULTA_FK foreign key (idConsulta)
    references CONSULTA(idConsulta) on delete cascade on update cascade,
    constraint RELATORIO_idConsulta_UK unique key(idConsulta)
)ENGINE = InnoDB AUTO_INCREMENT 1;

CREATE TABLE melhora(
    idRelatorio INT 		    NOT NULL,
    melhora 	VARCHAR(500)    NOT NULL,
    constraint melhora_RELATORIO_FK foreign key(idRelatorio) 
    references RELATORIO(idRelatorio) on delete cascade on update cascade
)ENGINE = InnoDb;

CREATE TABLE RECEITA (
    idReceita 			INT 		NOT NULL AUTO_INCREMENT,
    dtReceita 			DATE 		NOT NULL,
    horaReceita 		TIME 		NOT NULL,
    idConsulta 			INT 		NOT NULL,
    constraint RECEITA_PK primary key (idReceita),
    constraint RECEITA_CONSULTA_FK foreign key (idConsulta)
    references CONSULTA(idConsulta) on delete cascade on update cascade
)ENGINE = InnoDB AUTO_INCREMENT 1;

CREATE TABLE esta_contido (
    idProcedimento 	INT NOT NULL,
    idFicha 		INT NOT NULL,
    constraint esta_contido_PROCEDIMENTO_FK foreign key (idProcedimento)
    references PROCEDIMENTO(idProcedimento) on delete restrict on update restrict,
    constraint esta_contido_FICHA_SESSOES_FK foreign key (idFicha)
    references FICHA_SESSOES(idFicha) on delete cascade on update cascade
)ENGINE = InnoDB;

CREATE TABLE leciona(
    cpfTerapeuta	DECIMAL(11,0) 	NOT NULL,
    idCurso 		INT 			NOT NULL,
    constraint leciona_CURSO_FK foreign key (idCurso)
    references CURSO(idCurso) on delete cascade on update cascade,
    constraint leciona_TERAPEUTA_FK foreign key (cpfTerapeuta)
    references TERAPEUTA(cpfTerapeuta) on delete restrict on update cascade
)ENGINE = InnoDB;

CREATE TABLE adquire (
    idCurso 	INT 			NOT NULL,
    cpfAluno 	DECIMAL(11,0) 	NOT NULL,
    constraint adquire_CURSO_FK foreign key (idCurso)
    references CURSO(idCurso) on delete restrict on update restrict,
    constraint adquire_ALUNO_FK foreign key (cpfAluno)
    references ALUNO(cpfAluno) on delete restrict on update cascade
)ENGINE = InnoDB;

CREATE TABLE TURMA(
    idTurma  			INT 				NOT NULL AUTO_INCREMENT,
    turno 				ENUM('M','V','N') 	NOT NULL,
    horarioInicioAula 	TIME 				NOT NULL,
    horarioFimAula		TIME 				NOT NULL,
    idCurso 			INT 				NOT NULL,
    constraint TURMA_PK primary key(idTurma),
    constraint TURMA_CURSO_FK foreign key(idCurso)
    references CURSO(idCurso) on delete cascade on update cascade,
    constraint TURMA_horarioFimAula_CK check(horarioFimAula > horarioInicioAula)
)ENGINE = InnoDb AUTO_INCREMENT 1;

CREATE TABLE diaAula(
    idTurma INT 											NOT NULL,
    diaAula ENUM('SEG','TER','QUA','QUI','SEX','SAB','DOM') NOT NULL,
    constraint diaAula_TURMA_FK foreign key(idTurma)
    references TURMA(idTurma) on delete cascade on update cascade
)ENGINE = InnoDb;

CREATE TABLE INSCRICAO(
    idInscricao INT 			    NOT NULL AUTO_INCREMENT,
    situacao 	ENUM('A','AN','R') 	NOT NULL,
    quantFaltas INT				    DEFAULT 0,
    dtInscricao DATE 			    NOT NULL,
    cpfAluno 	DECIMAL(11,0) 	    NOT NULL,
    idTurma 	INT 			    NOT NULL,
    constraint INSCRICAO_PK primary key(idInscricao),
    constraint INSCRICAO_ALUNO_FK foreign key(cpfAluno)
    references ALUNO(cpfAluno) on delete cascade on update cascade,
    constraint INSCRICAO_TURMA_FK foreign key(idTurma)
    references TURMA(idTurma) on delete restrict on update cascade,
    constraint INSCRICAO_cpfAluno_idTurma_UK unique key(cpfAluno, idTurma),
    constraint INSCRICAO_quantFaltas_CK check (quantFaltas >= 0)
)ENGINE = InnoDb AUTO_INCREMENT 1;

CREATE TABLE CERTIFICADO (
    idCertificado 	INT 	NOT NULL AUTO_INCREMENT,
    dtCertificado 	DATE 	NOT NULL,
    idInscricao 	INT 	NOT NULL,
    constraint CERTIFICADO_PK primary key (idCertificado),
    constraint CERTIFICADO_INSCRICAO_FK foreign key (idInscricao)
    references INSCRICAO(idInscricao) on delete restrict on update restrict,
    constraint CERTIFICADO_idInscricao_UK unique key(idInscricao)
)ENGINE = InnoDB AUTO_INCREMENT 1;

CREATE TABLE estoca (
    idLoja 		INT 	NOT NULL,
    idProduto 	INT 	NOT NULL,
    dtEntrada	DATE 	NOT NULL,
    quantidade  INT 	NOT NULL,
    constraint estoca_LOJA_FK foreign key (idLoja)
    references LOJA(idLoja) on delete cascade on update cascade,
    constraint estoca_PRODUTO_FK foreign key (idProduto)
    references PRODUTO(idProduto) on delete restrict on update cascade,
    constraint estoca_quantidade_CK check (quantidade > 0)
)ENGINE = InnoDB;

CREATE TABLE prescrito_em (
    idReceita           INT         NOT NULL,
    idProduto           INT         NOT NULL,
    frequencia 			VARCHAR(30)			,
    quantComprimidos 	INT					,
    constraint prescrito_em_RECEITA_FK foreign key (idReceita)
    references RECEITA(idReceita) on delete cascade on update cascade,
    constraint prescrito_em_PRODUTO_FK foreign key (idProduto)
    references PRODUTO(idProduto) on delete restrict on update restrict,
    constraint prescrito_em_quantComprimidos_CK check (quantComprimidos > 0)
)ENGINE = InnoDB;