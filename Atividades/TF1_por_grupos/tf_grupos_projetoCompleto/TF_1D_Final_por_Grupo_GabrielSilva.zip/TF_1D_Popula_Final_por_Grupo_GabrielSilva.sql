-- ---------------------   << TF_1D_GabrielSilva >>   ---------------------
--
--                         SCRIPT DE POPULA                                  
-- 
-- Data Criacao ...........: 30/08/2022
-- Autor(es) ..............: Guilherme Silva, Gabriel Cruz, Gabriel Silva e Eduardo Farias
-- Banco de Dados .........: MySQL 8.0
-- Banco de Dados(nome) ...: TF_1D_GabrielSilva
--
-- Ultimas Alteracoes
--   11/09/2022 => Alteração do nome da base de dados.
--              => Alteração de algumas tuplas por conta da modificação do script físico.
--              => Inclusão de tuplas em novas tabelas.
--   18/09/2022 => Alteração do nome da base de dados.
--              => Adição de mais 20 tuplas em PESSOA, mais 15 tuplas em PRODUTO e mais 5 tuplas nas outras tabelas.
--
-- PROJETO => 01 Base de Dados
--         => 32 Tabelas
--  	   => 05 Perfis
--         => 25 Usuários
-- 
-- --------------------------------------------------------------------------------------------
USE TF_1D_GabrielSilva;

-- Inserção das tuplas nas tabelas
INSERT INTO PESSOA (cpf, nome, numeroTel,ddd,estado,cidade,bairro,rua,numero,complemento,cep) VALUES
    (63325791026, 'Pedro Alves Da Fonseca',999999998,61,'DF','Brasilia','Taguatinga Norte','Qnl 21 Cojunto H',14,'casa',72610410),
    (25878720140, 'Giulia Miranda da Silva',999999997,62,'GO','Acreúna','Setor Central','Rua Rosa Guimarães 52-B',4,'Apartamento',75960970),
    (04175079173, 'Alberto José Macedo',999999996,61,'DF','Brasilia','Sobradinho','Quadra 5 Área Especial 05',17,'casa',73031574),
    (61360811052, 'Marcus Henrique Luiz',999997998,61,'DF','Brasilia','Asa Norte','Quadra SQN 313 Bloco A',4,'Apartamento',70766010),
    (08574130659, 'João Pedro Silva', 995465287,61,'DF','Brasilia','Taguatinga Norte','Quadra QNM 40 Conjunto P',5,'casa',72146016),
    (75814966190, 'Michael Silva de Jesus',999999988,62,'GO','Planaltina','Setor Leste',' Quadra 4',18,'casa',73752040),
    (75462447817, 'Henrique Dourado ',999959998,18,'SP','Assis','Residencial Esmeralda Park','Rua das Pérolas',1,'casa',19808070),
    (08945925164, 'Gabriel Barbosa Pereira', 997891251, 62, 'GO', 'Goiania', 'São Sebastião', 'Avenida Castanhal', 12, NULL, 74852369),
    (08416511516, 'Juliana Alves de Sá', 997451265, 61, 'DF', 'Brasília', 'Águas Claras', 'Avenida dos Cocais', 205, 'Residencial Jundiaí', 78452136),
    (09161513546, 'Maria Silva da Conceição', 999521452, 61, 'DF', 'Brasília', 'Gama', 'Leste', 13, NULL, 78451263),
    (05468454354, 'João Pereira Santana', 998524632, 61, 'DF', 'Brasília', 'Águas Claras', 'Praça Tuím', 203, 'Residencial Jandaia', 75968431),
    (09543138645, 'Theo Nascimento Lima', 997853256, 61, 'DF', 'Brasília', 'Vicente Pires', 'Rua 10', 164, 'Casa 25', 72145369),
    (05487268743, 'Juliano Martins', 998453498, 61, 'DF', 'Brasília', 'Vicentee Pires', 'Rua 6', 34, 'Casa 7', 75846513),
    (09687418726, 'Antônio Lima Saldanha', 997627542, 14, 'SP', 'São Paulo', 'Campinas', 'Rua Jacobi Silva', 74, NULL, 98456147),
    (06736872872, 'Julia Marinho e Silva', 997414562, 61, 'DF', 'Brasília', 'Guará', 'Avenida Príncipe Augusto', 878, NULL, 72458963),
    (04613487822, 'Victor Leão Moreira', 998653145, 61, 'DF', 'Brasília', 'Vicente Pires', 'Rua 8', 205, 'Casa 17', 72145362),
    (01038736821, 'Camila Goss Pereira', 998745146, 61, 'DF', 'Brasília', 'Taguatinga Norte', 'QNL 9 Conjunto E', 14, NULL, 72145879),
    (01462689723, 'Vinícius Assumpção de Araújo', 999859549, 61, 'DF', 'Brasília', 'Vicente Pires', 'Rua 5', 167, 'Casa 1', 72222544),
    (08656426541, 'Pedro Henrique Brito', 998765477, 62, 'GO', 'Águas Lindas', 'Girassol', 'Rua 74', 74, NULL, 74145444),
    (03232891452, 'Tânia Cláudia Amorim', 998624437, 61, 'DF', 'Brasília', 'Ceilândia', 'QNO', 2, 'Loja 1', 72145874),

    (07204197518, 'Cauê Samuel Almeida', 994642465, 83, 'PB', 'João Pessoa', 'Mangabeira', 'Rua José Joaquim da Silva', 867, NULL, 58058310),
    (08581130747, 'Gustavo Erick Osvaldo', 996261414, 21, 'RJ', 'Rio de Janeiro', 'Campo Grande', 'Rua Domingos Alves', 959,'Loja 2', 23040750),
    (05751619102, 'Francisco Alexandre Gomes', 986272876, 95, 'RR', 'Boa Vista', 'Olímpico', 'Rua JT-14', 504, NULL, 69313283),
    (01760936048, 'Luna, Sônia Pinto', 997137168, 83, 'PB', 'João Pessoa', 'Mangabeira', 'Rua Jeferson de Paiva', 798, NULL, 58058190),
    (07690670024, 'Clarice Jennifer Aragão', 999859522, 27, 'ES', 'Serra', 'Nossa Senhora da Conceição', 'Beco Queiroz', 139, NULL, 29176544),

    (09731475143, 'Nelson Luís Melo', 985265292, 28, 'ES', 'Cachoeiro de Itapemirim', 'Ferroviários', 'Escadaria Manoel Braga', 775, NULL, 29308025),
    (01426984502, 'Rita Aurora Figueiredo', 996173587, 21, 'RJ', 'Teresópolis', 'Carlos Guinle', 'Rua Olegário Mariano', 927, NULL, 25958343),
    (02955909777, 'Sophia Adriana Corte Real', 981549794, 84, 'RN', 'Natal', 'Potengi', 'Avenida Itapetinga', 105, NULL, 59124400),
    (09429337815, 'Gabrielly Francisca Fátima', 983636084, 83, 'PB', 'João Pessoa', 'Oitizeiro', 'Avenida Coronel Felipe', 198, NULL, 58088620),
    (04747015388, 'Bernardo Mário Caldeira', 982920489, 84, 'RN', 'Natal', 'Pitimbu', 'Travessa Xavantes', 600, NULL, 59067602),

    (00583353827, 'Carlos Eduardo Miguel Araújo', 985703704, 21, 'RJ', 'Nova Iguaçu', 'Boa Esperança', 'Rua Peroba', 107, NULL, 26070063),
    (07848825523, 'Pedro Calebe dos Santos', 997641996, 47, 'SC', 'Joinville', 'Fátima', 'Rua Begônias', 112, NULL, 89229160),
    (05170901631, 'Gael Caio Assis', 993727521, 27, 'ES', 'São Mateus', 'Bom Jesus', 'Rua Brasília', 257, NULL, 29944100),
    (05063856390, 'Rayssa Tânia Fogaça', 989534719, 14, 'SP', 'Bauru', 'Parque Jardim Araruna', 'Rua Modesto Sanchi', 197, NULL, 17025130),
    (08651143290, 'Mariane Alice Gonçalves', 982160120, 91, 'PA', 'Bélem', 'Marco', 'Passagem Carmem', 456, NULL, 66093520),

    (01095229788, 'Luís Manoel da Cruz', 986524662, 98, 'MA', 'Imperatriz', 'Jardim Andrea', 'Rua São Lázaro', 995, NULL, 65914815),
    (06287421061, 'Elaine Bianca Nogueira', 997301791, 83, 'PB', 'João Pessoa', 'Trincheiras', 'Rua Maria de Fátima', 467, NULL, 58011332),
    (07460577600, 'Letícia Marli Fernandes', 986135276, 92, 'AM', 'Manaus', 'Nossa Senhora das Graças', 'Avenida Rio Pauini', 599, NULL, 69053570),
    (02862434035, 'Guilherme Levi Bernardes', 989381727, 96, 'AP', 'Santana', 'Provedor I', 'Travessa Sílvio Camilo', 640, NULL, 68927227),
    (05892638030, 'Lúcia Fátima Nunes', 995537610, 63, 'TO', 'Araguaína', 'Setor Bela Vista', 'Rua Miranorte', 878, NULL, 77825018);

INSERT INTO PACIENTE (cpfPaciente, rg, profissao, grupoSanguineo, fatorRh, alergia, email, estadoCivil, dtNasc) VALUES
    (04613487822, 3315748, 'Comerciante', 'O', '+', 'Não possui', 'vitinho@gmail.com', 'Casado', '2002-12-12'),
    (01038736821, 3451748, 'Faxineira', 'B', '-', 'Alergia a camarão', 'camila123@gmail.com', 'Solteira', '2002-09-09'),
    (01462689723, 3698574, 'Bancário', 'AB', '+', 'Alergia a ovo', 'viniboy@gmail.com', 'Solteiro', '2001-04-04'),
    (08656426541, 3562478, 'Garçom', 'B', '+', 'Não possui', 'pedrinho@outlook.com', 'Casado', '1998-07-07'),
    (03232891452, 3589647, 'Secretária', 'O', '-', 'Alergia a laticínios', 'tania2323@hotmail.com', 'Casada', '1987-06-06'),
    
    (07204197518, 5146844, 'Padeiro', 'O', '-', 'Alergia a frutos do mar e soja', 'cauezinho@outlook.com', 'Solteiro', '1950-06-14'),
    (08581130747, 4187622, 'Medico', 'A', '+', 'Alergia a amendoim', 'gustavoerick@gmail.com', 'Casado', '1946-08-08'),
    (05751619102, 6278716, 'Professor', 'AB', '+', 'Alergia a poeira', 'chicogomes@gmail.com', 'Viúvo', '1965-04-04'),
    (01760936048, 5676827, 'Bancaria', 'B', '-', 'Não possui', 'lunasonia@hotmail.com', 'Casada', '1971-05-17'),
    (07690670024, 3467754, 'Faxineira', 'O', '+', 'Não possui', 'claricearagao@hotmail.com', 'Solteira', '1980-08-06');

INSERT INTO TERAPEUTA (cpfTerapeuta,dtContratacao, matriculaTerapeuta) VALUES
    (05468454354,'2015-12-23', 1212),
    (09543138645,'2021-03-03', 1313),
    (05487268743,'2017-11-12', 1414),
    (09687418726,'2019-11-21', 1515),
    (06736872872,'2014-04-17', 1616),

    (09731475143,'2020-02-17', 1717),
    (01426984502,'2022-06-06', 1818),
    (02955909777,'2019-04-19', 1919),
    (09429337815,'2021-02-19', 2020),
    (04747015388,'2022-05-05', 2121);

INSERT INTO ALUNO (cpfAluno,matriculaAluno) VALUES
    (63325791026, 11),
    (25878720140, 12),
    (04175079173, 13),
    (61360811052, 14),
    (08574130659, 15),
    
    (00583353827, 16),
    (07848825523, 17),
    (05170901631, 18),
    (05063856390, 19),
    (08651143290, 20);
    
INSERT INTO CLIENTE (cpfCliente,dtCadastro) VALUES
    (75814966190,'2017-12-23'),
    (75462447817,'2020-04-05'),
    (08945925164,'2019-11-13'),
    (08416511516,'2019-05-22'),
    (09161513546,'2018-03-11'),
    
    (01095229788,'2017-05-05'),
    (06287421061,'2022-02-28'),
    (07460577600,'2022-03-06'),
    (02862434035,'2021-05-29'),
    (05892638030,'2022-08-17');

INSERT INTO LOJA (estado, cidade, bairro, rua, numero, complemento, cep) VALUES
    ('DF', 'Brasília', 'Águas Claras', 'Avenida dos Cocais', 12, '23', 72456789),
    ('DF', 'Brasília', 'Vicente Pires', 'Rua 7', 204, 'Lote 2', 72145698),
    ('DF', 'Brasília', 'Vicente Pires', 'Rua 10', 111, 'Lote 1', 71111111),
    ('GO', 'Goiânia', 'Município de Lourdes', 'Avenida São João', 24, NULL, 87456123),
    ('DF', 'Brasília', 'Gama', 'Avenida Central', 456, NULL, 72145896),
    
    ('RR', 'Boa Vista', 'Jardim Primavera', 'Rua Centauro', 245, NULL, 69314222),
    ('AL', 'Palmeira dos Índios', 'Vila Maria', 'Rua Antônio Gaudino', 956, NULL, 57607610),
    ('TO', 'Gurupi', 'Parque Nova Fronteira', 'Rua 75', 447, NULL, 77415630),
    ('SP', 'Amparo', 'Chácara Flor da Porcelana', 'Rua João Baseio', 286, NULL, 13908532),
    ('RN', 'Parnamirim', 'Jardim Planalto', 'Rua Navajo', 577, NULL, 59155250);

INSERT INTO COMPRA (dtCompra, horaCompra, cpfCliente, idLoja, formaPag, desconto) VALUES
    ('2022-05-05', '05:05:05', 75814966190, 1, 'P', NULL),
    ('2021-01-01', '15:15:15', 75462447817, 2, 'D', NULL),
    ('2022-02-02', '14:14:14', 08945925164, 3, 'TB', 10.00),
    ('2020-08-08', '08:08:08', 08416511516, 4, 'CC', 15.00),
    ('2021-03-13', '13:13:13', 09161513546, 5, 'CD', NULL),
    
    ('2022-05-08', '12:12:12', 01095229788, 6, 'P', 5.00),
    ('2021-12-14', '11:11:11', 06287421061, 7, 'CD', NULL),
    ('2021-12-12', '09:09:09', 07460577600, 8, 'CC', NULL),
    ('2019-04-04', '16:16:16', 02862434035, 9, 'D', 8.00),
    ('2020-05-19', '17:17:17', 05892638030, 10, 'TB', NULL);

INSERT INTO FORMULARIO (cpfPaciente) VALUES
    (04613487822),
    (01038736821),
    (01462689723),
    (08656426541),
    (03232891452),
    
    (07204197518),
    (08581130747),
    (05751619102),
    (01760936048),
    (07690670024);

INSERT INTO queixa VALUES 
    (1, 'Dor de cabeça'),
    (2, 'Dor na perna esquerda'),
    (3, 'Dor na perna direita'),
    (4, 'Dor abdominal'),
    (5, 'Dor no pulso direito'),
    (6, 'Dor de cabeça'),
    (7, 'Congestão nasal'),
    (8, 'Insônia'),
    (9, 'Dificuldade de caminhar'),
    (10, 'Enxaqueca');

   INSERT INTO PRODUTO (nome,precoCusto,precoVenda,tipoproduto) VALUES
    ('Aroma Brasil 100 ml',60.35,95.00,'LO'),
    ('Sabonete Erva Doce 300 ml',118.62,165.00,'LO'),
    ('Bambu Intenso 1 litro',79.30,130.00,'LO'),
    ('Sabonete Detox 120 g',36.99,47.00,'LO'),
    ('Coconut 120 ml',36.99,46.00,'LO'),
    ('Aroma Brasil 500 ml', 150.00, 225.00, 'LO'),
    ('Souvie 14ml', 80.00, 118.75, 'LO'),
    ('Essencia Vegan 20g', 9.99, 19.99, 'LO'),
    ('Arte dos Aromas 50g', 21.50, 49.90, 'LO'),
    ('Aging Organico 100ml', 259.99, 412.18, 'LO'),

    ('Extrato de Mutamba 300 mg',36.99,46.00,'FITO'),
    ('Ritmoneuran 120 ml',51.97,70.00,'FITO'),
    ('Emagremax 100 ml', 38.70, 53.90, 'FITO'),
    ('Calman 120 mg', 12.76, 32.99, 'FITO'),
    ('Fitovital 50 ml', 17.67, 29.99, 'FITO'),
    ('Nuubu Cleansing 100ml', 49.99, 97.00, 'FITO'),
    ('Nature Bounty 400mg', 25.99, 49.28, 'FITO'),
    ('MaxCognil 60ml', 30.00, 46.66, 'FITO'),
    ('Santa Maria 100ml', 25.00, 40.70, 'FITO'),
    ('EmagreMAX 820mg', 70.00, 99.00, 'FITO'),

    ('Ion Quantic 240 mg', 14.76, 31.98, 'FQ'),
    ('Bio Quantic 130 ml', 23.76, 45.99, 'FQ'),
    ('Biofactor 1 litro', 113.75, 241.99, 'FQ'),
    ('Ion Quantic 350 mg', 12.12, 27.74, 'FQ'),
    ('Fisiotox Quantic 750 ml', 211.11, 323.54, 'FQ'),
    ('Fito Quantic 50ml', 35.00, 55.00, 'FQ'),
    ('Bio Quantic 70ml', 61.99, 73.00, 'FQ'),
    ('Biofactor 100ml', 71.00, 85.70, 'FQ'),
    ('FisioQuantic 50ml', 39.00, 57.00, 'FQ'),
    ('Biofactor 50ml', 34.99, 68.00, 'FQ');
   
  INSERT INTO FLORAL_QUANTICO (funcionalidade,nomeElemento,frequenciaElemento, idProduto) VALUES
    ('Essência Vibracional','Neurovit','Pouco Frequente', 21),
    ('Equilíbrio energético','Centralis','Frequente', 22),
    ('Equilíbrio energético','Quellanthus','Pouco Frequente', 23),
    ('Harmonizador','Neutrinicusflower','Pouco Frequente', 24),
    ('Essência Vibracional','Filtralis','Muito Frequente', 25),
    ('Essência Vibracional', 'Calmallis', 'Pouco Frequente', 26),
    ('Neutralizador', 'Mentalis', 'Pouco Frequente', 27),
    ('Equilíbrio energético', 'MemoX', 'Muito Frequente', 28),
    ('Essência Vibracional', 'Amplivit', 'Pouco Frequente', 29),
    ('Digestão', 'Digeris', 'Muito Frequente', 30);
  
  INSERT INTO LINHA_ORGANICA (dsProdOrganico, idProduto) VALUES
    ('Shampoo', 1),
    ('Sabonete líquido', 2),
    ('Condicionador', 3),
    ('Sabonete em Barra', 4),
    ('Hidratante Corporal', 5),
    ('Shampoo', 6),
    ('Loção para Rosto', 7),
    ('Hidratante Facial', 8),
    ('Hidratante Facial', 9),
    ('Soro Antirrugas', 10);
  
  INSERT INTO FITOTERAPICO (dsFitoterapico, idProduto) VALUES
    ('Cimicifuga', 11),
    ('Gengibre', 12),
    ('Kava-kava', 13),
    ('Equinácea', 14),
    ('Valeriana', 15),
    ('Adesivos de desintoxicação', 16),
    ('Cápsulas para resfriado', 17),
    ('Composto para cognição', 18),
    ('Tintura de Erva', 19),
    ('Suplemento Alimentar', 20);

INSERT INTO possui VALUES 
    (1, 1, 3),
    (2, 2, 1),
    (3, 3, 4),
    (4, 4, 5),
    (5, 5, 6),
    (6, 6, 10),
    (7, 7, 4),
    (8, 8, 3),
    (9, 9, 12),
    (10, 10, 7);
                        
INSERT INTO FICHA_SESSOES (quantSessoes, cpfPaciente) VALUES 
    (2, 04613487822),
    (3, 01038736821),
    (3, 01462689723),
    (4, 08656426541),
    (5, 03232891452),
    (3, 07204197518),
    (4, 08581130747),
    (1, 05751619102),
    (2, 01760936048),
    (3, 07690670024);

INSERT INTO PROCEDIMENTO (dsProcedimento, valor) VALUES 
    ('Reiki', 200.00),
    ('Barra de Access', 150.00),
    ('Cristais', 350.00),
    ('Acupuntura', 180.00),
    ('Fitoterapia', 250.00),
    
    ('Apiterapia', 170.00),
    ('Terapia de florais', 230.00),
    ('Terapia bioenergética', 190.00),
    ('Aromaterapia', 210.00),
    ('Ozonioterapia', 270.00);

INSERT INTO ORGAO(nomeOrgao) VALUES
    ('Fígado'),
    ('Coração'),
    ('Rins'),
    ('Estômago'),
    ('Intestino Grosso'),

    ('Pulmão'),
    ('Pâncreas'),
    ('Faringe'),
    ('Intestino Delgado'),
    ('Laringe');

INSERT INTO afeta VALUES
    (1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5),
    (6, 6),
    (7, 7),
    (8, 8),
    (9, 9),
    (10, 10);

INSERT INTO CURSO(cargaHoraria,idProcedimento, preco) VALUES
    (70, 1, 400.00),
    (90, 2, 350.00),
    (60, 3, 370.00),
    (30, 4, 550.00),
    (80, 5, 280.00),
    (40, 6, 310.00),
    (55, 7, 300.00),
    (47, 8, 290.00),
    (85, 9, 550.00),
    (62, 10, 360.00);
  
INSERT INTO CONSULTA (dtConsulta, horaConsulta, idProcedimento, cpfPaciente, cpfTerapeuta, numSessao, valorConsulta, desconto, formaPag) VALUES 
    ('2022-02-02', '08:08:08', 1, 04613487822, 05468454354, 1, 120.00, NULL, 'P'),
    ('2022-03-03', '13:13:13', 2, 01038736821, 09543138645, 1, 100.00, NULL, 'D'),
    ('2022-04-04', '14:14:14', 3, 01462689723, 05487268743, NULL, 110.00, NULL, 'CD'),
    ('2022-05-05', '15:15:15', 4, 08656426541, 09687418726, 3, 170.00, 40.00, 'TB'),
    ('2022-06-06', '16:16:16', 5, 03232891452, 06736872872, 2, 210.00, NULL, 'CC'),
    
    ('2022-07-07', '11:11:11', 6, 07204197518, 09731475143, NULL, 230.00, NULL, 'P'),
    ('2022-08-08', '10:10:10', 7, 08581130747, 01426984502, 2, 220.00, NULL, 'CC'),
    ('2022-09-09', '12:12:12', 8, 05751619102, 02955909777, 3, 180.00, 30.00, 'D'),
    ('2021-10-10', '09:09:09', 9, 01760936048, 09429337815, 4, 170.00, 20.00, 'D'),
    ('2021-11-11', '17:17:17', 10, 07690670024, 04747015388, NULL, 165.00, NULL, 'TB');

   INSERT INTO RELATORIO (dtRetorno,orientacao,acompanhamento,idConsulta) VALUES
    ('2022-09-30', 'Não tomar bebidas energéticas', 'durante 20 dias', 1),
    ('2022-07-30', 'Fazer exercicios físicos', '1 vez por semana', 2),
    ('2022-05-10', 'Fazer exercicios físicos', '1 vez a cada 2 dias', 3),
    ('2022-10-09', 'Fazer sessões de detox', '1 vez por mês', 4),
    ('2022-10-08', 'Fazer sessões de detox', '1 vez semana', 5),
    
    ('2022-08-07', 'Não consumir cafeína', 'durante 15 dias', 6),
    ('2022-08-30', 'Fazer caminhada', '2 vezes por semana', 7),
    ('2022-09-18', 'Fazer terapia energética', '2 vezes por mês', 8),
    ('2021-11-10', 'Não tomar bebida alcoólica', 'durante 21 dias', 9),
    ('2021-12-11', 'Fazer sessões de detox', '2 vezes por semana', 10);

INSERT INTO melhora VALUES 
    (1, 'Melhora na dor de cabeça'),
    (2, 'Melhora da qualidade do sono'),
    (3, 'Melhora na parte respiratória'),
    (4, 'Melhora na dor nas costas'),
    (5, 'Melhora da dor abdominal'),
    (6, 'Melhora na insônia'),
    (7, 'Melhora na digestão'),
    (8, 'Melhora na dor nos pés'),
    (9, 'Melhora na disposição'),
    (10, 'Melhora no rendimento no trabalho');

   INSERT INTO RECEITA (dtReceita,horaReceita,idConsulta) VALUES
    ('2022-08-11', '12:30:00', 1),
    ('2022-05-30', '13:05:00', 2),
    ('2022-08-24', '17:00:00', 3),
    ('2022-07-27', '19:05:00', 4),
    ('2022-05-02', '13:05:00', 5),
    ('2022-07-07', '11:30:00', 6),
    ('2022-08-08', '10:30:00', 7),
    ('2022-09-09', '12:30:00', 8),
    ('2021-10-10', '09:25:25', 9),
    ('2021-11-11', '17:35:35', 10);

INSERT INTO esta_contido VALUES 
    (1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5),
    (6, 6),
    (7, 7),
    (8, 8),
    (9, 9),
    (10, 10);

INSERT INTO leciona VALUES 
    (05468454354, 1), 
    (09543138645, 2),
    (09543138645, 3),
    (09687418726, 4),
    (06736872872, 5),
    (09731475143, 6),
    (09731475143, 7),
    (01426984502, 8),
    (02955909777, 9),
    (04747015388, 10);

INSERT INTO adquire VALUES 
    (1, 63325791026),
    (2, 25878720140),
    (3, 04175079173),
    (4, 61360811052),
    (5, 08574130659),
    (6, 00583353827),
    (1, 00583353827),
    (3, 05170901631),
    (3, 05063856390),
    (4, 08651143290);

INSERT INTO TURMA(turno, horarioInicioAula, horarioFimAula, idCurso) VALUES
    ('M', '07:00:00', '11:00:00', 1),
    ('M', '08:00:00', '09:00:00', 2),
    ('V', '14:00:00', '17:30:00', 3),
    ('V', '14:00:00', '17:30:00', 4),
    ('N', '19:30:00', '21:30:00', 5),
    ('M', '08:00:00', '11:30:00', 6),
    ('V', '14:30:00', '17:30:00', 7),
    ('M', '09:00:00', '11:15:00', 8),
    ('N', '18:30:00', '21:00:00', 9),
    ('N', '19:15:00', '21:35:00', 10);

INSERT INTO diaAula VALUES 
    (1, 'SEG'),
    (2, 'QUA'),
    (3, 'SEG'),
    (4, 'TER'),
    (5, 'QUI'),
    (6, 'TER'),
    (7, 'QUA'),
    (8, 'SEX'),
    (9, 'SEG'),
    (10, 'SEG');

INSERT INTO INSCRICAO(situacao, quantFaltas, dtInscricao, cpfAluno, idTurma) VALUES
    ('A', 2, '2022-08-08', 63325791026, 1),
    ('R', 7, '2021-05-05', 25878720140, 2),
    ('A', 0, '2022-03-03', 04175079173, 3),
    ('A', 1, '2022-02-02', 61360811052, 4),
    ('R', 9, '2022-01-07', 08574130659, 5),
    ('A', 2, '2022-04-04', 63325791026, 5),
    ('A', 1, '2022-03-03', 04175079173, 2),

    ('A', 0, '2021-02-02', 00583353827, 6),
    ('A', 1, '2022-02-14', 00583353827, 1),
    ('A', 2, '2022-03-05', 05170901631, 3),
    ('A', 3, '2022-01-18', 05063856390, 3),
    ('A', 1, '2022-05-16', 08651143290, 4);

 INSERT INTO CERTIFICADO(dtCertificado,idInscricao) VALUES
    ('2022-09-01', 1),
    ('2022-04-03', 3),
    ('2022-03-02', 4),
    ('2022-05-05', 6),
    ('2022-04-03', 7),
    ('2022-08-08', 8),
    ('2022-09-09', 9),
    ('2022-09-15', 10),
    ('2022-08-14', 11),
    ('2022-08-20', 12);

INSERT INTO estoca VALUES 
    (1, 1, '2022-02-02', 10),
    (2, 2, '2021-01-01', 15),
    (3, 3, '2022-04-04', 20),
    (4, 4, '2020-10-10', 5),
    (5, 5, '2021-09-09', 14),
    (6, 6, '2022-08-08', 10),
    (7, 7, '2022-05-10', 5),
    (8, 8, '2022-06-06', 2),
    (9, 9, '2022-06-18', 4),
    (10, 10, '2022-07-15', 8);

INSERT INTO prescrito_em VALUES 
    (1, 1,'3 vezes durante 12 horas',2),
    (2, 2,'1 vez por semana',3),
    (3, 3,'1 vez a cada 2 dias',1),
    (4, 4,'1 vez por semana',2),
    (5, 5,'1 vez por semana',1),
    (6, 6, NULL, NULL),
    (7, 7, '1 vez por dia', 3),
    (8, 8, '2 vezes por dia', 1),
    (9, 9, '1 vez a cada 8 horas', 2),
    (10, 10, '3 vezes por semana', 3);                       