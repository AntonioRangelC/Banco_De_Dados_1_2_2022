-- ---------------------   << TF_1D_GabrielSilva >>   ---------------------
--
--                         SCRIPT DE APAGA                                
-- 
-- Data Criacao ...........: 30/08/2022
-- Autor(es) ..............: Guilherme Silva, Gabriel Cruz, Gabriel Silva e Eduardo Farias
-- Banco de Dados .........: MySQL 8.0
-- Banco de Dados(nome) ...: TF_1D_GabrielSilva
--
-- Ultimas Alteracoes
--   11/09/2022 => Alteração do nome da base de dados.
--              => Inclusão de drop table de novas tabelas: INSCRICAO, melhora, TURMA e diaAula.
--              => Alteração de drop table se_inscreve para drop table adquire.
--  			=> Exclusão de drop table da tabela FORMA_PAG.
--   18/09/2022 => Alteração do nome da base de dados.
--              => Inclusão de drop table de novas tabelas: ORGAO e afeta.
--              => Inclusão de drop role e drop user.
--
-- PROJETO => 01 Base de Dados
--         => 32 Tabelas
--  	   => 05 Perfis
--         => 25 Usuários
-- 
-- --------------------------------------------------------------------------------------------
USE TF_1D_GabrielSilva;

-- Remoção de ROLE's
DROP ROLE 'professor';
DROP ROLE 'pesquisador';
DROP ROLE 'vendedor';
DROP ROLE 'funcionario';
DROP ROLE 'administrador';

-- Remoção de usuários
DROP USER HENRIQUE_CHAVEZ;
DROP USER Emanuel;
DROP USER CARLOS;
DROP USER erika;
DROP USER Cibele;

DROP USER Administrador;
DROP USER ASSISTENCIA;
DROP USER GOUDINHO;
DROP USER FOCOTERAPIA;
DROP USER ADM;

DROP USER Camilo;
DROP USER Vendedor1;
DROP USER lojareidotebori;
DROP USER Wesley;
DROP USER Antonia;

DROP USER Gabriel;
DROP USER Luis;
DROP USER Terapeuta;
DROP USER Funcionario2;
DROP USER Funcionario1;

DROP USER Prof_Ferreira;
DROP USER Eduardo;
DROP USER Guilherme;
DROP USER Professor2;
DROP USER Professor1;

-- Remoção das tabelas 
DROP TABLE prescrito_em;
DROP TABLE estoca;
DROP TABLE CERTIFICADO;
DROP TABLE INSCRICAO;
DROP TABLE diaAula;
DROP TABLE TURMA;
DROP TABLE adquire;
DROP TABLE leciona;
DROP TABLE esta_contido;
DROP TABLE RECEITA;
DROP TABLE melhora;
DROP TABLE RELATORIO;
DROP TABLE CONSULTA;
DROP TABLE CURSO;
DROP TABLE afeta;
DROP TABLE ORGAO;
DROP TABLE PROCEDIMENTO;
DROP TABLE FICHA_SESSOES;
DROP TABLE possui;
DROP TABLE LINHA_ORGANICA;
DROP TABLE FITOTERAPICO;
DROP TABLE FLORAL_QUANTICO;
DROP TABLE PRODUTO;
DROP TABLE queixa;
DROP TABLE FORMULARIO;
DROP TABLE COMPRA;
DROP TABLE LOJA;
DROP TABLE ALUNO;
DROP TABLE CLIENTE;
DROP TABLE TERAPEUTA;
DROP TABLE PACIENTE;
DROP TABLE PESSOA; 