-- ---------------------   << TF_1D_GabrielSilva >>   ---------------------
--
--                         SCRIPT DE CONTROLE                                
-- 
-- Data Criacao ...........: 11/09/2022
-- Autor(es) ..............: Guilherme Silva, Gabriel Cruz, Gabriel Silva e Eduardo Farias
-- Banco de Dados .........: MySQL 8.0
-- Banco de Dados(nome) ...: TF_1D_GabrielSilva
--
-- Ultimas Alterações
--   18/09/2022 => Alteração do nome da base de dados.
--   19/09/2022 => Adição de novas Roles e novos usúarios
--
-- PROJETO => 01 Base de Dados
--         => 32 Tabelas
-- 		   => 05 Perfis
--         => 25 Usuários
-- 
-- --------------------------------------------------------------------------------------------
USE TF_1D_GabrielSilva;

-- CRIANDO PERFIS --

-- Para realizar admnistração --

CREATE ROLE 'administrador';

--  Para professores controlares CURSO, TURMA,SITUACAO e certificados gerados --

CREATE ROLE 'professor';

-- Para pessoas somente pesquisarem o contéudo dentro das tabelas --

CREATE ROLE 'pesquisador';

-- Para Vendendores realizarem as atividades de venda da loja --

CREATE ROLE 'vendedor';

-- Para funcionários em geral dos 2 estabelecimentos(CURSO e LOJA)

CREATE ROLE 'funcionario';


-- GARANTINDO PREVILÉGIOS AOS PERFIS RESPECTIVOS --

-- Privilégios de Administrador --

GRANT ALL ON TF_1D_GabrielSilva.* TO 'administrador' WITH GRANT OPTION;

--Privilégios de Funcionário --

GRANT SHOW VIEW ON TF_1D_GabrielSilva.* TO 'funcionario';
GRANT INSERT ON TF_1D_GabrielSilva.PESSOA TO 'funcionario';
GRANT INSERT ON TF_1D_GabrielSilva.ALUNO TO 'funcionario';
GRANT INSERT ON TF_1D_GabrielSilva.CLIENTE TO 'funcionario';
GRANT INSERT ON TF_1D_GabrielSilva.TERAPEUTA TO 'funcionario';
GRANT INSERT ON TF_1D_GabrielSilva.PACIENTE TO 'funcionario';


-- Privilégios de Vendedor --

GRANT SELECT ON TF_1D1_gabrielsilva.PESSOA TO 'vendedor';
GRANT SELECT ON TF_1D1_gabrielsilva.PRODUTO TO 'vendedor';
GRANT SELECT ON TF_1D1_gabrielsilva.compra TO 'vendedor';
GRANT  SELECT ON TF_1D1_gabrielsilva.FLORAL_QUANTICO TO 'vendedor';
GRANT  SELECT ON TF_1D1_gabrielsilva.FITOTERAPICO TO 'vendedor';
GRANT  SELECT ON TF_1D1_gabrielsilva.LINHA_ORGANICA TO 'vendedor';

GRANT INSERT ON TF_1D1_gabrielsilva.PRODUTO TO 'vendedor';
GRANT INSERT ON TF_1D1_gabrielsilva.compra TO 'vendedor';
GRANT INSERT ON TF_1D1_gabrielsilva.FLORAL_QUANTICO TO 'vendedor';
GRANT INSERT ON TF_1D1_gabrielsilva.FITOTERAPICO TO 'vendedor';
GRANT INSERT ON TF_1D1_gabrielsilva.LINHA_ORGANICA TO 'vendedor';


GRANT ALTER ON TF_1D1_gabrielsilva.PRODUTO TO 'vendedor';
GRANT ALTER ON TF_1D1_gabrielsilva.compra TO 'vendedor';
GRANT ALTER ON TF_1D1_gabrielsilva.FLORAL_QUANTICO TO 'vendedor';
GRANT ALTER ON TF_1D1_gabrielsilva.FITOTERAPICO TO 'vendedor';
GRANT ALTER ON TF_1D1_gabrielsilva.LINHA_ORGANICA TO 'vendedor';

GRANT DELETE ON TF_1D1_gabrielsilva.PRODUTO TO 'vendedor';
GRANT DELETE ON TF_1D1_gabrielsilva.compra TO 'vendedor';
GRANT DELETE  ON TF_1D1_gabrielsilva.FLORAL_QUANTICO TO 'vendedor';
GRANT DELETE  ON TF_1D1_gabrielsilva.FITOTERAPICO TO 'vendedor';
GRANT DELETE  ON TF_1D1_gabrielsilva.LINHA_ORGANICA TO 'vendedor';


-- Privélegios de Vendedor na Turma e Curso --

GRANT SELECT ON TF_1D1_gabrielsilva.TURMA TO 'vendedor';
GRANT SELECT ON TF_1D1_gabrielsilva.CURSO TO 'vendedor';
GRANT ALTER ON TF_1D1_gabrielsilva.TURMA TO 'vendedor';
GRANT ALTER ON TF_1D1_gabrielsilva.CURSO TO 'vendedor';
GRANT DELETE ON TF_1D1_gabrielsilva.TURMA TO 'vendedor';
GRANT DELETE ON TF_1D1_gabrielsilva.CURSO TO 'vendedor';

-- Privélegios de Pesquisador de todas as tabelas --

GRANT SELECT ON TF_1D1_gabrielsilva.* TO 'pesquisador';


-- Privilégios de Professor
GRANT SELECT ON TF_1D1_gabrielsilva.TURMA TO 'professor';
GRANT SELECT ON TF_1D1_gabrielsilva.CURSO TO 'professor';
GRANT INSERT ON TF_1D1_gabrielsilva.TURMA TO 'professor';
GRANT INSERT ON TF_1D1_gabrielsilva.CURSO TO 'professor';
GRANT ALTER ON TF_1D1_gabrielsilva.TURMA TO 'professor';
GRANT ALTER ON TF_1D1_gabrielsilva.CURSO TO 'professor';
GRANT DELETE ON TF_1D1_gabrielsilva.TURMA TO 'professor';
GRANT DELETE ON TF_1D1_gabrielsilva.CURSO TO 'professor';



-- CRIANDO USUÁRIOS -- 

CREATE USER  Professor1 IDENTIFIED BY '1rosseforP321';
CREATE USER  Professor2 IDENTIFIED BY '2rosseforP321';
CREATE USER Guilherme IDENTIFIED BY 'emrehliuG';
CREATE USER Eduardo IDENTIFIED BY 'odraudE321';
CREATE USER Prof_Ferreira IDENTIFIED BY 'arierreF_forP321';

CREATE USER Funcionario1 IDENTIFIED BY '1oiranoicnuF';
CREATE USER Funcionario2 IDENTIFIED BY '2oiranoicnuF321';
CREATE USER Terapeuta IDENTIFIED BY 'atuepareT';
CREATE USER Luis IDENTIFIED BY 'siuL321';
CREATE USER Gabriel IDENTIFIED BY 'leirbaG321';

CREATE USER Antonia IDENTIFIED BY 'ainotna321';
CREATE USER Wesley IDENTIFIED BY 'yelsew321';
CREATE USER lojareidotebori IDENTIFIED BY 'irobetodierajol';
CREATE USER Vendedor1 IDENTIFIED BY '1rodedneV';
CREATE USER Camilo IDENTIFIED BY 'olimac';

CREATE USER Vandor IDENTIFIED BY 'RODNAV321';
CREATE USER ADM IDENTIFIED BY 'MDA321';
CREATE USER FOCOTERAPIA IDENTIFIED BY 'AIPARETOCOF321';
CREATE USER GOUDINHO IDENTIFIED BY 'OHNIDUOG321';
CREATE USER ASSITENCIA IDENTIFIED BY 'aicnetissa321';
CREATE USER Administrador IDENTIFIED BY 'nimda321';


CREATE USER Cibele IDENTIFIED BY 'elebic321';
CREATE USER erika IDENTIFIED BY 'akire';
CREATE USER CARLOS IDENTIFIED BY 'CARLOS321';
CREATE USER Emanuel IDENTIFIED BY 'LEUNAME321';
CREATE USER HENRIQUE_CHAVEZ IDENTIFIED BY 'ZEVAHC_EUQIRNEH';


-- Associando perfis a usuários --

GRANT 'administrador' TO Administrador;
GRANT 'administrador' TO ADM;
GRANT 'administrador' TO FOCOTERAPIA;
GRANT 'administrador' TO GOUDINHO;
GRANT 'administrador' TO ASSISTENCIA;


GRANT 'vendedor' TO Antonia;
GRANT 'vendedor' TO Wesley;
GRANT 'vendedor' TO lojareidotebori;
GRANT 'vendedor' TO Vendedor1;
GRANT 'vendedor' TO Camilo;


GRANT 'pesquisador' TO Cibele;
GRANT 'pesquisador' TO erika;
GRANT 'pesquisador' TO Emanuel;
GRANT 'pesquisador' TO CARLOS;
GRANT 'pesquisador' TO HENRIQUE_CHAVEZ;

GRANT 'funcionario' TO Funcionario1;
GRANT 'funcionario' TO Funcionario2;
GRANT 'funcionario' TO Terapeuta;
GRANT 'funcionario' TO Luis;
GRANT 'funcionario' TO Gabriel;

GRANT 'professor' TO Professor1;
GRANT 'professor' TO Professor2;
GRANT 'professor' TO Guilherme;
GRANT 'professor' TO Eduardo;
GRANT 'professor' TO Prof_Ferreira;

