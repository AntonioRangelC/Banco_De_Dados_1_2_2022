-- ---------------------   << Trabalho Final - Jogos de Mesa e Gastrobar (Tema 3)  >>   ---------------------
--
--                                   SCRIPT DE APAGA (DDL)                                   
-- 
-- Data Criacao ...........: 29/08/2022
-- Autor(es) ..............: Pablo Christianno Silva Guedes
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: TF3_Pablo
-- 
-- Ultimas Alterecoes
-- 			10/09/2022 => Trocando posicao do drop da tabela COMPRADOR e CLIENTE
-- 			17/09/2022 => Apagando o Drop da tabela PRECO
-- 
-- PROJETO => 01 Base de Dados
--         => 13 Tabelas
-- 		   => 02 Roles
-- 
-- --------------------------------------------------------------------------------------------

use TF3_Pablo;

DROP TABLE ALUGUEL;
DROP TABLE JOGO;
DROP TABLE CATEGORIA;
DROP TABLE ALUGAVEL;
DROP TABLE forma;
DROP TABLE INSUMO;
DROP TABLE LANCHE;
DROP TABLE compra;
DROP TABLE PRODUTO;
DROP TABLE CLIENTE;
DROP TABLE COMPRADOR;
DROP TABLE CLUB;
DROP TABLE CONTRATO;