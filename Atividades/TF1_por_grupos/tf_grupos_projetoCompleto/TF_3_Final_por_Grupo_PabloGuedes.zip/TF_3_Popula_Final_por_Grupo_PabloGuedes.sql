
-- ---------------------   << Trabalho Final - Jogos de Mesa e Gastrobar (Tema 3)  >>   ---------------------
--
--                                   SCRIPT DE POPULA (DML)                                   
-- 
-- Data Criacao ...........: 30/08/2022
-- Autor(es) ..............: Pablo Christianno Silva Guedes
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: TF3_Pablo
-- 
-- Ultimas Alterecoes
-- 			10/09/2022 => Adicionando valores a serem inseridos na tabela insumo
-- 					   => Corrigindo valor da chave estrangeira de comprador na tabela compra
-- 					   => Adicionando duplas na Tabela de comprador
-- 			17/09/2022 => Apagando iserções da tabela PRECO
--                     => Mudando tipo do dado que o atributo precoContrato recebe
--                     => Acrescentando novas tuplas de inserção em cada tabela
-- 
-- PROJETO => 01 Base de Dados
--         => 13 Tabelas
-- 		   => 02 Roles
-- 
-- --------------------------------------------------------------------------------------------

USE TF3_Pablo;


INSERT INTO CONTRATO (dataAss, tipoContrato, precoContrato) values
	('2022-05-20', 'S', 50.00),
    ('2021-07-01', 'C1', 100.00),
    ('2021-06-15', 'C1', 100.00),
    ('2022-08-30', 'C2', 150.00),
    ('2019-01-22', 'C2', 150.00),
    ('2019-02-16', 'C3', 200.00),
    ('2022-09-01', 'C2', 150.00),
    ('2022-09-02', 'C2', 150.00),
    ('2022-09-02', 'C1', 100.00),
    ('2022-09-05', 'S', 50.00);

INSERT INTO CLUB (numeroCartao, codigoContrato) values
		(654547859632102514, 2),
		(454654684684684684, 3),
        (445513254654651313, 4),
        (465465777894133467, 5),
        (888879431555467897, 6),
        (456465765421321434, 7),
        (454657651213127878, 8),
        (984532145132133444, 9),
        (121324468779978984, 10);
 
 INSERT INTO COMPRADOR (idComprador) values
	(1),
    (2),
    (3),
    (4),
    (5),
    (6),
    (7),
    (8),
    (9),
    (10);
    
 INSERT INTO CLIENTE (cpf, nome, dataNasc, bairro, rua, numero, email, telefone, contrato, comprador) values
	(07474255185, 'Maria Machado', '1990-10-20', 'Setor Leste', 'Rua Laranjeiras',15, 'Maria@gmail.com', 983149513, 1, 1),
    (07574154586, 'Felipe Luiz', '1991-09-15', 'Setor Norte', 'Rua dos Cristais', 16, 'Felipe@yahoo.com', 981456312, 2, 2),
    (07474855185, 'Cristiano Andretti', '1992-08-10', 'Setor Sul', 'Rua das Macieiras', 17, 'Cristiano@hotmail.com', 987856411, 3, 3),
    (07454830154, 'Ronaldo Macedo', '1993-09-05', 'Setor Oeste', 'Rua dos Papagaios', 18, 'Ronaldo@gmail.com', 985656417, 4, 4),
    (07355830453, 'Rafael Gonzaga', '2000-09-17', 'Setor Leste', 'Rua dos Afogados', 30, 'Rafael@hotmail.com', 981569414, 5, 5),
    (05132456768, 'Joana da Costa', '2001-01-11', 'Setor Leste', 'Rua dos Afogados', 04, 'Joana@hotmail.com', 982546574, 6, 6),
    (05789846878, 'João Neto', '1993-12-21', 'Setor Sul', 'Rua dos Ipês', 15, 'Jneto@hotmail.com', 983569284, 7, 7),
    (05987846513, 'Marta Silva Feliciano', '1999-11-07', 'Setor Oeste', 'Rua das Araras', 33, 'Marta@hotmail.com', 995563318, 8, 8),
    (05679431345, 'Marilha Turquesa', '1992-04-20', 'Setor Leste', 'Rua dos Afogados', 20, 'Turquesa@hotmail.com', 994169774, 9, 9),
    (05165465465, 'Higashi Toshiba', '2001-10-10', 'Setor Norte', 'Rua dos Cristais', 02, 'Htoshiba@hotmail.com', 984567488, 10, 10);
    

INSERT INTO PRODUTO (nomeProduto, qnt, preco, tipo) values
	('dado - d20', 40, 5.00, 'P'),
    ('Vingadores - Guerra Civíl', 2, 30.00, 'H'),
    ('Homem Aranha - Apocalípse', 1, 35.00, 'H'),
    ('Monopoly', 2, 150.00, 'J'),
    ('Dixit', 3, 200.00, 'J'),
    ('Hamburguer', 0, 20.00, 'L'),
    ('Batata Frita', 0, 10.00, 'L'),
    ('Sanduíche', 0, 20.00, 'L'),
    ('Suco de Laranja', 0, 8.00, 'L'),
    ('Caipirinha', 0, 20.00, 'L'),
    ('Caipiroska', 0, 20.00, 'L'),
    ('Sakerinha', 0, 20.00, 'L'),
    ('Coxinha', 0, 10.00, 'L'),
    ('milkshake', 0, 15.00, 'L'),
    ('bolo de chocolate', 0, 10.00, 'L'),
    ('Pegue em 6', 10, 50.00, 'J');
    
INSERT INTO compra (dataCompra, horaCompra, codigo, comprador) values
	('2022-03-10', '15:45:57', 1, 6),
    ('2022-04-20', '13:19:18', 6, 7),
    ('2022-04-30', '14:45:23', 7, 8),
    ('2022-05-11', '17:49:54', 8, 9),
    ('2022-08-23', '18:15:35', 8, 10);
    
INSERT INTO LANCHE (codigo) values
	(6),
    (7),
    (8),
    (9),
    (10),
    (11),
    (12),
    (13),
    (14),
    (15);

INSERT INTO INSUMO (nomeInsumo, qnt, dataEntrada, horaEntrada) values
	('Pão', 85, '2021-12-15', '18:15:35'),
    ('Queijo Paermesão', 200, '2022-07-20', '14:30:15'),
    ('Batata', 100, '2022-09-05', '09:45:09'),
    ('Laranja', 50, '2022-07-17', '20:01:30'),
    ('Limão', 60, '2021-07-11', '14:15:56'),
    ('Vodka', 20, '2022-07-30', '13:11:17'),
    ('Sake', 10, '2022-07-30', '13:12:30'),
    ('frango', 20, '2022-08-15', '15:15:02'),
    ('leite', 40, '2022-09-15', '11:15:17'),
    ('farinha', 30, '2022-09-15', '11:17:20');
    
INSERT INTO forma (insumo, lanche) values
	(1, 1),
    (2, 1),
    (1, 3),
    (3, 2),
    (4, 4),
    (5, 5),
    (6, 6),
    (7, 7),
    (8, 8),
    (10, 8),
    (9, 9),
    (9, 10),
    (10, 10);
    
INSERT INTO ALUGAVEL (copia, codigo, estado) values
	(1, 2, 'capa amassada'),
    (2, 2, 'Bom estado'),
    (1, 3, 'Bom estado'),
    (1, 4, 'Bom estado'),
    (2, 4, 'Bom estado'),
    (1, 5, 'Falta peça'),
    (2, 5, 'mapa com manchas'),
    (3, 5, 'Bom estado'),
    (1, 16, 'Bom estado'),
    (2, 16, 'Bom estado'),
    (3, 16, 'Bom estado'),
    (4, 16, 'Bom estado'),
    (5, 16, 'Bom estado'),
    (6, 16, 'falta peça'),
    (7, 16, 'Sem cartas'),
    (8, 16, 'Cartas manchadas'),
    (9, 16, 'inutilizável'),
    (10, 16, 'inutilizável');
    
INSERT INTO CATEGORIA (descricao, cor) values
	('Jogo comum de pequeno porte', 'azul'),
    ('Jogo comum de médio porte', 'amarelo'),
    ('Jogo raro ou de grande porte', 'dourado'),
    ('Não pode ser alugado', 'rosa'),
    ('pode ser vendido', 'verde'),
    ('Jogo lacrado', 'preto'),
    ('Edições antes de 2000', 'rosa'),
    ('Edição limitada', 'marrom'),
    ('Jogo de medio porte', 'cinza'),
    ('Não pode ser vendido', 'vermelho');
    
INSERT INTO JOGO (precoLocal, categoria, copia, codigo) values
	(50.00, 1, 1, 4),
    (50.00, 5, 2, 4),
    (30.00, 2, 1, 5),
    (30.00, 3, 2, 5),
    (30.00, 4, 3, 5),
    (20.00, 5, 1, 16),
    (20.00, 6, 2, 16),
    (20.00, 7, 3, 16),
    (20.00, 8, 4, 16),
    (20.00, 10, 5, 16);
    
INSERT INTO ALUGUEL (dataRetirada, dataDevolucao, cliente, copia, codigo) values
	('2022-04-30', '2022-05-06', 07474255185, 1, 4),
    ('2022-03-10', '2022-04-10', 07574154586, 2, 4),
    ('2022-04-25', '2022-05-25', 07474855185, 1, 5),
    ('2022-04-25', '2022-05-25', 07454830154, 2, 5),
    ('2022-07-28', '2022-08-28', 07355830453, 3, 5),
    ('2022-07-30', '2022-08-10', 05132456768, 1, 16),
    ('2022-08-05', '2022-08-12', 05789846878, 2, 16),
    ('2022-08-23', '2022-08-30', 05987846513, 3, 16),
    ('2022-09-02', '2022-08-09', 05679431345, 4, 16),
    ('2022-09-10', '2022-08-17', 05165465465, 5, 16);