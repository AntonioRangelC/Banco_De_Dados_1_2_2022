-- ---------------------   << Trabalho Final - Jogos de Mesa e Gastrobar (Tema 3)  >>   ---------------------
--
--                                   CONTROLE                                  
-- 
-- Data Criacao ...........: 11/09/2022
-- Autor(es) ..............: Pablo Christianno Silva Guedes
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: TF3_Pablo
-- 
-- Ultimas Alterecoes
-- 			17/09/2022 => Adicionando usuário e atribuindo seus perfis
-- 
-- PROJETO => 01 Base de Dados
--         => 13 Tabelas
-- 		   => 02 Roles
-- 
-- --------------------------------------------------------------------------------------------

use TF3_Pablo;

CREATE ROLE 'ADM';
GRANT ALL PRIVILEGES ON TF3_Pablo TO 'ADM'
	with grant option;

CREATE ROLE 'FUNCIONARIO';
GRANT SELECT, INSERT ON TF3_Pablo.COMPRADOR TO 'FUNCIONARIO';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF3_Pablo.CONTRATO TO 'FUNCIONARIO';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF3_Pablo.CLUB TO 'FUNCIONARIO';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF3_Pablo.CLIENTE TO 'FUNCIONARIO';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF3_Pablo.LANCHE TO 'FUNCIONARIO';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF3_Pablo.INSUMO TO 'FUNCIONARIO';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF3_Pablo.ALUGAVEL TO 'FUNCIONARIO';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF3_Pablo.JOGO TO 'FUNCIONARIO';
GRANT SELECT, INSERT(dataRetirada, dataDevolucao) ON TF3_Pablo.ALUGUEL TO 'FUNCIONARIO';

CREATE USER 'Charlon'
IDENTIFIED BY '2022Charlon';
GRANT 'ADM' to 'Charlon';

CREATE USER 'Carlos'
IDENTIFIED BY '2022Carlos';
GRANT 'ADM' to 'Carlos';

CREATE USER 'Maria'
IDENTIFIED BY '2022Maria';
GRANT 'FUNCIONARIO' to 'Maria';

CREATE USER 'Leandro'
IDENTIFIED BY '2022Leandro';
GRANT 'FUNCIONARIO' to 'Leandro';