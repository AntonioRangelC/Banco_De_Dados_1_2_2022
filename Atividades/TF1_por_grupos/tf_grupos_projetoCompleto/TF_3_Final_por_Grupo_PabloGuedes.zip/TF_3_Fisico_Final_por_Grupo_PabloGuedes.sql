-- ---------------------   << Trabalho Final - Jogos de Mesa e Gastrobar (Tema 3)  >>   ---------------------
--
--                                   SCRIPT DE CRIAÇÃO (DDL)                                   
-- 
-- Data Criacao ...........: 29/08/2022
-- Autor(es) ..............: Pablo Christianno Silva Guedes
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: TF3_Pablo
-- 
-- Ultimas Alterecoes
-- 			10/09/2022 => Adicionando chave estrangeira da tabela COMPRADOR na tabela CLIENTE
-- 					   => Trocando posicao da tabela COMPRADOR e CLIENTE
-- 	 				   => Adicionando dois atributos no relacionamento forma
-- 					   => Mudando o tipo de INT para BIGINT de todos atriibutos que estão com auto_increment
-- 					   => Adicionando integridade referencial à todas chaves estrangeiras
-- 			17/09/2022 => Apagando tabela PRECO
-- 					   => mudando tipo do atributo precoContrato na tabrla CONTRATO
-- 
-- PROJETO => 01 Base de Dados
--         => 13 Tabelas
-- 		   => 02 Roles
-- ------------------------------------------------------------------------------------------------------------
-- Base de Dados
CREATE DATABASE
	IF NOT EXISTS TF3_Pablo;

use TF3_Pablo;
-- Tabelas

CREATE TABLE COMPRADOR(
	idComprador		BIGINT		NOT NULL auto_increment,
    CONSTRAINT COMPRADOR_PK PRIMARY KEY(idComprador)
) ENGINE = InnoDB auto_increment = 1;

CREATE TABLE CONTRATO(
	codigoContrato		BIGINT			NOT	NULL	auto_increment,
    dataAss				DATE			NOT NULL,
    tipoContrato		VARCHAR(2) 		NOT NULL,
    precoContrato		DECIMAL(8,2)	NOT NULL,
    CONSTRAINT CONTRATO_PK PRIMARY KEY(codigoContrato)
) ENGINE = InnoDB auto_increment = 1;

CREATE TABLE CLUB(
	numeroCartao	BIGINT		NOT NULL,
	codigoContrato	BIGINT			NOT NULL,
    CONSTRAINT CLUB_CONTRATO_FK FOREIGN KEY(codigoContrato) REFERENCES CONTRATO(codigoContrato) on delete restrict on update restrict,
    CONSTRAINT CLUB_codigoContrato_UK UNIQUE KEY(codigoContrato)
) ENGINE = InnoDB;

CREATE TABLE CLIENTE(
	cpf				BIGINT 			NOT NULL,
    nome			VARCHAR(100) 	NOT NULL,
    dataNasc		DATE			NOT NULL,
    bairro			VARCHAR(40)		NOT NULL,
    rua				VARCHAR(40)		NOT NULL,
    numero			INT				NOT NULL,
    email			VARCHAR(100)	NOT NULL,
    telefone		BIGINT			NOT NULL,
    contrato		BIGINT			NOT NULL,
    comprador 		BIGINT			NOT NULL,
	CONSTRAINT CLIENTE_PK PRIMARY KEY(cpf),
    CONSTRAINT CLIENTE_COMPRADOR_FK FOREIGN KEY(comprador) references COMPRADOR(idComprador) on delete restrict on update restrict,
    CONSTRAINT CLIENTE_comprador_UK UNIQUE KEY(comprador)
) ENGINE = InnoDB;

CREATE TABLE PRODUTO(
	codigo			BIGINT 			NOT NULL auto_increment,
    nomeProduto		VARCHAR(200) 	NOT NULL,
    qnt				INT				NOT NULL,
    preco			DECIMAL(8,2)	NOT	NULL,
    tipo			VARCHAR(1)		NOT NULL,
    CONSTRAINT PRODUTO_PK PRIMARY KEY(codigo)
) ENGINE = InnoDB auto_increment = 1;

CREATE TABLE compra(
	dataCompra		DATE 	NOT NULL,
    horaCompra		TIME	NOT NULL,
    codigo			BIGINT	NOT NULL,
    comprador		BIGINT  NOT NULL,
    CONSTRAINT compra_PRODUTO_FK FOREIGN KEY(codigo) REFERENCES PRODUTO(codigo) on delete cascade on update cascade,
    CONSTRAINT compra_COMPRADOR_FK FOREIGN KEY(comprador) REFERENCES COMPRADOR(idComprador) on delete cascade on update cascade
) ENGINE = InnoDB;

-- Primeira especialização de produto
CREATE TABLE LANCHE(
	codigoLanche	BIGINT 	NOT NULL auto_increment,
    codigo			BIGINT 	NOT NULL,
    CONSTRAINT LANCHE_PK PRIMARY KEY(codigoLanche),
    CONSTRAINT LANCHE_PRODUTO_FK FOREIGN KEY(codigo) REFERENCES PRODUTO(codigo) on delete restrict on update cascade,
    CONSTRAINT LANCHE_codigo_UK	UNIQUE KEY(codigo)
) ENGINE = InnoDB auto_increment = 1;

CREATE TABLE INSUMO(
	idInsumo	BIGINT		NOT NULL auto_increment,
    nomeInsumo 	VARCHAR(50)		NOT NULL,
    qnt			INT 			NOT NULL,
    dataEntrada	DATE    NOT NULL,
    horaEntrada	TIME	NOT NULL,
    CONSTRAINT INSUMO_PK PRIMARY KEY(idInsumo)
) ENGINE = InnoDB auto_increment = 1;

CREATE TABLE forma(
	insumo		BIGINT		NOT NULL,
    lanche		BIGINT		NOT NULL,
    CONSTRAINT forma_INSUMO_FK FOREIGN KEY(insumo) REFERENCES INSUMO(idInsumo) on delete cascade on update cascade,
    CONSTRAINT forma_LANCHE_FK FOREIGN KEY(lanche) REFERENCES LANCHE(codigoLanche) on delete cascade on update cascade
) ENGINE = InnoDB;

-- Segunda especialização de produto
CREATE TABLE ALUGAVEL(
	copia	INT 			NOT NULL,
    codigo	BIGINT			NOT NULL,
    estado 	VARCHAR(100)	NOT	NULL,
    CONSTRAINT ALUGAVEL_PK	PRIMARY KEY(codigo, copia),
    CONSTRAINT ALUGAVEL_PRODUTO_FK FOREIGN KEY(codigo) REFERENCES PRODUTO(codigo) on delete restrict on update cascade
) ENGINE = InnoDB;

CREATE TABLE CATEGORIA(
	idCategoria		BIGINT			NOT NULL auto_increment,
    descricao		VARCHAR(30)	NOT NULL,
    cor				VARCHAR(10)	NOT NULL,
    CONSTRAINT CATEGORIA_PK PRIMARY KEY(idCategoria)
) ENGINE = InnoDB auto_increment = 1;

CREATE TABLE JOGO(
	precoLocal		DECIMAL(8,2)		NOT NULL,
    categoria		BIGINT 				NOT NULL,
    copia			INT					NOT NULL,
    codigo			BIGINT				NOT NULL,
    CONSTRAINT JOGO_CATEGORIA_FK FOREIGN KEY(categoria) REFERENCES CATEGORIA(idCategoria) on delete restrict on update cascade,
    CONSTRAINT JOGO_ALUGAVEL_FK FOREIGN KEY(codigo, copia) REFERENCES ALUGAVEL(codigo, copia) on delete restrict on update cascade,
    CONSTRAINT JOGO_codigo_copia_UK UNIQUE KEY(codigo, copia)
) ENGINE = InnoDB;

CREATE TABLE ALUGUEL(
	idAluguel 		BIGINT	NOT NULL auto_increment,
    dataRetirada	DATE	NOT NULL,
    dataDevolucao	DATE	NOT NULL,
    cliente			BIGINT	NOT NULL,
    codigo			BIGINT 	NOT NULL,
    copia			INT 	NOT NULL,
    CONSTRAINT ALUGUEL_PK PRIMARY KEY(idAluguel),
    CONSTRAINT ALUGUEL_CLIENTE_FK FOREIGN KEY(cliente) REFERENCES CLIENTE(cpf) on delete cascade on update cascade,
    CONSTRAINT ALUGUEL_ALUGAVEL_FK FOREIGN KEY(codigo, copia) REFERENCES ALUGAVEL(codigo, copia) on delete cascade on update cascade
) ENGINE = InnoDB auto_increment = 1;






