-- --------  Trabalho Final - Tema 2  ----------
--
--                    SCRIPT DE CONTROLE (DDL)
--
-- Data Criacao ...........: 10/09/2022
-- Autor(es) ..............: Jackes Tiago Ferreira da Fonseca, Karla Chaiane da Silva Feliciano e Lucas Gabriel Sousa Camargo Paiva
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_2B_KarlaFeliciano
-- 
-- Ultimas Alteracoes
--   18/09/2022 => Criação das ROLEs HOLDER, MAINTAINER e COMISSIONAIRE
--   18/09/2022 => Criação dos usuários dbAdmin, 
--
-- PROJETO => 01 Base de Dados
--         => 29 Tabelas
--
-- ---------------------------------------------------------

USE TF_2B_KarlaFeliciano;

CREATE ROLE HOLDER;
GRANT ALL PRIVILEGES ON  TF_2B_KarlaFeliciano. * TO HOLDER;

CREATE ROLE MAINTAINER;
GRANT SELECT ON TF_2B_KarlaFeliciano. * TO MAINTAINER;
GRANT INSERT ON TF_2B_KarlaFeliciano. * TO MAINTAINER;
GRANT DELETE ON TF_2B_KarlaFeliciano. * TO MAINTAINER;
GRANT UPDATE ON TF_2B_KarlaFeliciano. * TO MAINTAINER;

CREATE ROLE COMISSIONAIRE;
GRANT SELECT ON TF_2B_KarlaFeliciano.PROPOSTA  TO COMISSIONAIRE;
GRANT INSERT ON TF_2B_KarlaFeliciano.PROPOSTA  TO COMISSIONAIRE;
GRANT UPDATE ON TF_2B_KarlaFeliciano.PROPOSTA  TO COMISSIONAIRE;

CREATE USER 'dbAdmin'@'localhost' IDENTIFIED BY '2022DbAdmin';
GRANT HOLDER TO 'dbAdmin'@'localhost';

CREATE USER 'director'@'localhost' IDENTIFIED BY '2022Director';
GRANT MAINTAINER TO 'director'@'localhost';

CREATE USER 'comissionaire1'@'localhost' IDENTIFIED BY '1Comissionaire';
GRANT COMISSIONAIRE TO 'comissionaire1'@'localhost';

CREATE USER 'comissionaire2'@'localhost' IDENTIFIED BY '2Comissionaire';
GRANT COMISSIONAIRE TO 'comissionaire2'@'localhost';

FLUSH PRIVILEGES;