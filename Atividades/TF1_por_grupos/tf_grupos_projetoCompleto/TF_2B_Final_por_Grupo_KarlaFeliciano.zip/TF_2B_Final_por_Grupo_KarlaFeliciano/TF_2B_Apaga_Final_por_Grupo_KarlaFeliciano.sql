-- ---------------------   << Trabalho Final - Tema 2  >>   ---------------------
--
--                                   SCRIPT DE APAGA (DDL)                                   
-- 
-- Data Criacao ...........: 31/08/2022
-- Autor(es) ..............: Jackes Tiago Ferreira da Fonseca, Karla Chaiane da Silva Feliciano e Lucas Gabriel Sousa Camargo Paiva
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: TF_2B_KarlaFeliciano
--
-- Ultimas Alteracoes
--   18/09/2022 => Adição das tabelas DEPENDENTE, INFORMACOES_TRABALHISTAS, relacionado, fgts, inss, decimoTerceiro
--              => Alteração do nome da base de dados
-- 
-- PROJETO => 01 Base de Dados
--         => 29 Tabelas
-- 
-- --------------------------------------------------------------------------------------------

USE TF_2B_KarlaFeliciano;

DROP TABLE realiza;
DROP TABLE cursa;
DROP TABLE trabalha;
DROP TABLE gerencia;
DROP TABLE contem;
DROP TABLE possui;
DROP TABLE PAGAMENTO_SERVICO;
DROP TABLE PROJETO;
DROP TABLE CONTRATO;
DROP TABLE PROPOSTA;
DROP TABLE TIPO_SERVICO;
DROP TABLE MATERIAL;
DROP TABLE telefoneContratante;
DROP TABLE CONTRATANTE;
DROP TABLE PAGAMENTO_FUNCIONARIO;
DROP TABLE CONTA;
DROP TABLE CURSO;
DROP TABLE EXAME;
DROP TABLE FUNCIONARIO_OBRA;
DROP TABLE FUNCIONARIO_ESCRITORIO;
DROP TABLE telefoneFuncionario;
DROP TABLE relacionado;
DROP TABLE DEPENDENTE;
DROP TABLE decimoTerceiro;
DROP TABLE fgts;
DROP TABLE inss;
DROP TABLE FUNCIONARIO;
DROP TABLE INFORMACOES_TRABALHISTA;
DROP TABLE ENDERECO;