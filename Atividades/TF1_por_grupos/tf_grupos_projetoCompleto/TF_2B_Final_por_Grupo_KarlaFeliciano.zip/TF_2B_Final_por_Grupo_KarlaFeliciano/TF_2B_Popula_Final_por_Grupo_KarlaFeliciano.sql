-- ---------------------   << Trabalho Final - Tema 2 >>   ---------------------
--
--                                   SCRIPT DE POPULA (DML)                                   
-- 
-- Data Criacao ...........: 30/08/2022
-- Autor(es) ..............: Jackes Tiago Ferreira da Fonseca, Karla Chaiane da Silva Feliciano e Lucas Gabriel Sousa Camargo Paiva
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: TF_2B_KarlaFeliciano
-- 
-- Ultimas Alteracoes
--   10/09/2022 => Adição dos valores de juros e multa na tabela CONTRATO
--   17/09/2022 => Adição de mais 5 tuplas em cada tabela
--   18/09/2022 => Adição das tabelas DEPENDENTE, INFORMACOES_TRABALHISTAS, relacionado, fgts, inss, decimoTerceiro 
--              => Alteração do nome da base de dados
-- 
-- PROJETO => 01 Base de Dados
--         => 29 Tabelas
-- 
-- --------------------------------------------------------------------------------------------

USE TF_2B_KarlaFeliciano;

INSERT INTO ENDERECO
	(idEndereco, cep, numero, rua, bairro, cidade, estado, complemento)
VALUES    
	(1, 72640100, 09, 'avenida dos cocais', 'Gama', 'Brasília', 'DF', 'Quadra 02'),
    (2, 70652482, 14, 'ponte alta', 'Gama', 'Brasília', 'DF', 'Setor Central'),
    (3, 72642156, 02, 'M norte', 'Taguatinga', 'Brasília', 'DF', 'Qnn 14'),
    (4, 72555320, 17, 'W3-Sul', 'Asa Sul', 'Brasília', 'DF', 'Quadra 10'),
    (5, 71236598, 01, 'Avenida do Contorno', 'Ceilândia', 'Brasília', 'DF', 'Quadra 225'),
    (6, 79856562, 13, 'Via M1', 'Ceilandia', 'Brasília', 'DF', 'Qnn 19'),
    (7, 76495746, 13, 'Rua rural casa grande', 'Gama', 'Brasília', 'DF', 'Setor Central'),
    (8, 72640100, 12, 'Rua babaçu', 'Gama', 'Brasília', 'DF', 'EQ 15'),
    (9, 72636458, 07, 'Area especial', 'Gama', 'Brasília', 'DF', 'Quadra 20-21'),
    (10, 71235658, 06, 'Galeria Oeste', 'Asa norte', 'Brasília', 'DF', 'CLN 102'),
    (11, 79895866, 24, 'Rua Dom Bosco', 'Santa Maria', 'Brasília', 'DF', 'Quadra 501'),
    (12, 70215566, 04, 'Setor Central', 'Gama', 'Brasília', 'DF', 'Quadra 601'),
    (13, 79896351, 06, 'Avenida das Palmeiras', 'Asa norte', 'Brasília', 'DF', 'CLN 110'),
    (14, 89566526, 02, 'Rua Ipanema', 'Ipanema', 'Rio de Janeiro', 'RJ', 'Quadra 406'),
    (15, 79895862, 20, 'Praça do Bicalho', 'Taguatinga', 'Brasília', 'DF', 'CLN 307'),
	(16, 72261219, 14, 'Quadra QNO 20 Conjunto 19', 'Ceilândia Norte ', 'Brasília', 'DF', 'Quadra 71'),
    (17, 70755070, 24, 'Quadra SQN 309 Bloco G', 'Asa Norte', 'Brasília', 'DF', 'Quadra 701'),
    (18, 78150518, 13, 'CSB 3 Lote 08', 'Taguatinga Sul', 'Brasília', 'DF', 'Quadra 202'),
    (19, 55154085, 01, 'Quadra QNO 11 Conjunto B', 'Ceilândia Norte', 'Brasília', 'DF', 'Quadra 46'),
    (20, 72322813, 22, 'Quadra QI 616 Conjunto C', 'Samambaia Norte', 'Brasília', 'DF', 'CLN 37'),
    (21, 29154223, 01, 'Quadra 805 Conjunto 6', 'Recanto das Emas', 'Brasília', 'DF', 'CLN 37'),
	(22, 88348819, 41, 'Quadra EQNP 11/15 Módulo D', 'Ceilândia Norte', 'Brasília', 'DF', 'Quadra 271'),
    (23, 53170180, 42, 'Setor Colina', 'Nova Colina', 'Brasília', 'DF', 'Quadra 21'),
    (24, 93534011, 98, 'Quadra EQ 34/36', 'Setor Central', 'Brasília', 'DF', 'Quadra 22'),
    (25, 60510442, 07, 'Quadra CNN 1 Bloco K', 'Ceilândia Centro', 'Brasília', 'DF', 'Quadra 12'),    
    (26, 76589970, 14, 'Avenida Osvaldo', 'Setor Central', 'Novo Planalto', 'GO', 'CLN 47'),
	(27, 74692161, 21, 'Rua A 1', 'Residencial Atalaia', 'Goiânia', 'GO', 'Quadra 11'),
    (28, 74453170, 12, 'Rua Laguna', 'Ipiranga', 'Goiânia', 'GO', 'Quadra 21'),
    (29, 75532370, 08, 'Rua Miguel Couto', 'Setor Novo Horizonte', 'Itumbiara', 'GO', 'Quadra 34'),
    (30, 72833183, 06, 'Quadra Quadra 92', 'Jardim Bandeirante', 'Luziânia', 'GO', 'Quadra 19');

INSERT INTO INFORMACOES_TRABALHISTA
	(idInformacaoTrabalhista, salarioInicial, salario, valeAlimentacao, valeTransporte, numeroCtps, inscricaoPis)
VALUES
	(1, 1100.00, 1100.00, 600.00, 400.00, 46742431642, 78524589781),
    (2, 1100.00, 1100.00, 600.00, 400.00, 15451431151, 15158648651),
    (3, 1100.00, 1100.00, 600.00, 400.00, 15615151515, 55151315150),
    (4, 1100.00, 1100.00, 600.00, 350.00, 71505518155, 51500051511),
    (5, 1500.00, 1500.00, 600.00, 400.00, 16681515112, 15131515502),
    (6, 1500.00, 1500.00, 600.00, 450.00, 15156020559, 95958502002),
    (7, 1500.00, 1500.00, 600.00, 450.00, 87815151115, 12120205115),
    (8, 1800.00, 1800.00, 600.00, 400.00, 11715020202, 16100699260),
    (9, 1800.00, 1800.00, 600.00, 300.00, 21515195944, 15150202155),
    (10, 1800.00, 1800.00, 600.00, 300.00, 51515154544, 97544975477),
    (11, 2300.00, 2300.00, 600.00, 300.00, 25412542167, 21412341411),
    (12, 2300.00, 2300.00, 600.00, 300.00, 67267247476, 61272164124),
    (13, 2300.00, 2300.00, 600.00, 300.00, 57924672427, 97549726126),
    (14, 2300.00, 2300.00, 600.00, 300.00, 27627672727, 12461264124),
    (15, 2300.00, 2300.00, 600.00, 300.00, 62762467247, 14612461426),
    (16, 2300.00, 2300.00, 600.00, 300.00, 27292497242, 14612642412),
    (17, 2300.00, 2300.00, 600.00, 300.00, 29217921726, 14614124123),
    (18, 2300.00, 2300.00, 600.00, 300.00, 72167247248, 14612416456),
    (19, 2300.00, 2300.00, 600.00, 300.00, 41267247264, 12641241624),
    (20, 2300.00, 2300.00, 600.00, 300.00, 79424672472, 12461264262);

INSERT INTO FUNCIONARIO
	(cpf, nome, dataNascimento, idEndereco, funcao, idInformacaoTrabalhista)
VALUES
	(06637214158, 'Eduardo Gurgel', '1964-05-03', 1, 'Meio Oficial', 1), 
    (06265132256, 'Amanda Rocha', '1967-02-24', 2, 'Meio Oficial', 2),
    (56232326568, 'Gabriel Henrique','1980-09-03', 3, 'Meio Oficial', 3),
    (56595989562, 'Kamila Silva', '1981-04-04', 4, 'Meio Oficial', 4),
    (02112511532, 'Caio Bispo Nunes', '1987-11-11', 5, 'Servente', 5),
    (13154846545, 'Celina Bispo ', '1986-09-23', 6, 'Servente', 6),
    (13548498465, 'Henrique Juliano', '1984-05-23', 7, 'Servente', 7),
    (94846515311, 'Joaquim Brandão', '1990-01-03', 8, 'Impermeabilizador', 8),
    (02156165486, 'Kelly Dantas', '1989-12-014', 9, 'Impermeabilizador', 9),
    (15184894966, 'Joana Darc','1989-06-19',  10, 'Impermeabilizador', 10),
	(09206224026, 'Cristiano Santos ', '1976-02-21', 16, 'Encarregado', 11),
    (37042405080, 'Augusto Silva', '1997-05-23', 17, 'Encarregado', 12),
    (11266981055, 'Claudia Aragão', '1999-03-03', 18, 'Encarregado', 13),
    (83876039029, 'Sofia Dantas', '1989-12-19', 19, 'Encarregado', 14),
    (15012294009, 'Leticia Durval','1999-06-20',  20, 'Encarregado', 15),
	(31655443011, 'Davi Santana ', '1996-02-01', 21, 'Encarregado', 16),
    (40793098050, 'Pedro Silveira', '1999-05-03', 22, 'Encarregado', 17),
    (05387386003, 'Gabriela Souza', '1987-02-04', 23, 'Encarregado', 18),
    (28315466054, 'Ana Jordão', '1989-12-09', 24, 'Encarregado', 19),
    (34890226028, 'Cida Viana','1978-07-10',  25, 'Encarregado', 20);

INSERT INTO inss
	(idInformacaoTrabalhista, dataInss, valorInss)
VALUES
	(1, '2020-09-10', 400),
    (2, '2020-09-23', 600),
    (3, '2021-09-15', 500),
    (4, '2021-09-07', 800),
    (5, '2022-09-01', 900),
    (6, '2022-09-08', 300),
    (7, '2020-09-10', 400),
    (8, '2020-09-23', 600),
    (9, '2021-09-15', 500),
    (10, '2021-09-07', 800),
    (11, '2022-09-01', 900),
    (12, '2022-09-08', 300),
    (13, '2020-09-10', 400),
    (14, '2020-09-23', 600),
    (15, '2021-09-15', 500),
    (16, '2021-09-07', 800),
    (17, '2022-09-01', 900),
    (18, '2022-09-08', 300),
    (19, '2021-09-15', 500),
    (20, '2021-09-07', 800);
    
INSERT INTO fgts
	(idInformacaoTrabalhista, dataFgts, valorFgts)
VALUES
	(1, '2020-09-10', 400),
    (2, '2020-09-23', 600),
    (3, '2021-09-15', 500),
    (4, '2021-09-07', 800),
    (5, '2022-09-01', 900),
    (6, '2022-09-08', 300),
    (7, '2020-09-10', 400),
    (8, '2020-09-23', 600),
    (9, '2021-09-15', 500),
    (10, '2021-09-07', 800),
    (11, '2022-09-01', 900),
    (12, '2022-09-08', 300),
    (13, '2020-09-10', 400),
    (14, '2020-09-23', 600),
    (15, '2021-09-15', 500),
    (16, '2021-09-07', 800),
    (17, '2022-09-01', 900),
    (18, '2022-09-08', 300),
    (19, '2020-09-10', 400),
    (20, '2020-09-23', 600);
    
INSERT INTO decimoTerceiro
	(idInformacaoTrabalhista, dataDecimoTerceiro, valorDecimoTerceiro)
VALUES
	(1, '2022-11-23', 1000),
    (2, '2022-11-23', 1000),
    (3, '2022-11-23', 1000),
    (4, '2022-11-23', 1000),
    (5, '2022-11-23', 1000),
    (6, '2022-11-23', 1000),
    (7, '2022-11-23', 1000),
    (8, '2022-11-23', 1000),
    (9, '2022-11-23', 1000),
    (10, '2022-11-23', 1000),
    (11, '2022-11-23', 1000),
    (12, '2022-11-23', 1000),
    (13, '2022-11-23', 1000),
    (14, '2022-11-23', 1000),
    (15, '2022-11-23', 1000),
    (16, '2022-11-23', 1000),
    (17, '2022-11-23', 1000),
    (18, '2022-11-23', 1000),
	(19, '2022-11-23', 1000),
    (20, '2022-11-23', 1000);
    
INSERT INTO DEPENDENTE
	(cpfDependente, nomeDependente, tipoDependente) 
VALUES
	(02265875419, 'Mariana Xavier Bernardes', 'Filha'),
	(15131516511, 'Paulo Alberto Alves', 'Pai'),
	(15615615615, 'Ana Carolina Lemos', 'Esposa'),
	(16481861511, 'José Benício da Cunha', 'Filho'),
	(16515151155, 'Miguel Carvalho Santana', 'Filho'),
    (16515615151, 'Juliana Alves', 'Filha'),
	(00268151151, 'Caio Castro', 'Pai'),
	(98461515151, 'Aurideia Fernandes', 'Esposa'),
	(64615151511, 'Jean Maike Fonseca', 'Filho'),
	(15615616511, 'Gabriel Nunes Pacheco', 'Filho');
    
INSERT INTO relacionado
	(cpfDependente, cpfFuncionario) 
VALUES
	(02265875419, 06637214158),
	(15131516511, 06265132256),
	(15615615615, 56232326568),
	(16481861511, 56595989562),
	(16515151155, 02112511532),
    (16515615151, 13154846545),
	(00268151151, 13548498465),
	(98461515151, 94846515311),
	(64615151511, 02156165486),
	(15615616511, 15184894966);
    
INSERT INTO telefoneFuncionario
	(cpf, telefone)
VALUES
	(06637214158, 61994287770),
    (06265132256, 61985633258),
    (56232326568, 61982322641),
    (56595989562, 61995623232),
	(02112511532, 61993213123),
    (13154846545, 61999453155),
    (13548498465, 61994141247),
    (94846515311, 61992732811),
    (02156165486, 61993141415),
    (15184894966, 61995125512),
	(09206224026, 61996152742),
    (37042405080, 61996789831),
    (11266981055, 61995361272),
    (83876039029, 61992874198),
    (15012294009, 61998412848),
	(31655443011, 61993123133),
    (40793098050, 61998785656),
    (05387386003, 61992376757),
    (28315466054, 61992465473),
    (34890226028, 61992123315);
    
INSERT INTO FUNCIONARIO_ESCRITORIO
	(cpf, tituloGraduacao)
VALUES
	(06637214158, 'Contabilidade'),
    (06265132256, 'Contabilidade'),
    (56232326568, 'Administração'),
    (56595989562, 'Contabilidade'),
    (02112511532, 'Administração'),
	(09206224026, 'Administração'),
    (37042405080, 'Contabilidade'),
    (11266981055, 'Administração'),
    (83876039029, 'Contabilidade'),
    (15012294009, 'Administração');
    
INSERT INTO FUNCIONARIO_OBRA 
	(cpf, tempoExperiencia)
VALUES
	(13154846545, '7 meses'),
    (13548498465, '1 ano e 2 meses'),
    (94846515311, '1 ano'),
    (02156165486, '10 anos'),
    (15184894966, '5 anos'),
	(31655443011, '2 anos e 7 meses'),
    (40793098050, '3 anos e 6 meses'),
    (05387386003, '11 meses'),
    (28315466054, '1 ano e 1 mes'),
    (34890226028, '4 anos');
    
INSERT INTO EXAME
	(idExame, nomeExame)
VALUES
	(1, 'Oftamológico'),
    (2, 'Cardíaco'),
    (3, 'Muscular'),
    (4, 'Hemograma'),
    (5, 'Colesterol'),
	(6, 'Ácido Úrico'),
    (7, 'Eletrocardiograma'),
    (8, 'Ressonância Computadorizada'),
    (9, 'Tomografia'),
    (10, 'Densitometria Óssea');

INSERT INTO CURSO
	(idCurso, nomeCurso)
VALUES
	(1, 'Segurança do Trabalho'),
    (2, 'Edificações'),
    (3, 'Primeiros Socorros'),
    (4, 'Planejamento e Gestão de Obras '),
    (5, 'Impermeabilização de Áreas'),
	(6, 'Trabalho em Altura'),
    (7, 'Utilização de Máquinas e Equipamentos'),
    (8, 'Sustentabilidade'),
    (9, 'Sinalização de Segurança Básico'),
    (10, 'Comissão Interna de Prevenção de Acidentes');
    
INSERT INTO CONTA
	(idConta, nome, dtVencimento)
VALUES
	(1, 'Impermeabilização', '2022-09-08'),
    (2, 'Reparo de Avarias', '2022-09-08'),
    (3, 'Revestimento', '2022-09-08'),
    (4, 'Salario', '2022-09-08'),
    (5, 'Sistema de proteção', '2022-09-08'),
    (6, 'Impermeabilização', '2022-10-08'),
	(7, 'Equipamentos de Segurança', '2023-01-08'),
    (8, 'Equipamento Impermeabilização', '2023-04-03'),
    (9, 'Maquinário', '2023-04-09'),
    (10, 'Equipamento Sinalização', '2022-10-10');
    
 INSERT INTO PAGAMENTO_FUNCIONARIO
	(idConta, cpf, salario, somaBeneficios, mesAno)
VALUES
	(4, 06637214158, 2400.00, 200.00, '2022-05-05'),
    (4, 06265132256, 2400.00, 200.00, '2022-05-05'),
    (4, 56232326568, 2400.00, 200.00, '2022-05-05'),
    (4, 56595989562, 2400.00, 200.00, '2022-05-05'),
    (4, 02112511532, 2400.00, 200.00, '2022-05-05'),
    (4, 13154846545, 1200.00, 100.00, '2022-05-05'),
    (4, 13548498465, 1200.00, 100.00, '2022-05-05'),
    (4, 94846515311, 1200.00, 100.00, '2022-05-05'),
    (4, 02156165486, 1200.00, 100.00, '2022-05-05'),
    (4, 15184894966, 1200.00, 100.00, '2022-05-05'),
	(4, 09206224026, 1200.00, 100.00, '2022-05-05'),
    (4, 37042405080, 1200.00, 100.00, '2022-05-05'),
    (4, 11266981055, 1200.00, 100.00, '2022-05-05'),
    (4, 83876039029, 1200.00, 100.00, '2022-05-05'),
    (4, 15012294009, 1200.00, 100.00, '2022-05-05'),
	(4, 31655443011, 1200.00, 100.00, '2022-05-05'),
    (4, 40793098050, 1200.00, 100.00, '2022-05-05'),
    (4, 05387386003, 1200.00, 100.00, '2022-05-05'),
    (4, 28315466054, 1200.00, 100.00, '2022-05-05'),
    (4, 34890226028, 1200.00, 100.00, '2022-05-05');

INSERT INTO CONTRATANTE
	(cnpj, idEndereco, contato)
VALUES
	(00214587963365, 11, 'Gustavo Euclides'),
    (01235489688959, 12, 'Jhessica Fonseca'),
    (15232656594594, 13, 'Geraldo Merci'),
    (23689265623235, 14, 'Luiz Eduardo Brandão'),
    (65959832321569, 15, 'Ana Beatriz de Almeida'),
	(90594894000188, 26, 'Mauricio Euclides'),
    (67754732000148, 27, 'José Machado'),
    (33572462000132, 28, 'Flávio Augusto'),
    (34862800000133, 29, 'Luiza Brandão'),
    (03496975000140, 30, 'Ana Claudia');
    
INSERT INTO telefoneContratante
	(cnpj, telefone)
VALUES
	(00214587963365, 6130354585),
    (01235489688959, 6131265685),
    (15232656594594, 6136595336),
    (23689265623235, 6136543565),
    (65959832321569, 6133665988),
	(90594894000188, 6232512411),
    (67754732000148, 6233625112),
    (33572462000132, 6233516782),
    (34862800000133, 6233414124),
    (03496975000140, 6233424124);
    

INSERT INTO MATERIAL
	(idMaterial, nome, valor, medida, peso)
VALUES
	(1, 'Impermeabilizador', 500.00, 5.50, 100.00),
    (2, 'Manta Asfáltica', 200.00, 10.00, 200.00),
    (3, 'Reservatórios', 150.00, 15.50, 300.00),
    (4, 'Argamassa polimétrica', 530.00, 20.00, 200.00),
    (5, 'Resina de Poliuretano', 210.00, 10.50, 100.00),
	(6, 'Areia', 200.00, 54.50, 70.00),
    (7, 'Brita', 300.00, 101.00, 200.00),
    (8, 'Gesso', 450.00, 151.50, 130.00),
    (9, 'Impermeabilizante', 1530.00, 20.00, 50.00),
    (10, 'Cimento', 100.00, 103.50, 400.00);
    
INSERT INTO TIPO_SERVICO
	(idTipoServico, nomeTipoServico)
VALUES
	(1, 'Impermeabilização Total'),
    (2, 'Impermeabilização Parcial'),
    (3, 'Revestimento Lateral'),
    (4, 'Sistema de Proteção'),
    (5, 'Revestimento subterrâneo'),
	(6, 'Impermeabilização Em altura'),
    (7, 'Impermeabilização extensa'),
    (8, 'Revestimento Parcial'),
    (9, 'Impermeabilização predial'),
    (10, 'Revestimento Total');
    
INSERT INTO PROPOSTA
	(idProposta, valor, prazoValidade, prazoExecucao)
VALUES
	(1, 16.000, '2023-08-31', '2022-09-30'),
    (2, 8.0000, '2023-08-05', '2022-10-01'),
    (3, 10.000, '2024-06-10', '2022-09-05'),
    (4, 9.000, '2023-02-01', '2022-11-11'),
    (5, 10.000, '2025-08-31', '2022-12-26'),
	(6, 6.000, '2023-09-25', '2023-09-30'),
    (7, 18.0000, '2023-07-05', '2023-06-01'),
    (8, 20.000, '2024-01-10', '2024-07-05'),
    (9, 3.000, '2023-010-01', '2025-09-11'),
    (10, 30.000, '2025-01-31', '2025-11-26');

INSERT INTO CONTRATO
	(idContrato, idProposta, cnpj, descricaoTermo, juros, multa)
VALUES
	(1, 1, 00214587963365, 'Impermeabilização de Cômodo', 2.0, 1.0),
    (2, 2, 01235489688959, 'Impermeabilização de Cômodo', 2.0, 1.0),
    (3, 3, 15232656594594, 'Impermeabilização da piscina', 2.0, 1.0),
    (4, 4, 23689265623235, 'Revestimento da área externa', 2.0, 1.0),
    (5, 5, 65959832321569, 'Revestimento da área externa', 2.0, 1.0),
	(6, 6, 90594894000188, 'Impermeabilização de Cômodo', 2.0, 1.0),
    (7, 7, 67754732000148, 'Impermeabilização de Cômodo', 2.0, 1.0),
    (8, 8, 33572462000132, 'Impermeabilização da piscina', 2.0, 1.0),
    (9, 9, 34862800000133, 'Revestimento da área externa', 2.0, 1.0),
    (10, 10, 03496975000140,'Revestimento da área externa', 2.0, 1.0);
    
INSERT INTO PROJETO
	(idProjeto, idContrato)
VALUES
	(1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5),
    (6, 6),
    (7, 7),
    (8, 8),
    (9, 9),
    (10, 10);
    
INSERT INTO PAGAMENTO_SERVICO
	(idConta, idContrato, cnpj, descricaoPagamento)
VALUES
	(1, 1, 00214587963365, 'Pagamento à vista'),
    (2, 2, 01235489688959, 'Pagamento à vista'),
    (3, 3, 15232656594594, 'Pagamento à vista'),
    (4, 4, 23689265623235, 'Pagamento à vista'),
    (5, 5, 65959832321569, 'Pagamento à vista'),
	(6, 6, 90594894000188, 'Pagamento à vista'),
    (7, 7, 67754732000148, 'Pagamento à vista'),
    (8, 8, 33572462000132, 'Pagamento à vista'),
    (9, 9, 34862800000133, 'Pagamento à vista'),
    (10, 10, 03496975000140, 'Pagamento à vista');
    
INSERT INTO possui
	(idMaterial, idProposta, quantidade)
VALUES
	(1, 1, 3),
    (1, 2, 2),
    (2, 3, 4),
    (3, 4, 1),
    (4, 5, 1),
	(8, 6, 3),
    (8, 7, 2),
    (7, 8, 4),
    (6, 9, 1),
    (4, 10, 1);

INSERT INTO contem
	(idTipoServico, idProposta)
VALUES
	(1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5),
	(6, 6),
    (7, 7),
    (8, 8),
    (9, 9),
    (10, 10);

INSERT INTO gerencia
	(cpf, idProjeto)
VALUES
	(06637214158, 1),
    (06265132256, 2),
    (56232326568, 3),
    (56595989562, 4),
    (02112511532, 5),
	(09206224026, 6),
    (37042405080, 7),
    (11266981055, 8),
    (83876039029, 9),
    (15012294009, 10);

INSERT INTO trabalha
	(idProjeto, cpf)
VALUES
	(1, 13154846545),
    (2, 13548498465),
    (3, 94846515311),
    (4, 02156165486),
    (5, 15184894966),
    (6, 31655443011),
    (7, 40793098050 ),
    (8, 05387386003),
    (9, 28315466054),
    (10, 34890226028);
    
    
INSERT INTO cursa
	(cpf, idCurso)
VALUES
	(13154846545, 1),
    (13154846545, 2),
    (13548498465, 3),
    (02156165486, 4),
    (15184894966, 5),
	(31655443011, 6),
    (40793098050, 7),
    (05387386003, 8),
    (28315466054, 9),
    (34890226028, 10);
    
INSERT INTO realiza
	(cpf, idExame, resultado)
VALUES
	(13548498465, 1, 'apto'),
    (13154846545, 2, 'apto'),
    (13548498465, 3, 'apto'),
    (02156165486, 4, 'apto'),
    (15184894966, 5, 'apto'),
	(31655443011, 6, 'apto'),
    (40793098050, 7, 'apto'),
    (05387386003, 8, 'apto'),
    (28315466054, 9, 'apto'),
    (34890226028, 10, 'apto');