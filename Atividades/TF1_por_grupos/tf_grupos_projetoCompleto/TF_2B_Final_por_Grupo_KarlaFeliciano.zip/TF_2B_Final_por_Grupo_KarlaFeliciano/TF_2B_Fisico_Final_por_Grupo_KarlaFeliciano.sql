-- ---------------------   << Trabalho Final - Tema 2  >>   ---------------------
--
--                                   SCRIPT DE CRIAÇÃO (DDL)                                   
-- 
-- Data Criacao ...........: 31/08/2022
-- Autor(es) ..............: Jackes Tiago Ferreira da Fonseca, Karla Chaiane da Silva Feliciano e Lucas Gabriel Sousa Camargo Paiva
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: TF_2B_KarlaFeliciano
-- 
-- Ultimas Alteracoes
--   10/09/2022 => Adição do ON DELETE
--              => Remoção dos atributos juros e multa em PAGAMENTO_SERVICO
--              => Adição dos atributos juros e multa em CONTRATO
--
--   18/09/2022 => Criação das tabelas DEPENDENTE, INFORMACOES_TRABALHISTAS, relacionado, fgts, inss, decimoTerceiro 
--              => Adição do atributo idInformacaoTrabalhista na tabela FUNCIONARIO
--              => Troca do nome da tabela FUNCIONARIODEOBRA para FUNCIONARIO_OBRA
--              => Troca do nome da tabela ENCARREGADO para FUNCIONARIO_ESCRITORIO
--              => Adição do atributo descricaoPagamento em PAGAMENTO_SERVICO
--              => Adição dos atributos tempoExperiencia em FUNCIONARIO_OBRA e tituloGraducao em FUNCIONARIO_ESCRITORIO
--              => Alteração do nome da base de dados
--
-- PROJETO => 01 Base de Dados
--         => 29 Tabelas
-- 
-- --------------------------------------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS TF_2B_KarlaFeliciano;

USE TF_2B_KarlaFeliciano;

CREATE TABLE ENDERECO (
	idEndereco INT(4) NOT NULL AUTO_INCREMENT,
	cep INT(8) NOT NULL,
    numero INT(4) NOT NULL,
    rua VARCHAR(30) NOT NULL,
    bairro VARCHAR(30) NOT NULL,
    cidade VARCHAR(30) NOT NULL,
    estado CHAR(2) NOT NULL,
    complemento VARCHAR(50),
    
    CONSTRAINT ENDERECO_PK PRIMARY KEY (idEndereco)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE INFORMACOES_TRABALHISTA (
    idInformacaoTrabalhista INT(4) NOT NULL AUTO_INCREMENT,
    salarioInicial FLOAT(6,2) NOT NULL,
    salario FLOAT(6,2) NOT NULL,
    valeAlimentacao FLOAT(6,2) NOT NULL,
    valeTransporte FLOAT(6,2) NOT NULL,
    numeroCtps BIGINT(14) NOT NULL,
    inscricaoPis BIGINT(14) NOT NULL,

    CONSTRAINT INFORMACOES_TRABALHISTA_PK PRIMARY KEY(idInformacaoTrabalhista)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE FUNCIONARIO (
	cpf BIGINT(11) NOT NULL,
    nome VARCHAR(50) NOT NULL,
    dataNascimento DATE NOT NULL,
    idEndereco INT(4) NOT NULL,
    idInformacaoTrabalhista INT(4),
    funcao VARCHAR(20) NOT NULL,
    
    CONSTRAINT FUNCIONARIO_PK PRIMARY KEY (cpf),
    CONSTRAINT FUNCIONARIO_ENDERECO_FK FOREIGN KEY(idEndereco)
		REFERENCES ENDERECO(idEndereco)
) ENGINE = InnoDB;

CREATE TABLE inss (
    idInformacaoTrabalhista INT(4) NOT NULL,
    valorInss FLOAT(6,2) NOT NULL,
    dataInss DATE NOT NULL,

    CONSTRAINT inss_INFORMACAO_TRABALHISTA_FK FOREIGN KEY (idInformacaoTrabalhista)
        REFERENCES INFORMACOES_TRABALHISTA(idInformacaoTrabalhista),
    CONSTRAINT inss_UK UNIQUE KEY(idInformacaoTrabalhista, dataInss)  
)ENGINE = InnoDB;

CREATE TABLE fgts (
    idInformacaoTrabalhista INT(4) NOT NULL,
    valorFgts FLOAT(6,2) NOT NULL,
    dataFgts DATE NOT NULL,

    CONSTRAINT fgts_INFORMACAO_TRABALHISTA_FK FOREIGN KEY (idInformacaoTrabalhista)
        REFERENCES INFORMACOES_TRABALHISTA(idInformacaoTrabalhista),
    CONSTRAINT fgts_UK UNIQUE KEY(idInformacaoTrabalhista, dataFgts)  
)ENGINE = InnoDB;

CREATE TABLE decimoTerceiro (
    idInformacaoTrabalhista INT(4) NOT NULL,
    valorDecimoTerceiro FLOAT(6,2) NOT NULL,
    dataDecimoTerceiro DATE NOT NULL,

    CONSTRAINT DecimoTerceiro_INFORMACAO_TRABALHISTA_FK FOREIGN KEY (idInformacaoTrabalhista)
        REFERENCES INFORMACOES_TRABALHISTA(idInformacaoTrabalhista),
    CONSTRAINT DecimoTerceiro_UK UNIQUE KEY(idInformacaoTrabalhista, dataDecimoTerceiro)  
)ENGINE = InnoDB;

CREATE TABLE DEPENDENTE (
    cpfDependente BIGINT(11) NOT NULL,
    nomeDependente VARCHAR(50) NOT NULL,
    tipoDependente VARCHAR(20) NOT NULL,

    CONSTRAINT DEPENDENTE_PK PRIMARY KEY(cpfDependente)
)ENGINE = InnoDB;

CREATE TABLE relacionado (
    cpfFuncionario BIGINT(14) NOT NULL,
    cpfDependente BIGINT(14) NOT NULL,

    CONSTRAINT relacionado_FUNCIONARIO_FK FOREIGN KEY (cpfFuncionario)
        REFERENCES FUNCIONARIO(cpf),
    CONSTRAINT relacionado_DEPENDENTE_FK FOREIGN KEY (cpfDependente)
        REFERENCES DEPENDENTE(cpfDependente)
)ENGINE = InnoDB;

CREATE TABLE telefoneFuncionario (
	cpf BIGINT(11) NOT NULL,
    telefone BIGINT(12) NOT NULL,
    
    CONSTRAINT telefoneFuncionario_FUNCIONARIO_FK FOREIGN KEY(cpf) 
		REFERENCES FUNCIONARIO(cpf)
) ENGINE = InnoDB;

CREATE TABLE FUNCIONARIO_ESCRITORIO (
	cpf BIGINT(11) NOT NULL,
    tituloGraduacao VARCHAR(20) NOT NULL,
    cnpj BIGINT(14),
    
	CONSTRAINT ENCARREGADO_UK UNIQUE (cnpj),
    CONSTRAINT ENCARREGADO_PK PRIMARY KEY(cpf),
    CONSTRAINT ENCARREGADO_FUNCIONARIO_FK FOREIGN KEY(cpf) 
		REFERENCES FUNCIONARIO(cpf)
			ON DELETE CASCADE
) ENGINE = InnoDB;

CREATE TABLE FUNCIONARIO_OBRA (
	cpf BIGINT(11) NOT NULL,
    tempoExperiencia VARCHAR(20),

    CONSTRAINT FUNCIONARIODEOBRA_PK PRIMARY KEY(cpf),
    CONSTRAINT FUNCIONARIODEOBRA_FUNCIONARIO_FK FOREIGN KEY (cpf)
		REFERENCES FUNCIONARIO(cpf)
			ON DELETE CASCADE
) ENGINE = InnoDB;

CREATE TABLE EXAME (
	idExame INT(3) NOT NULL AUTO_INCREMENT,
    nomeExame VARCHAR(30) NOT NULL,
    
	CONSTRAINT EXAME_UK UNIQUE (nomeExame),
    CONSTRAINT EXAME_PK PRIMARY KEY (idExame)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE CURSO (
	idCurso INT(3) NOT NULL AUTO_INCREMENT,
    nomeCurso VARCHAR(50) NOT NULL,
    
	CONSTRAINT CURSO_UK UNIQUE (nomeCurso),
    CONSTRAINT CURSO_PK PRIMARY KEY (idCurso)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE CONTA (
	idConta INT(5) NOT NULL AUTO_INCREMENT,
    nome VARCHAR(30) NOT NULL,
    valor FLOAT(8,2),
    numeroBoleto VARCHAR(50),
    dtVencimento DATE NOT NULL,
    
	CONSTRAINT CONTA_UK UNIQUE (numeroBoleto),
    CONSTRAINT CONTA_PK PRIMARY KEY(idConta)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PAGAMENTO_FUNCIONARIO (
	idConta INT(5) NOT NULL,
    mesAno DATE NOT NULL,
    somaBeneficios FLOAT(8,2), 
    salario FLOAT(8,2) NOT NULL, 
    gratificacao FLOAT(8,2), 
    cpf BIGINT(11) NOT NULL,
    
    CONSTRAINT PAGAMENTO_FUNCIONARIO_PK PRIMARY KEY(cpf),
    CONSTRAINT PAGAMENTO_FUNCIONARIO_FUNCIONARIO_FK FOREIGN KEY(cpf)
		REFERENCES FUNCIONARIO(cpf),
    CONSTRAINT PAGAMENTO_FUNCIONARIO_CONTA_PK FOREIGN KEY(idConta)
		REFERENCES CONTA(idConta)
			ON DELETE CASCADE
) ENGINE = InnoDB;

CREATE TABLE CONTRATANTE (
	cnpj BIGINT(14) NOT NULL, 
    idEndereco INT(4) NOT NULL, 
    contato VARCHAR(50) NOT NULL, 
    
    CONSTRAINT CONTRATANTE_PK PRIMARY KEY(cnpj),
    CONSTRAINT CONTRATANTE_ENDERECO_FK FOREIGN KEY(idEndereco)
		REFERENCES ENDERECO(idEndereco)
) ENGINE = InnoDB;

CREATE TABLE telefoneContratante (
	cnpj BIGINT(14) NOT NULL,
    telefone BIGINT(12) NOT NULL,
    
    CONSTRAINT telefoneContratante_CONTRATANTE_FK FOREIGN KEY(cnpj) 
		REFERENCES CONTRATANTE(cnpj)
) ENGINE = InnoDB;

CREATE TABLE MATERIAL (
	idMaterial INT(3) NOT NULL AUTO_INCREMENT,
    nome VARCHAR(30) NOT NULL, 
    valor FLOAT(8,2) NOT NULL, 
    medida FLOAT(6,2) NOT NULL, 
    peso FLOAT(5,2) NOT NULL, 
    
    CONSTRAINT MATERIAL_PK PRIMARY KEY(idMaterial)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE TIPO_SERVICO (
	idTipoServico INT(3) NOT NULL AUTO_INCREMENT,
    nomeTipoServico VARCHAR(30) NOT NULL,
    
	CONSTRAINT TIPO_SERVICO_UK UNIQUE (nomeTipoServico),
    CONSTRAINT TIPO_SERVICO_PK PRIMARY KEY(idTipoServico)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PROPOSTA (
	idProposta INT(4) NOT NULL AUTO_INCREMENT,
    valor FLOAT(11,2) NOT NULL, 
    prazoValidade DATE NOT NULL, 
    prazoExecucao DATE NOT NULL, 
    tempoGarantia DATE, 
    descricaoObsevacoes VARCHAR(500),
    
    CONSTRAINT PROPOSTA_PK PRIMARY KEY(idProposta)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE CONTRATO (
	idContrato INT(4) NOT NULL AUTO_INCREMENT, 
    cnpj BIGINT(14) NOT NULL, 
    idProposta INT(4) NOT NULL, 
    descricaoTermo VARCHAR(1000) NOT NULL, 
    juros FLOAT(5,2),
    multa FLOAT(5,2),

	CONSTRAINT CONTRATO_PK PRIMARY KEY(idContrato),
	CONSTRAINT CONTRATO_CONTRATANTE_FK FOREIGN KEY(cnpj)
		REFERENCES CONTRATANTE(cnpj),
	CONSTRAINT CONTRATO_PROPOSTA_FK FOREIGN KEY(idProposta)
		REFERENCES PROPOSTA(idProposta)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PROJETO (
	idProjeto INT(5) NOT NULL AUTO_INCREMENT,
    idContrato INT(4) NOT NULL,
    
    CONSTRAINT PROJETO_PK PRIMARY KEY(idProjeto),
    CONSTRAINT PROJETO_CONTRATO_FK FOREIGN KEY(idContrato)
		REFERENCES CONTRATO(idContrato)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PAGAMENTO_SERVICO (
	idConta INT(5) NOT NULL, 
    idContrato INT(5) NOT NULL,
    cnpj BIGINT(14) NOT NULL,
    descricaoPagamento VARCHAR(50),
    
    CONSTRAINT PAGAMENTO_SERVICO_PK PRIMARY KEY(idConta),
    CONSTRAINT PAGAMENTO_SERVICO_CONTA_FK FOREIGN KEY(idConta)
		REFERENCES CONTA(idConta),
	CONSTRAINT PAGAMENTO_SERVICO_CONTRATO_FK FOREIGN KEY(idContrato)
		REFERENCES CONTRATO(idContrato),
	CONSTRAINT PAGAMENTO_SERVICO_CONTRATANTE_FK FOREIGN KEY(cnpj)
		REFERENCES CONTRATANTE(cnpj)
			ON DELETE CASCADE
) ENGINE = InnoDB;

CREATE TABLE possui (
	idMaterial INT(3) NOT NULL,
    idProposta INT(4) NOT NULL,
    quantidade INT(5) NOT NULL,
    
    CONSTRAINT possui_MATERIAL_FK FOREIGN KEY(idMaterial)
		REFERENCES MATERIAL(idMaterial),
	CONSTRAINT possui_PROPOSTA_FK FOREIGN KEY(idProposta)
		REFERENCES PROPOSTA(idProposta)
) ENGINE = InnoDB;

CREATE TABLE contem (
	idTipoServico INT(3) NOT NULL,
    idProposta INT(4) NOT NULL,
    
    CONSTRAINT contem_TIPO_SERVICO_FK FOREIGN KEY(idTipoServico)
		REFERENCES TIPO_SERVICO(idTipoServico),
	CONSTRAINT contem_PROPOSTA_FK FOREIGN KEY(idProposta)
		REFERENCES PROPOSTA(idProposta)
) ENGINE = InnoDB;

CREATE TABLE gerencia (
	cpf BIGINT(11) NOT NULL,
    idProjeto INT(5) NOT NULL,
    
    CONSTRAINT gerencia_ENCARREGADO_FK FOREIGN KEY(cpf)
		REFERENCES FUNCIONARIO_ESCRITORIO(cpf),
	CONSTRAINT gerencia_PROJETO_FK FOREIGN KEY(idProjeto)
		REFERENCES PROJETO(idProjeto)
) ENGINE = InnoDB;

CREATE TABLE trabalha (
	cpf BIGINT(11) NOT NULL,
    idProjeto INT(5) NOT NULL,
    
    CONSTRAINT trabalha_FUNCIONARIO_OBRA_FK FOREIGN KEY(cpf)
		REFERENCES FUNCIONARIO_OBRA(cpf),
	CONSTRAINT trabalha_PROJETO_FK FOREIGN KEY(idProjeto)
		REFERENCES PROJETO(idProjeto)
) ENGINE = InnoDB;

CREATE TABLE cursa (
	cpf BIGINT(11) NOT NULL,
    idCurso INT(3) NOT NULL,
    
    CONSTRAINT cursa_FUNCIONARIO_OBRA_FK FOREIGN KEY(cpf)
		REFERENCES FUNCIONARIO_OBRA(cpf),
	CONSTRAINT cursa_CURSO_FK FOREIGN KEY(idCurso)
		REFERENCES CURSO(idCurso)
) ENGINE = InnoDB;

CREATE TABLE realiza (
	cpf BIGINT(11) NOT NULL,
    idExame INT NOT NULL,
    resultado VARCHAR(30) NOT NULL,
    
    CONSTRAINT realiza_FUNCIONARIO_OBRA_FK FOREIGN KEY(cpf)
		REFERENCES FUNCIONARIO_OBRA(cpf),
	CONSTRAINT realiza_EXAME_FK FOREIGN KEY(idExame)
		REFERENCES EXAME(idExame)
) ENGINE = InnoDB;
