-- --------  << Trabalho final tema 3 - Ludoteca >>  ----------
--
--                    SCRIPT Popula
--
-- Data Criacao ...........: 18/09/2022
-- Autor(es) ..............: Mateus de Almeida Dias, Vinícius Assumpção de Araújo, Victor Hugo Oliveira Leão, Renan Rodrigues Lacerda
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_3C_ViniciusAraujo
--
--
-- PROJETO => 01 Base de Dados
--         => 24 Tabelas
--         => 03 papeis
--         => 09 users
-- ---------------------------------------------------------

-- BASE DE DADOS
USE TF_3C_ViniciusAraujo;

-- TABELAS

INSERT INTO CLIENTE
	(email, nomeCompleto, telefone) 
VALUES
	('edelmiro5758@uorak.com','Esmeralda Cortês',55611234567893 ),
	('poul465@uorak.com','Aline Lustosa',55611234567883 ),
	('rolindes2267@uorak.com','Kelson Nobre',55611236667893 ),
	('biser9039@uorak.com','Nathan Castro',55511234567893 ),
	('aurembiaix4702@uorak.com','Zita Cangueiro',55611234877893 ),
	('asbiser@uorak.com','Esmeralda Souza',55619876545513 ),
	('rexfox@uorak.com', 'Francisco Manoel',5589986335016 ),
	('beautyeyes@uorak.com', 'Fernando Mendes',5569968460388 ),
    ('vitin@uorak.com', 'Victor Leão', 5561991844198),
    ('renan123@uorak.com', 'Renan Lacerda', 5561998314916);

INSERT INTO CONTRATO 
	(cpf, rg, dtNas, endereco, bairro, cep, estadoCivil, profissao, telefoneUm, telefoneDois, dataAssinatura, tipoContrato, NomeTestemunhaUm, rgTestemunhaUm, NomeTestemunhaDois, rgTestemunhaDois, multaAtraso, multaPerda, email) 
VALUES
	(12345678945,1234567,'2002-06-27','Brasília','Vicente Pires',72006054,'solteiro','estudante',55619876543212,55619876577222,'2022-06-27','A','Jessica Lampreia',9876543,'Paulo Aleixo',4563217,300,500,'edelmiro5758@uorak.com'),
	(12345678545,1262567,'2003-06-30','Brasília','Gama',72008554,'casado','engenheira civil',55619878543212,55619876546622,'2022-06-28','A','Jessica Lampreia',9876543,'Paulo Aleixo',4563217,300,500,'poul465@uorak.com'),
	(12363678945,1834567,'2001-06-07','Brasília','Guará',72696054,'solteiro','professor',55619876963212,55619885543222,'2022-07-29','C','Anaís Valentim',9876883,'Cristovão Travassos',456617,300,500,'rolindes2267@uorak.com'),
	(12345672545,1234297,'2002-08-17','Brasília','Taguatinga',78006054,'casado','empreendedor',55619876545512,55619824543222,'2022-03-05','C','Anaís Valentim',9876883,'Cristovão Travassos',4566617,300,500,'biser9039@uorak.com'),
	(12384678945,1824567,'2002-09-28','Brasília','Samambaia',79606054,'solteiro','personal trainer',55637876543212,55619855543222,'2022-04-06','C','Gisela Holanda',9879943,'Victoria Freitas',4599217,300,500,'aurembiaix4702@uorak.com'),
	(12345672544,1234296,'2002-11-17','Brasília','Taguatinga',74006054,'casado','empreendedor',55619876545513,55619824543225,'2022-04-05','C','Anaís Castro',9876884,'Cristovão Travassos',4566617,300,500,'asbiser@uorak.com'),
	(67773780226,1563628,'1999-10-02','Fortaleza','Centro',04894480,'solteiro','Eletricista',558622723742,557438592703,'2022-10-11','C','Felipe Carvalho',3355958,'Carla Araújo',3077163,300,500,'rexfox@uorak.com'),
	(67773780226,1563628,'1999-10-02','Fortaleza','Centro',04894480,'solteiro','Eletricista',558622723742,557438592703,'2022-10-11','A','Luiz Alexandre',3355959,'Matheus Araújo',3877163,300,500,'rexfox@uorak.com'),
	(15161297506,1344211,'1987-05-10','Recife','Boa viagem',19020430,'solteiro','Mecânico',5511974146853,5521974936775,'2022-01-07','C','Manoel Silva',9879855,'Violeta Alves',9549215,300,500,'beautyeyes@uorak.com'), 
	(15161297506,1344211,'1987-05-10','Recife','Boa viagem',19020430,'solteiro','Mecânico',5511974146853,5521974936775,'2022-01-07','A','Azarias Neto',9976855,'Gomes de Melo',9549326,300,500,'beautyeyes@uorak.com'),
    (82593519111,0823510,'1990-02-20','Brasília','Águas Claras',71802812,'viúvo','Engenheiro de Software',5511012362234,5521999123612,'2021-02-09','A','Vinicius Souza',97187931,'Ana Claudia',0971411,50,555,'vitin@uorak.com'),
    (82593519111,0823510,'1990-02-20','Brasília','Águas Claras',71802812,'viúvo','Engenheiro de Software',5511012362234,5521999123612,'2021-11-30','C','Violeta Alves',06156312,'Felipe Carvalho',8912333,66,50,'vitin@uorak.com'),
    (98162946210,0001122,'1999-03-22','Brasília','Vicente Pires',71070015,'solteiro','Motorista de aplicativo',5511086183671,5521975187211,'2020-03-10','A','Brenda Oliveira',9768111,'Maria Santos',9999991,150,900,'renan123@uorak.com'),
    (98162946210,0001122,'1999-03-22','Brasília','Vicente Pires',71070015,'solteiro','Motorista de aplicativo',5511086183671,5521975187211,'2022-03-12','C','Elbert Leão',6853122,'Anaís Valentim',7988991,99,256,'renan123@uorak.com'),
    (67773780226,1563628,'1999-10-02','Fortaleza','Centro',04894480,'solteiro','Eletricista',558622723742,557438592703,'2019-12-30','C','Luiz Alexandre',3355959,'Matheus Araújo',3877163,50,55,'rexfox@uorak.com'),
    (12345678545,1262567,'2003-06-30','Brasília','Gama',72008554,'casado','engenheira civil',55619878543212,55619876546622,'2020-10-11','C','Jessica Lampreia',9876543,'Paulo Aleixo',4563217,99,100,'poul465@uorak.com'), 
	(67773780226,1563628,'1999-10-02','Fortaleza','Centro',04894480,'solteiro','Eletricista',558622723742,557438592703,'2022-09-19','A','Jessica Lampreia',9876543,'João Vaz',4666617,677,167,'rexfox@uorak.com'); 

-- Apesar do mínimo de tuplas da atividade ser 10, foi passado na entrevista e documento de contrato a existência de apenas 3 tipos de assinaturas.
INSERT INTO ASSINATURA 
	(nomeAssinatura, valorAssinatura) 
VALUES
	('CG', 80.00),  -- Casual Gamer
   	('BG', 120.00), -- Board Gamer
	('HG', 140.00); -- Heavy Gamer
    
INSERT INTO AVULSO 
	(idContrato, valorPago, periodoAluguel) 
VALUES
	(2, 60, 7),
	(1, 30, 3),
	(2, 60, 2),
	(2, 60, 4),
	(1, 30, 7),
	(8, 60, 7), 
	(10,60, 7),
    (11,120,3),
    (13,99,10),
    (17, 60, 4);
    
INSERT INTO CLUBE 
	(numCartaoCredito, multaCancelamento, idContrato, idAssinatura) 
VALUES
	(5502963852741236, 35, 4, 1),
	(5502963852741556, 35, 3, 1),
	(5502963859641236, 120, 6, 3),
	(5502945852741236, 90, 5, 2),
	(5502963852743936, 35, 12, 1),
	(6221147113785256, 100, 7, 1),
	(6321147113785256, 100, 9, 1),
    (9123585534139001, 120, 14, 3),
    (0909988542114668, 90, 15, 2),
    (0458585257838411, 35, 16, 1);
    
-- Apesar do mínimo de tuplas da atividade ser 10, foi passado na entrevista a existência de apenas 4 categorias de jogos.
INSERT INTO CATEGORIA 
	(corCategoria, descricaoCategoria) 
VALUES
	('Azul', 'Caixa pequena e baratos'),
	('Amarelo', 'Caixa média e comuns'),
	('Dourado', 'Raro, alugáveis para o clube'),
	('Rosa', 'Muito famosos e não alugáveis');
    
INSERT INTO FUNCIONARIO 
	(cpfFuncionario, nomeFuncionario, dataContratacao, emailFuncionario, telefoneFuncionario, salario, tipoFuncionario) 
VALUES
	(92491643611, 'Eduardo Lima', '2017-08-09', 'edunnli@gmail.com', 61991844198, 2550.00, 'M'),
	(92491643666, 'Hugo Yure', '2022-08-22', 'yureyugo@gmail.com', 61958582111, 3550.00, 'M'),
	(84791643611, 'Joao Germano', '2021-03-12', 'joaopegepa@gmail.com', 61999548314, 1450.00, 'M'),
	(92491682022, 'Nadim El Madi', '2018-07-30', 'nadasmaldi@gmail.com', 61994726296, 2950.50, 'M'),
	(00490043611, 'Ursula Monica', '2022-06-06', 'moniquinha@gmail.com', 61979821559, 550.00, 'M'),
	(88498843600, 'Alexandre Nascimento', '2019-10-10', 'alezinho@yahoo.com.br', 61983474123, 1450.00, 'G'),
	(92123641231, 'Felipe Amorim', '2015-11-26', 'felipena123@yahoo.com.br', 61939410800, 9888.80, 'G'),
	(12391643321, 'Vitor Amorim', '2015-11-26', 'vitorna@gmail.com', 61939410820, 7250.00, 'G'),
	(93391656121, 'Valeria Oliveira', '2019-07-01', 'lela.o.oliveira@gmail.com', 61991235788, 4920.22, 'G'),
	(62411633333, 'Laura Santos', '2011-04-12', 'lauras99@hotmail.com', 61948499016, 6099.99, 'G'),
	(74569531202, 'Pedro Andrade', '2015-04-12', 'pedro@hotmail.com', 62958499016, 6099.99, 'G'), 
	(23942829673, 'Ágata Maria', '2016-04-12', 'aamaria@hotmail.com', 63968499016, 6099.99, 'M'),
	(65808487749, 'Filipi Almeida', '2014-04-12', 'fpee99@hotmail.com', 88988499016, 6099.99, 'G'),
	(86775617062, 'Daniela Rodrigues', '2013-04-12', 'guesdan99@hotmail.com', 71948499016, 6099.99, 'M'),
    (01652691111, 'Vandor da Silva', '2022-06-13', 'vandor@hotmail.com', 81973531342, 450.00, 'G'),
    (99918263872, 'Sérgio Freitas', '2015-10-22', 'sergiofreitas@gmail.com', 81912783333, 10450.99, 'G'),
    (05784212301, 'Bruno Ribas', '2020-10-22', 'nutellaboot@gmail.com', 61998354222, 3880.99, 'G'),
    (05143613333, 'Sandra Maria', '2022-09-18', 'sandramonitoria@gmail.com', 61998354444, 1580.99, 'M'),
    (08975166777, 'André Correa', '2017-11-20', 'requisitosandre@gmail.com', 61998884444, 3880.99, 'M'),
    (05463642111, 'Rafael Oliveira', '2021-05-22', 'rafaelunb@hotmail.com', 61995555123, 1999.99, 'M');

INSERT INTO GARCOM 
	(cpfFuncionario) 
VALUES
	(92491643611),
	(92491643666),
	(84791643611),
	(92491682022),
	(00490043611),
	(74569531202), 
	(65808487749),
    (01652691111),
    (99918263872),
    (05784212301); 
    
INSERT INTO MONITOR 
	(cpfFuncionario) 
VALUES
	(88498843600),
	(92123641231),
	(12391643321),
	(93391656121),
	(62411633333),
	(23942829673),
	(86775617062),
    (05143613333),
    (08975166777),
    (05463642111); 
    
INSERT INTO MERCADORIA
	(categoriaMercadoria, precoVenda)
VALUES
	('Jogo', 55.00),
	('Jogo', 65.00),
	('Jogo', 70.00),
	('Jogo', 30.00),
	('Jogo', 32.99),
	('Produtos Avulsos', 35.00),
	('Produtos Avulsos', 70.00),
	('Produtos Avulsos', 12.00),
	('Produtos Avulsos', 20.00),
	('Produtos Avulsos', 55.00),
	('Quadrinho', 20.00),
	('Quadrinho', 22.00),
	('Quadrinho', 23.99),
	('Quadrinho', 25.00),
	('Quadrinho', 30.00),
	('Jogo', 100.00), 
	('Jogo', 200.00), 
	('Quadrinho', 10.00),
	('Quadrinho', 15.00),
	('Produtos Avulsos', 20.00),
	('Produtos Avulsos', 50.00),
    ('Jogo', 70.00),
    ('Jogo', 350.99),
    ('Jogo', 99.99),
    ('Produtos Avulsos', 20.00),
	('Produtos Avulsos', 60.00),
    ('Produtos Avulsos', 70.00),
    ('Produtos Avulsos', 30.00);
    
INSERT INTO JOGO 
	(nomeJogo, marca, idMercadoria, idCategoria)
 VALUES
	('Jogo da vida', 'Estrela', 1, 1),
	('Monopoly', 'Hasbro', 2, 2),
	('Coup', 'Galapagos', 3, 3),
	('Detetive', 'Estrela', 4, 4),
	('Cara a Cara', 'Precisa mente', 5, 3),
	('Resident Evil 2', 'Capcom', 16, 4), 
	('UNO', 'Copag', 17, 1),
    ('Banco Imobiliario', 'Estrela', 22, 1),
    ('War', 'Grow', 23, 3),
    ('Dungeons and Dragons', 'Wizards', 24, 4); 

INSERT INTO MESA
	(idMercadoria)
VALUES
	(1),
	(2),
	(3),
	(4),
	(5),
	(16), 
	(17),
    (22),
    (23),
    (24); 

INSERT INTO PRODUTO
	(idMercadoria, descricaoProduto)
VALUES
	(6, 'Caneca Marvel'),
	(7, 'Camiseta Avengers'),
	(8, 'Protetor de cartas'),
	(9, 'Baralho de cartas'),
	(10, 'Copo Batman'),
	(21, 'Chaveiro marvel'),
    (25, 'Chaveiro DC'), 
    (26, 'Camisa Image'), 
    (27, 'Caneca DC'), 
	(28, 'Boné Superman'); 
    
INSERT INTO CONTA
	(dataConta, idMesa, cpfFuncionario)
VALUES
	('2022-08-27', 1, 92491643611),
	('2022-06-12', 2, 92491643666),
	('2020-02-20', 3, 84791643611),
	('2022-05-10', 4, 92491682022),
	('2021-07-30', 5, 00490043611),
	('2020-08-10', 6, 74569531202),
    ('2021-04-05', 7, 65808487749),
    ('2020-09-10', 8, 74569531202),
    ('2022-11-10', 9, 74569531202),
	('2021-02-05', 10, 65808487749); 

INSERT INTO COMIDA
	(descricaoComida, precoComida)
VALUES
	('Crepe de Chocolate', 10.99),
	('Crepe de Presunto e Queijo', 7.99),
	('Crepe de Frango com Catupiry', 12.99),
	('Crepe de Banana com canela', 10.99),
	('Cachorro quente', 12.99),
	('Hamburguer Carne', 29.99),
    ('Hamburguer de soja', 50.00),
    ('Crepe de carne de sol', 29.99),
    ('Crepe de nutella', 29.99),
	('Hamburguer de Frango', 25.99); 
    
INSERT INTO BEBIDA
	(nomeBebida, precoBebida)
VALUES
	('Suco de laranja', 6.99),
	('Coca-cola', 5.99),
	('Redbull', 10.99),
    ('Monster', 10.99),
	('Caipiroska', 13.99),
	('Heineken Lata', 8.99),
    ('Suco de uva', 10.99),
    ('Guaraná Jesus', 10.99),
	('Coca-cola lata 600 ml', 6.99), 
	('Guaraná Kuat 1L', 7.99);
    
INSERT INTO QUADRINHO
	(nomeQuadrinho, marca, idMercadoria)
VALUES
	('X-Men: Fênix', 'Marvel', 11),
	('Quarteto Fantástico', 'Marvel', 12),
	('Homem Aranha: Fantasia', 'Marvel', 13),
	('Superman: O mundo sofreu', 'DC', 14),
	('Batman: Cavaleiro das Trevas', 'DC', 15),
    ('Batman: Longo dia das bruxas', 'DC', 16),
    ('Lanterna Verde', 'DC', 17),
	('Liga da justiça: o início', 'DC', 18), 
    ('Homem Aranha: Volta ao lar', 'DC', 19),
	('Homem Aranha: mile morales', 'Marvel', 20); 
    
INSERT INTO compra
	(email, idMercadoria, dataVenda, copia)
VALUES
	('edelmiro5758@uorak.com', 1, '2022-08-27', 3),
	('rolindes2267@uorak.com', 10, '2022-06-12', 6),
	('aurembiaix4702@uorak.com', 11, '2020-02-20', 2),
	('edelmiro5758@uorak.com', 14, '2022-05-10', 9),
	('poul465@uorak.com', 2, '2022-07-30', 4),
	('biser9039@uorak.com', 20, '2021-06-30', 1), 
    ('aurembiaix4702@uorak.com', 21, '2021-07-30', 7),
    ('rexfox@uorak.com', 22, '2019-07-30', 8),
    ('rexfox@uorak.com', 23, '2020-03-30', 10),
	('beautyeyes@uorak.com', 24, '2021-09-30', 5); 
    
INSERT INTO aluga
	(idContrato, idMercadoria, copia)
VALUES
	(1, 1, 2),
	(2, 14, 3),
	(3, 15, 4), 
    (4, 16, 5),
    (5, 18, 6),
    (6, 19, 7),
    (7, 20, 9),
    (8, 21, 10),
    (9, 22, 11),
	(10, 21, 12); 
    
INSERT INTO contem_MESA_JOGO
	(email, idMesa, pontuacao)
VALUES
	('rolindes2267@uorak.com', 1, 1000),
	('biser9039@uorak.com', 2, 15),
	('aurembiaix4702@uorak.com', 3, 150),
    ('poul465@uorak.com', 4, 15),
	('asbiser@uorak.com', 5, 66),
	('biser9039@uorak.com', 6, 999),
	('vitin@uorak.com', 7, 1150), 
    ('biser9039@uorak.com', 8, 999),
    ('renan123@uorak.com', 9, 1150),
	('beautyeyes@uorak.com', 10, 2000); 

INSERT INTO ensina
	(cpfFuncionario, idMesa, dataAtendimento)
VALUES
	(88498843600, 1, '2022-08-27'),
	(92123641231, 2, '2022-06-12'),
	(12391643321, 3, '2020-02-20'),
	(93391656121, 4, '2022-05-10'),
	(62411633333, 5, '2021-07-30'),
	(23942829673, 6, '2021-08-03'), 
    (05143613333, 7, '2021-08-04'),
    (08975166777, 8, '2021-09-03'),
    (23942829673, 9, '2022-08-15'),
	(86775617062, 10, '2020-09-17');
    
INSERT INTO loca
	(idContrato, idMercadoria, periodoAluguel, copia)
VALUES
	(1, 3, 10, 10),
	(2, 12, 5, 12),
	(3, 13, 7, 1),
    (4, 14, 8, 3),
    (5, 15, 6, 4), 
    (6, 16, 9, 5), 
    (7, 17, 3, 6), 
    (8, 18, 4, 7), 
    (9, 19, 7, 8), 
	(10, 20, 1, 2); 
    
INSERT INTO contem_CONTA_COMIDA
	(idConta, idComida)
VALUES
	(1, 1),
	(2, 2),
	(3, 3),
	(4, 4),
	(5, 5),
	(6, 6), 
    (7, 7),
    (8, 8),
    (9, 9),
	(10, 10);
    
INSERT INTO detem
	(idConta, idBebida)
VALUES
	(2, 3),
	(1, 3),
	(3, 1),
	(2, 2),
	(5, 4),
	(6, 6),
    (7, 7),
    (8, 8),
    (9, 9),
	(10, 10);
