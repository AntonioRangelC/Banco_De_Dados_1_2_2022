-- --------  << Trabalho final tema 3 - Ludoteca >>  ----------
--
--                    SCRIPT DE APAGAR
--
-- Data Criacao ...........: 30/08/2022
-- Autor(es) ..............: Mateus de Almeida Dias, Vinícius Assumpção de Araújo, Renan Rodrigues Lacerda, Victor Hugo Oliveira Leão
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_3C_ViniciusAraujo
--
-- Ultimas Alteracoes
--  08/09/2022 => Adequação do nome da base de dados
--  09/09/2022 => Adição dos drop de usuários
--  18/09/2022 => Mudança do drop tables para os corretos
--             => Drop Users criados
--
-- PROJETO => 01 Base de Dados
--         => 24 Tabelas
--         => 03 papeis
--         => 09 users
-- ---------------------------------------------------------

-- BASE DE DADOS
USE TF_3C_ViniciusAraujo;

-- TABELAS

DROP TABLE detem;
DROP TABLE contem_CONTA_COMIDA;
DROP TABLE loca;
DROP TABLE ensina;
DROP TABLE contem_MESA_JOGO;
DROP TABLE aluga;
DROP TABLE compra;
DROP TABLE QUADRINHO;
DROP TABLE BEBIDA;
DROP TABLE COMIDA;
DROP TABLE CONTA;
DROP TABLE PRODUTO;
DROP TABLE MESA;
DROP TABLE JOGO;
DROP TABLE MERCADORIA;
DROP TABLE MONITOR;
DROP TABLE GARCOM;
DROP TABLE FUNCIONARIO;
DROP TABLE CATEGORIA;
DROP TABLE CLUBE;
DROP TABLE AVULSO;
DROP TABLE ASSINATURA;
DROP TABLE CONTRATO;
DROP TABLE CLIENTE;

-- USERS
DROP USER 'bianca';
DROP USER 'vandor';
DROP USER 'charlon';
DROP USER 'rozana';
DROP USER 'flavia';
DROP USER 'luana';
DROP USER 'maria';
DROP USER 'joao';
DROP USER 'marialuisa';