-- --------  << Trabalho final tema 3 - Ludoteca >>  ----------
--
--                    SCRIPT DE Controle
--
-- Data Criacao ...........: 05/09/2022
-- Autor(es) ..............: Mateus de Almeida Dias, Vinícius Assumpção de Araújo, Renan Rodrigues Lacerda, Victor Hugo Oliveira Leão
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_3C_ViniciusAraujo
--
-- Ultimas Alteracoes
--  18/09/2022 => Adequação do nome da base de dados
--             => Tabelas corretas para as roles de acordo com o novo Fisico
--             => Criação dos usuários com senhas e roles designadas
--
-- PROJETO => 01 Base de Dados
--         => 17 Tabelas
--         => 03 papeis	
--         => 09 users
-- ---------------------------------------------------------

CREATE ROLE IF NOT EXISTS 'gerente', 'monitor', 'garcom';

-- ROLE gerente
GRANT ALL ON TF_3C_ViniciusAraujo.* TO 'gerente';

-- ROLE garcom
GRANT SELECT, UPDATE, INSERT, DELETE ON TF_3C_ViniciusAraujo.COMIDA TO 'garcom';
GRANT SELECT, UPDATE, INSERT, DELETE ON TF_3C_ViniciusAraujo.BEBIDA TO 'garcom';
GRANT SELECT, UPDATE, INSERT, DELETE ON TF_3C_ViniciusAraujo.CONTA TO 'garcom';
GRANT SELECT, UPDATE, INSERT, DELETE ON TF_3C_ViniciusAraujo.MESA TO 'garcom';
GRANT SELECT, UPDATE, INSERT, DELETE ON TF_3C_ViniciusAraujo.CLIENTE TO 'garcom';
GRANT SELECT, UPDATE, INSERT, DELETE ON TF_3C_ViniciusAraujo.contem_CONTA_COMIDA TO 'garcom';
GRANT SELECT, UPDATE, INSERT, DELETE ON TF_3C_ViniciusAraujo.detem TO 'garcom';

-- ROLE monitor
GRANT SELECT, UPDATE, INSERT, DELETE ON TF_3C_ViniciusAraujo.MESA TO 'monitor';
GRANT SELECT, UPDATE, INSERT, DELETE ON TF_3C_ViniciusAraujo.CLIENTE TO 'monitor';
GRANT SELECT, UPDATE, INSERT, DELETE ON TF_3C_ViniciusAraujo.MERCADORIA TO 'monitor';
GRANT SELECT, UPDATE, INSERT, DELETE ON TF_3C_ViniciusAraujo.PRODUTO TO 'monitor';
GRANT SELECT, UPDATE, INSERT, DELETE ON TF_3C_ViniciusAraujo.JOGO TO 'monitor';
GRANT SELECT, UPDATE, INSERT, DELETE ON TF_3C_ViniciusAraujo.CATEGORIA TO 'monitor';
GRANT SELECT, UPDATE, INSERT, DELETE ON TF_3C_ViniciusAraujo.contem_MESA_JOGO TO 'monitor';

-- PERFIL gerente

CREATE USER 'bianca'
IDENTIFIED BY 'gerente123';
GRANT 'gerente' TO 'bianca';

CREATE USER 'vandor'
IDENTIFIED BY 'gerente456';
GRANT 'gerente' TO 'vandor';

CREATE USER 'charlon'
IDENTIFIED BY 'gerente321';
GRANT 'gerente' TO 'charlon';

-- PERFIL monitor

CREATE USER 'rozana'
IDENTIFIED BY 'monitor123';
GRANT 'monitor' TO 'rozana';

CREATE USER 'flavia'
IDENTIFIED BY 'monitor321';
GRANT 'monitor' TO 'flavia';

CREATE USER 'luana'
IDENTIFIED BY 'monitora456';
GRANT 'monitor' TO 'luana';

-- PERFIL garcom

CREATE USER 'maria'
IDENTIFIED BY 'garcom123';
GRANT 'garcom' TO 'maria';

CREATE USER 'joao'
IDENTIFIED BY 'garcom321';
GRANT 'garcom' TO 'joao';

CREATE USER 'marialuisa'
IDENTIFIED BY 'garcom456';
GRANT 'garcom' TO 'marialuisa';