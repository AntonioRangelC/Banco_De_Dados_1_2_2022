-- --------  << NOVO - Trabalho Final (scripts e dicionário) >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/09/2022
-- Autor(es) ..............: Guilherme Peixoto Lima
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF1_Guilherme
--
-- PROJETO => 01 Base de Dados
--         => 30 Tabelas
-- ---------------------------------------------------------

CREATE DATABASE IF NOT EXISTS TF1_Guilherme
    DEFAULT CHARACTER SET utf8
    DEFAULT COLLATE utf8_general_ci;
USE TF1_Guilherme;


#criar uma nova tabela de administrador
CREATE TABLE PESSOA (
    identificadorUnico DECIMAL (12,0) PRIMARY KEY, 
    dataNacimento DATE,
    email VARCHAR (150),
    tipoSanguineo ENUM ('A+', 'B+',  'AB+', 'O+','O-','A-', 'B-'),
    sexo ENUM ('M', 'F'),
    estadoCivil ENUM ('Solteiro', 'Casado', 'Divorciado', 'nao declarar'),
	#Adicionar Enum de viuvo(a)
    profissao VARCHAR (60),
    tipoIdentificacao ENUM ('CPF', 'RG'),
    tipoPessoa INT (2), 
                        -- #1 cliente 
                        -- #2 terapeuta
                        -- #3 administrador
                        -- #Mudar esse campo para ENUM('Cliente', 'Terapeuta', 'Admistrador')
    UNIQUE (identificadorUnico, email)
)ENGINE = InnoDB;


CREATE TABLE CLIENTE (
    identificadorUnico DECIMAL (12) PRIMARY KEY,
	CONSTRAINT identificadorUnico_PESSOA_FK FOREIGN KEY (identificadorUnico)
        REFERENCES PESSOA(identificadorUnico)
)ENGINE = InnoDB;

CREATE TABLE TERAPEUTA (
    tipoTerapeuta ENUM ('HEICH','Barra de Axis'),
    dataSaida DATE ,
    dataAdmissao DATE,
    identificadorUnico DECIMAL (12,0) UNIQUE,
    	CONSTRAINT identificadorUnico_PESSOA_TERAP_FK FOREIGN KEY (identificadorUnico)
        REFERENCES PESSOA(identificadorUnico)
)ENGINE = InnoDB;


CREATE TABLE SECAO_PAGAMENTO (
                                    -- criar uma tabela para secao e outra para pagamento (com foreing keys)

    idSecao INT (11) PRIMARY KEY AUTO_INCREMENT,
    periodicidadeAcompanhamento INT (4), #--Talvez enum(40,80,120)
    numeroSecoes INT (3),
    precoTotal DECIMAL (5,2),
    dataSecao DATE,
    tipoSecao VARCHAR (60),
    identificadorUnico DECIMAL (12,0),
    pagamentoId INT(12),
    tipo ENUM ('boleto', 'credito', 'debito', 'pix' ),
    criadoEm DATE,
    atualizadoEm DATE, #ALTERAR PARA DATETIME
    parcelas INT (3),
    status ENUM ('aprovado', 'nao aprovado', 'aguardando pagamento', 'recusado'),
    UNIQUE (idSecao, pagamentoId),
    
    
    CONSTRAINT SECAO_PESSOA_PK FOREIGN KEY (identificadorUnico)
        REFERENCES PESSOA(identificadorUnico)
)ENGINE = InnoDB;


CREATE TABLE ORGAOCHOQUE (
    orgaoId INT (11), #USAR AUTO INCREMENT
    nome VARCHAR(80) PRIMARY KEY UNIQUE
)ENGINE = InnoDB;


CREATE TABLE RELATORIO_ACOMPANHAMENTO ( 
                                    #--criar uma tabela para relatorio e outra para acompanhamento (com foreing keys)
    relatorioId INT (11) PRIMARY KEY AUTO_INCREMENT, #--Usar auto increment
    dataRelatorio DATE,
    infoCliente TEXT,
    tipoAcompanhamento ENUM ('mente','corpo'),
    idAcompanhamento INT(11), #--Usar auto increment
    idSecao INT (11),
        
    CONSTRAINT RELATORIOACOMPANHAMENTO_SECAO_FK FOREIGN KEY (idSecao)
        REFERENCES SECAO_PAGAMENTO(idSecao)
)ENGINE = InnoDB; 


CREATE TABLE RECEITA (
    idReceita INT (11) PRIMARY KEY AUTO_INCREMENT,
    statusReceita ENUM ('aguardando envio', 'enviada', 'aguardado resposta farmacia', 'finalizada'),
    idRelatorio INT (11),
    pessoaIdentificadorUnico DECIMAL (12,0),
    terapeutaIdentificadorUnico DECIMAL (12,0),
    
    CONSTRAINT RECEITA_RELATORIO_ID_FK FOREIGN KEY (idRelatorio)
        REFERENCES RELATORIO_ACOMPANHAMENTO(relatorioId),
    CONSTRAINT RECEITA_PESSOA_FK FOREIGN KEY (pessoaIdentificadorUnico)
        REFERENCES CLIENTE(identificadorUnico),
    CONSTRAINT RECEITA_TERAPEUTA FOREIGN KEY (terapeutaIdentificadorUnico)
        REFERENCES TERAPEUTA(IdentificadorUnico)
)ENGINE = InnoDB ;

CREATE TABLE CURSO (
    idCurso INT (11) PRIMARY KEY UNIQUE AUTO_INCREMENT,
    nome VARCHAR(120) 
    -- Acrecentar local de realizção do curso, site etc
)ENGINE = InnoDB;

CREATE TABLE telefone (
    telefoneId INT (11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
    telefone DECIMAL (13,0), #--Aumentar o numero de telefone em 2
    userId DECIMAL (12,0)
)ENGINE = InnoDB;

 
CREATE TABLE CONSULTORIO (
    idReceitaConsultorio INT (11),
	CONSTRAINT CONSULTORIO_RECEITA_FK FOREIGN KEY (idReceitaConsultorio)
	REFERENCES RECEITA(idReceita)
)ENGINE = InnoDB;


CREATE TABLE FARMACIA (
    idReceitaFarmacia INT (11) PRIMARY KEY,
    
    CONSTRAINT FARMACIA_RECEITA_FK FOREIGN KEY (idReceitaFarmacia)
        REFERENCES RECEITA(idReceita)
)ENGINE = InnoDB ;


CREATE TABLE CONTAMINACAO (
    recomendacao VARCHAR (500),
    contaminacaoId INT (11) PRIMARY KEY UNIQUE AUTO_INCREMENT,
    relatorioId INT (11),
    
    CONSTRAINT RELATORIOACOMPANHAMENTO_CONTAMINACAO_FK FOREIGN KEY (relatorioId)
        REFERENCES RELATORIO_ACOMPANHAMENTO(relatorioId)
)ENGINE = InnoDB;

CREATE TABLE METAL (
    metalId INT (11) AUTO_INCREMENT PRIMARY KEY, #--Usar auto increment 
    nome VARCHAR (60) UNIQUE
)ENGINE = InnoDB ;

CREATE TABLE ITEM (
    #--Adicionar números da anvisa ou id#--Nome do item como primary key
    itemId INT (11) PRIMARY KEY UNIQUE AUTO_INCREMENT,
    nome VARCHAR(600) UNIQUE, #--Alterar para VARCHAR
    precoVenda DECIMAL (6,2),
    descricao TEXT
)ENGINE = InnoDB;

CREATE TABLE ITEMFARMACIA (
    itemFarmaciaId INT (11) , #--Alterar por idItem

    CONSTRAINT ITEM_FARMACIA_FK FOREIGN KEY (itemFarmaciaId)
        REFERENCES ITEM(itemId)
)ENGINE = InnoDB ;


#Contestavel
CREATE TABLE ESTOQUE (
    -- Adicionar foreing key do item como id do item
    --
    idEstoque INT (11) AUTO_INCREMENT UNIQUE NOT NULL PRIMARY KEY, 
    idItemEstoque INT (11), #--Use as primary and auto increment
    quantidade INT (4),
    dataAtualizacao DATE,
    precoCusto DECIMAL (12,0),
    
    CONSTRAINT ESTOQUE_ITEM_FK FOREIGN KEY (idItemEstoque)
        REFERENCES ITEM(itemId)
)ENGINE = InnoDB;


CREATE TABLE ENDERECO (
	idEndereco INT(12) PRIMARY KEY NOT NULL AUTO_INCREMENT,  
    cep VARCHAR (8),
    cidade VARCHAR (80),
    complemento VARCHAR (300),
    #-- bairro
    #-- Estado
	UNIQUE (cep, complemento)
)ENGINE = InnoDB;


CREATE TABLE FARMACIA_PARCEIRA (
	idFarmacia INT(12) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nomeFarmacia VARCHAR (60),    
    
    UNIQUE(idFarmacia)
)ENGINE = InnoDB;

CREATE TABLE telefoneFarmacia (
    telefoneFarmacia DECIMAL(13,0) NOT NULL PRIMARY KEY,
    idFarmacia INT(12) ,
    
    CONSTRAINT FARMACIA_PARCEIRA_TELEFONE_FK FOREIGN KEY (idFarmacia)
        REFERENCES FARMACIA_PARCEIRA(idFarmacia)
)ENGINE = InnoDB;

CREATE TABLE habita (
	idEndereco INT(12),
    identificadorUnico DECIMAL (12,0),
    
    CONSTRAINT PESSOA_HABITA_PID_FK FOREIGN KEY (identificadorUnico)
        REFERENCES PESSOA(identificadorUnico),
    CONSTRAINT PESSOA_HABITA_ENDERECO_FK FOREIGN KEY (idEndereco)
        REFERENCES ENDERECO(idEndereco)
)ENGINE = InnoDB;
#####################
CREATE TABLE tem (
    relatorioId INT (11),
    orgaoChoqueNome VARCHAR(80),
    
    CONSTRAINT RELAT_ACOMP_ORGAO_FK FOREIGN KEY (orgaoChoqueNome)
        REFERENCES ORGAOCHOQUE(nome),
    CONSTRAINT RELAT_ACOMP_RELNOME_FK FOREIGN KEY (relatorioId)
        REFERENCES RELATORIO_ACOMPANHAMENTO(relatorioId)    
)ENGINE = InnoDB;

CREATE TABLE contem (
    contaminacaoId INT (11),
    metalNome VARCHAR (60),
    
    
    CONSTRAINT CONTA_METAL_FK FOREIGN KEY (contaminacaoId)
        REFERENCES CONTAMINACAO(contaminacaoId),
    CONSTRAINT CONTA_METAL_NOME_FK FOREIGN KEY (metalNome)
        REFERENCES METAL(nome) 
)ENGINE = InnoDB;

CREATE TABLE inclui (
    itemId INT (11),
    idReceitaConsultorio INT (11),
    
    CONSTRAINT CONSULTORIO_ITEM_FK FOREIGN KEY (itemId)
        REFERENCES ITEM(itemId),
    CONSTRAINT RECEITACONSULTORIO_ID_FK FOREIGN KEY (idReceitaConsultorio)
        REFERENCES CONSULTORIO(idReceitaConsultorio)    
)ENGINE = InnoDB;

CREATE TABLE dispoe (
    itemId INT (11),
    idFarmacia INT (12),
    
    CONSTRAINT ITEM_DISPOE_PK FOREIGN KEY (itemId)
        REFERENCES ITEM(itemId),
    CONSTRAINT FARMACIAPARCEIRA_DISPOE_PK FOREIGN KEY (idFarmacia)
        REFERENCES FARMACIA_PARCEIRA(idFarmacia)
)ENGINE = InnoDB;

CREATE TABLE cursa (
    fk_TERAPEUTA_FK_PESSOA_identificadorUnico DECIMAL (12),
    fk_CURSO_idCurso INT (4),
    
    CONSTRAINT TERAPEUTA_PESSOA_PK FOREIGN KEY (fk_TERAPEUTA_FK_PESSOA_identificadorUnico)
        REFERENCES PESSOA(identificadorUnico),
    CONSTRAINT TERAPEUTA_CURSO_PK FOREIGN KEY (fk_CURSO_idCurso)
        REFERENCES CURSO(idCurso)
)ENGINE = InnoDB;

CREATE TABLE localizada (
    idSecao INT (11),
    idEndereco INT (12),
    CONSTRAINT CONSULTA_LOCALIZADA_ID_FK FOREIGN KEY (idSecao)
        REFERENCES SECAO_PAGAMENTO(idSecao),
    CONSTRAINT CULSULRA_LOCALIZADA_ENDERECO_FK FOREIGN KEY (idEndereco)
        REFERENCES ENDERECO(idEndereco)
)ENGINE = InnoDB;

CREATE TABLE situada (
	idEndereco INT(12),
    idFarmacia INT(12),
    
    CONSTRAINT FARMACIA_SITUADA_ID_FK FOREIGN KEY (idFarmacia)
        REFERENCES FARMACIA_PARCEIRA(idFarmacia),
    CONSTRAINT FARMACIA_SITUADA_ENDERECO_FK FOREIGN KEY (idEndereco)
        REFERENCES ENDERECO(idEndereco)
)ENGINE = InnoDB;

CREATE TABLE entregue (
    idReceita INT (11),
    idFarmacia INT(12),
    
    CONSTRAINT RECEITAFARMACIA_ENTREGUE_PK FOREIGN KEY (idReceita)
        REFERENCES FARMACIA(idReceitaFarmacia),
    CONSTRAINT FARMACIA_ENTREGUE_PK FOREIGN KEY (idFarmacia)
        REFERENCES FARMACIA_PARCEIRA(idFarmacia)   
)ENGINE = InnoDB;



#Contestavel

CREATE TABLE gerencia (
    identificadorUnico DECIMAL (12,0),
    idEstoque INT (11),
    
    CONSTRAINT TERAPEUTA_GERENCIA_ESTOQUE_ID_PK FOREIGN KEY (identificadorUnico)
        REFERENCES PESSOA(identificadorUnico),
    CONSTRAINT TERAPEUTA_GERENCIA_ESTOQUE_FK FOREIGN KEY (idEstoque)
        REFERENCES ESTOQUE(idEstoque)
)ENGINE = InnoDB;

CREATE TABLE efetua (
    identificadorUnico DECIMAL (12,0),
    idSecao INT (12),

    CONSTRAINT CLIENTE_PAGAMENTO FOREIGN KEY (identificadorUnico)
        REFERENCES PESSOA(identificadorUnico),
    CONSTRAINT PAGAMENTO_PESSOA FOREIGN KEY (idSecao)
        REFERENCES SECAO_PAGAMENTO(idSecao)
)ENGINE = InnoDB;
