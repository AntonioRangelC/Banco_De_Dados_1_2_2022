-- -----------------------------   << Trabalho Final - Video Games (Tema 1) - Grupo C  >>   -----------------------------
--
--                                              SCRIPT DE APAGAR (DDL)                                               
-- 
-- Data Criacao ...........: 04/12/2019
-- Autor(es) ..............: Guilherme Peixoto Lima
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: TF1_Guilherme
-- 
-- Data Ultima Alteracao ..: 05/12/2019
--  => Adição do comando de apagar as tabelas PAGAMENTO e inclui
--
-- PROJETO => 01 Base de Dados
--         => 31 Tabelas
-- 
-- ----------------------------------------------------------------------------------------------------------------------

USE TF1_Guilherme;
DROP TABLE habita;
DROP TABLE tem;
DROP TABLE contem;
DROP TABLE inclui;
DROP TABLE dispoe;
DROP TABLE cursa ;
DROP TABLE localizada ;
DROP TABLE situada ;
DROP TABLE entregue ;
DROP TABLE gerencia ;
DROP TABLE efetua ;
DROP TABLE CONSULTORIO;
DROP TABLE FARMACIA;
DROP TABLE RECEITA;
DROP TABLE CLIENTE;
DROP TABLE TERAPEUTA;
DROP TABLE CONTAMINACAO;
DROP TABLE RELATORIO_ACOMPANHAMENTO;
DROP TABLE SECAO_PAGAMENTO;
DROP TABLE PESSOA;
DROP TABLE ORGAOCHOQUE;
DROP TABLE CURSO;
DROP TABLE telefone;
DROP TABLE METAL;
DROP TABLE ITEMFARMACIA;
DROP TABLE ESTOQUE;
DROP TABLE ITEM;
DROP TABLE ENDERECO;
DROP TABLE telefoneFarmacia;
DROP TABLE FARMACIA_PARCEIRA;

