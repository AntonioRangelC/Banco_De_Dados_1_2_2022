- ---------------------   << Trabalho Final - Video Games (Tema 1)  >>   ---------------------
--                                   SCRIPT DE POPULA (DML)                                   
-- Data Criacao ...........: 09/12/2022
-- Autor(es) ..............: Guilherme Peixoto Lima
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: TF1_Guilherme
-- 
-- 
-- PROJETO => 01 Base de Dados
--         => 31 Tabelas
-- 
-- --------------------------------------------------------------------------------------------
USE TF1_Guilherme;
    
INSERT INTO PESSOA (
    identificadorUnico,
    dataNacimento,
    email ,
    tipoSanguineo ,
    sexo ,
    estadoCivil ,
    profissao ,
    tipoIdentificacao ,
    tipoPEssoa 
    #Criar campo para nome do cliente
)
VALUES 
(19116252179,'1984-08-21', 'pedro_dacosta@hotmail.com.br','A-','M','Casado','Engenharia Ambiental e Sanitária','CPF','2'),
(19098819702,'1961-04-22', 'evelyn-gomes76@hotmail.com.br','O-','F','Casado','Engenharia Civil','CPF','1'),
(314710322,'1953-09-07', 'teresinha_fogaca@hotmail.com.br','A-','F','Casado','Engenharia de Minas','RG','1');


INSERT INTO CLIENTE (
    identificadorUnico 
)
VALUES 
('19098819702'),
('314710322');

INSERT INTO TERAPEUTA (
    tipoTerapeuta ,
    dataSaida ,
    dataAdmissao ,
    identificadorUnico 
)
VALUES
('HEICH','2100-01-01','2010-01-01',19116252179);


INSERT INTO SECAO_PAGAMENTO (
    periodicidadeAcompanhamento ,
    numeroSecoes ,
    precoTotal,
    dataSecao ,
    tipoSecao ,
    identificadorUnico ,
    pagamentoId ,
    tipo ,
    criadoEm ,
    atualizadoEm,
    parcelas,
    status
)
VALUES 
(40,2,120.00,'2019-03-02','HEICH',19098819702,1238717342,'credito','2019-03-02','2019-03-02',3, 'aprovado'),
(80,3,200.00,'2019-05-04','HEICH',314710322,1538717315,'pix','2019-05-04','2019-05-04',1, 'aprovado');

INSERT INTO ORGAOCHOQUE (
    nome 
)
VALUES ('Esôfago'),
 ('Estômago'),
 ('Intestino delgado'),
 ('Boca'),
 ('Intestino grosso'),
 ('Rins'),
 ('Bexiga'),
 ('Laringe'),
 ('Pulmões'),
 ('CORAÇÃO');

INSERT INTO RELATORIO_ACOMPANHAMENTO (
    dataRelatorio ,
    infoCliente ,
    tipoAcompanhamento ,
    idSecao      
)
VALUES 
('2019-03-02','O cliente possui um problema localizado no esôfago devido à grande ingestão de produtos contaminados muito ácido','corpo',1),
('2019-03-15','O cliente continua a possuir um problema localizado no esôfago devido à grande ingestão de produtos contendo muito ácido, mas já apresenta melhoras após o tratamento','corpo',1),

('2019-03-02','O cliente possui um problema localizado no intestino grosso e fígado devido à grande ingestão de produtos com muito alcool','corpo',1),
('2019-06-24','O cliente apresntou melhoras significativas no intestino grosso, mas é bom mais um acompanhamento para garantir a eficácia do tratamento, fígado tambem apresnetou melhoras','corpo',1),
('2019-12-09','O cliente esta sarado.','corpo',1);

INSERT INTO RECEITA (
    statusReceita,
    idRelatorio ,
    pessoaIdentificadorUnico ,
    terapeutaIdentificadorUnico
)
VALUES ('finalizada',1,19098819702,19116252179),
('finalizada',2,19098819702,19116252179),
('finalizada',3,314710322,19116252179),
('finalizada',4,314710322,19116252179)
;


INSERT INTO CURSO (
    nome  
)
VALUES  
('Diálogos Reichianos'),
('Psicofisiologia com base nas couraças'),
('O corpo revela os traços de caráter'),
('Residência Clínica em Análise Corporal Reichiana'),
('Massagem Reichiana e Complementares'),
('Terapia Corporal Reichiana'),
('Aromaterapia'),
('Alquimista de Ervas'),
('Instrutor de Zen'),
('Introdução a Barras de Access');

INSERT INTO telefone (
    telefone ,
    userId 
)
VALUES 
(1,21991863258),
(2,88983029692),
(3,8637253618),
(3,86994323620);
 
INSERT INTO CONSULTORIO (
    idReceitaConsultorio 
)
VALUES 
(1),
(2),
(3),
(4);


INSERT INTO FARMACIA (
    idReceitaFarmacia
)
VALUES 
(1),
(2),
(3),
(4);

INSERT INTO CONTAMINACAO (
    recomendacao ,
    relatorioId 
)
VALUES ('Recomenda-se parar de para de ingerir produtos industrializados e beber mais água, além disso utilizar Antidin 150mg 1 a cada dia', 1),
('Mesmo com a melhora recomenda-se utilizar o medicamento porém um a cada 2 dias', 2),
('Recomenda-se beber muita água e parar com a ingestao de bebidas alcoolias por completo duarnte 2 meses e meio e utilizacao de Prelone a cada 2 dias', 3),
('Com o bom avanço está liberado o uso de bebidas alcoolicas a cada 15 dias com a utilização de Prelone 20mg a cada 4 dias', 4)
;

INSERT INTO METAL (
    nome 
)
VALUES  ('sódio'),
        ('potássio'),
        ('cálcio'),
        ('ferro'),
        ('zinco'),
        ('cobre'),
        ('níquel'),
        ('magnésio'),
        ('arsênico'),
        ('Chumbo ');




INSERT INTO ITEM (
    #--Item aqui
    nome,
    precoVenda,
    descricao 
)
VALUES 
('Ziagenavir 20mg Glaxosmithkline 240ml', 347.29, "Ziagenavir 20mg Glaxosmithkline 240ml (sulfato de abacavir) é utilizado para tratamento da infecção causada pelo vírus HIV em combinação com outros medicamentos antirretrovirais. Uso adulto e pediátrico. Venda somente sob prescrição médica com retenção da receita."),
('Filinar Xarope Pediátrico 120ml', 23.69, "Filinar Xarope Pediátrico 120ml (Acebrofilina) indicado para tratar a obstrução dos brônquios. Possui ação broncodilatadora, atua no controle da quantidade de muco das vias respiratórias e ajuda na expectoração da secreção, deixando a respiração mais fácil. Leia a bula"),
('Flucistein Xarope 200mg/5g', 10.30, "Flucistein Xarope 200mg/5gUnião Química 15 envelopes é um medicamento indicado quando se tem dificuldade para expectorar e há muita secreção densa e viscosa, tais como bronquite aguda, bronquite crônica e suas exacerbações, enfisema pulmonar, pneumonia, atelectasias pulmonares, mucoviscidose."),
('Fluimucil Xarope Adulto Zambon 120ml',40.99 , "Fluimucil auxilia no tratamento de: Bronquite crônica e suas exacerbações, enfisema pulmonar, bronquite tabágica, bronquite aguda, broncopneumonia, abscessos pulmonares, atelectasias pulmonares, mucoviscidose (doença hereditária que produz muco espesso, também conhecida por fibrose cística) e outros. Também é indicado como antídoto na intoxicação acidental ou voluntária por paracetamol. Este medicamento é contra-indicado para pacientes com histórico de hipersensibilidade conhecida à acetilcisteína e/ou demais componentes de suas formulações. Não deve ser administrado à pacientes com úlcera gastroduodena"),
('Zovirax Creme 50mg GSK 10g', 54.09 ,"Zovirax Creme 50mg (aciclovir) antiviral utilizado para tratar infecções da pele causadas pelo vírus Herpes simplex, incluindo herpes genital e labial, seja o primeiro episódio ou recorrente. Zovirax deve ser aplicado sobre as lesões existentes ou emergentes, de preferência no início da infecção."),
('Avicis 0,025mg/ml Galderma Solução Capilar 100ml', 179.99 ,"Avicis 0,025mg/ml Solução Capilar (alfaestradiol) é indicado para tratamento da alopecia androgenética em homens e mulheres. Efeitos de melhora quanto à queda de cabelos podem ocorrer após no mínimo 1 mês de tratamento. Utilize de acordo com a prescrição médica."),
#--here
#-- Esôfago
('Antidin 150mg, caixa com 100 comprimidos revestidos',52.00 ,"Antidin contém ranitidina, substância que reduz a quantidade de ácido produzida no estômago. Isso favorece a cicatrização da gastrite e das úlceras pépticas do estômago e do duodeno, além de prevenir complicações. Após alguns dias de tratamento, você já deverá se sentir bem melhor. Mas não pare de usar Antidin antes do fim do período determinado pelo seu médico, pois a dor e o desconforto poderão voltar."),
('Suplemento Alimentar Capitrat Cabelos e Unhas 60 Cápsulas',46.39 ,"O Suplemento Alimentar Capitrat Cabelos e Unhas é formulado com cromo, biotina, piridoxina, selênio e zinco. É o suplemento alimentar ideal para suprir o organismo com os nutrientes essenciais para a manutenção da saúde e beleza de cabelos e unhas. Embalagem com 60 cápsulas gelatinosas."),
#-- estomago
('Laxante Muvinlax Limão 20 Sachês',40.99 ,"O Laxante Muvinlax é indicado para tratar prisão de ventre, impactação fecal e para preparo intestinal antes de cirurgias e determinados exames médicos. Sua ação laxante amolece as fezes e aumenta a frequência de evacuação. Uso de acordo com a prescrição médica."),
#-- intestino delgado
('Prelone 20mg Aché 10 Comprimidos',18.99 ,"Prelone 20mg Aché 10 Comprimidos (prednisolona) é indicado no tratamento de distúrbios endócrinos, reumáticos, doenças dermatológicas, alergias, doenças oftálmicas, respiratórias, distúrbios hematológicos, doenças neoplásticas, doenças gastrointestinais, doenças neurológicas e outras condições."),
#--Intestino grosso
('Lactosil Flora c/8 cápsulas Apsen',16.90 ,"Lactosil Flora possui combinação exclusiva de enzima lactase associada ao probiótico Lactobacillus acidophilus NCFM que: Auxilia na digestão da lactose e contribui com a saúde gastroinstestinal");



INSERT INTO ITEMFARMACIA (
    itemFarmaciaId 
)
VALUES 
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10);

INSERT INTO ESTOQUE (
    idItemEstoque , #-- Alterar isso pra puxar da tabela de intens
    quantidade ,
    dataAtualizacao,
    precoCusto 
)
VALUES
 (3, 1,'2020-05-02' , 347.29 ),
 (4, 2,'2019-05-02' , 20.69 ),
 (2, 3,'2022-02-22' , 09.30 ),
 (1, 4,'2021-02-23' , 38.99 ),
 (5, 5,'2022-02-22' , 50.09 ),
 (3, 6,'2019-06-02' , 160.99),
 (10, 7,'2018-09-02', 50.00 ),
 (4, 8,'2020-02-24' , 40.39 ),
 (7, 9,'2020-05-30' , 37.99 ),
 (8, 10,'2020-02-22' , 15.99);

INSERT INTO ENDERECO (
    cep ,
    cidade,
    complemento 
)
VALUES 
('40210735','Salvador','1ª Travessa de São Lázaro'), #--Federação, BA
('44004224','Feira de Santana','2ª Travessa das Américas'), #-- Chácara São Cosme,BA 
('48609500','Paulo Afonso','Rua Manaus'), #--Rodoviários, BA
('70760732','Brasília','Quadra SHCGN 713 Bloco B'), #--Asa Norte, DF
('60441050','Fortaleza','Vila do Cortiço'), #-- Pan Americano, CE
('55640574','Gravatá','Rua Santa Catarina'), #-- Campos do Jordão,PE
('27440070','Quatis','Praça Antônio de Paula Pacheco'), #-- Falcão, RJ
('86071300','Londrina','Rua Cajarana'), #-- Leonor, PR
('66643020','Belém','Rua Dois'), #-- São Clemente, PA
('61659060','Caucaia','Rua A'); #-- Nova Metrópole (Jurema), CE;

INSERT INTO FARMACIA_PARCEIRA (
    nomeFarmacia 
)
VALUES 
('Drogaria Félix Almeida'),
('Farmácia Integral'),
('N/C Medicinal Comércio de Medicamentos E Produtos F'),
('M S Meira Santana Guimarães'),
('Farmácia Ki Sara Ltda'),
('Drogaria São Paulo'),
('Farmacentro Comércio de Produtos Farmacêuticos'),
('Farma Hope Com'),
('J A Santana Farmácia'),
('Farmácia Mv');

INSERT INTO telefoneFarmacia (
    telefoneFarmacia ,
    idFarmacia
)
VALUES 
(7533322014, 1),
(7532621871, 2),
(7332662963, 3),
(3434492159, 4),
(7332961253, 5),
(1133472800, 6),
(7736116411, 7),
(7133972892, 8),
(7734135217, 9),
(7734238606, 10);

INSERT INTO habita (
	idEndereco,
    identificadorUnico 
)

VALUES 
(1,19116252179),
(2,19098819702),
(3,314710322);

INSERT INTO tem (
    relatorioId,
    orgaoChoqueNome
)
VALUES 
(1,'Esôfago'),
(4,'Intestino grosso');

INSERT INTO contem (
    contaminacaoId ,
    metalNome 
)
VALUES 
(1,'sódio'),
(2,'potássio'),
(3,'sódio');

INSERT INTO inclui (
    itemId ,
    idReceitaConsultorio 
)
VALUES 
(7,1),
(7,2),
(11,3)
;


INSERT INTO dispoe (
    itemId ,
    idFarmacia
)
VALUES 
(7,1),
(11,2),
(8,1)
;

INSERT INTO cursa (
    fk_TERAPEUTA_FK_PESSOA_identificadorUnico ,
    fk_CURSO_idCurso 
)
VALUES 
( 19116252179,1),
( 19116252179,2),
( 19116252179,3);

INSERT INTO localizada (
    idSecao ,
    idEndereco
)
VALUES (1,2),
(1,3);


INSERT INTO situada (
	idEndereco,
    idFarmacia 
)
VALUES 
(1 , 1),
(3 , 2);

INSERT INTO entregue (
    idReceita ,
    idFarmacia
)
VALUES 
(1,1),
(2,1),
(3,3),
(4,3);


INSERT INTO gerencia (
    identificadorUnico ,
    idEstoque 
)
VALUES 
(19116252179, 7),
(19116252179, 7) ,
(19116252179, 9);

INSERT INTO efetua (
    identificadorUnico,
    idSecao 
)
VALUES
 (19098819702,1),
 (314710322,2);
