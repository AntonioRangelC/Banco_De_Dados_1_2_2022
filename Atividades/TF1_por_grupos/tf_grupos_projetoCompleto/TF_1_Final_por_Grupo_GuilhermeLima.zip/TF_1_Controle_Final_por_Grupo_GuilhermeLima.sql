-- ---------------------   << Trabalho Final - Video Games (Tema 1)  >>   ---------------------
--
--                              SCRIPT DE CRIAÇÃO DE USUÁRIOS (DDL)                              
-- 
-- Data Criacao ...........: 12/09/2022
-- Autor(es) ..............: Guilherme Peixoto Lima
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: TF1_Guilherme
-- 
-- 
-- PROJETO => 01 Base de Dados
--         => 31 Tabelas
-- 
-- --------------------------------------------------------------------------------------------

USE TF1_Guilherme;

CREATE USER 'admin'@'localhost' IDENTIFIED BY '@d2022';
GRANT ALL PRIVILEGES ON  tf1c_guilherme. * TO 'admin'@'localhost';

CREATE USER 'cliente'@'localhost' IDENTIFIED BY 'cli2022';
GRANT SELECT ON  tf1c_guilherme. * TO 'cliente'@'localhost';

CREATE USER 'terapeuta'@'localhost' IDENTIFIED BY 'tr2022';
GRANT SELECT ON  tf1c_guilherme. * TO 'terapeuta'@'localhost';

FLUSH PRIVILEGES;