-- ---------------------  << TF Tema 1 >>   ------------------------ --
-- 																	 --
--                    SCRIPT DE CRIACAO (DDL)						 --
-- 																	 --
-- Data Criacao ...........: 10/09/2022								 --
-- Autor(es) ..............: Flávio Vieira Leão						 --
-- 							 Eduardo Rezende						 --
-- Banco de Dados .........: MySQL 8.0 								 --	
-- Banco de Dados(nome) ...: TF_1E_eduardorezende		  							 --
-- 																	 --
-- PROJETO => 01 Base de Dados										 --
--         => 20 Tabelas											 --
-- 																	 --
-- ----------------------------------------------------------------- --
CREATE DATABASE IF NOT EXISTS TF_1E_eduardorezende;
USE TF_1E_eduardorezende;

-- --------------------------------------------------------------
-- Tabela CLIENTE
-- --------------------------------------------------------------
CREATE TABLE CLIENTE (
	idCliente INT AUTO_INCREMENT NOT NULL,
	nome VARCHAR(80) NOT NULL,
	telefone BIGINT NOT NULL,
	cep INT NOT NULL,
	logradouro VARCHAR(45) NOT NULL,
	cidade VARCHAR(45) NOT NULL,
	estado CHAR(2) NOT NULL,
	complemento VARCHAR(100) NULL,
	cpf BIGINT NULL,
	rg VARCHAR(20) NULL,
	email VARCHAR(45) NULL,
	CONSTRAINT CLIENTE PRIMARY KEY (idCliente)
) ENGINE = InnoDB AUTO_INCREMENT = 1;


-- --------------------------------------------------------------
-- Tabela ALUNO
-- --------------------------------------------------------------
CREATE TABLE ALUNO (
	idAluno INT AUTO_INCREMENT NOT NULL,
	matricula INT NOT NULL,
	dtNascimento DATE NOT NULL,
	CONSTRAINT ALUNO PRIMARY KEY (idAluno),
    CONSTRAINT atributo_matricula_UK UNIQUE (matricula),
	CONSTRAINT ALUNO_CLIENTE_FK FOREIGN KEY (idAluno) 
		REFERENCES CLIENTE (idCliente) 
		ON DELETE RESTRICT 
		ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1;


-- --------------------------------------------------------------
-- Tabela CURSO
-- --------------------------------------------------------------
CREATE TABLE CURSO (
	codCurso INT AUTO_INCREMENT NOT NULL,
	nome VARCHAR(45) NOT NULL,
	cargaHoraria VARCHAR(45) NOT NULL,
	descricao VARCHAR(100) NULL,
	CONSTRAINT CURSO PRIMARY KEY (codCurso)
) ENGINE = InnoDB AUTO_INCREMENT = 1;


-- --------------------------------------------------------------
-- Tabela TURMA
-- --------------------------------------------------------------
CREATE TABLE TURMA (
	codTurma INT AUTO_INCREMENT NOT NULL,
	dtInicio DATE NOT NULL,
	dtFim DATE NOT NULL,
	codCurso INT NOT NULL,
	CONSTRAINT TURMA PRIMARY KEY (codTurma),
	CONSTRAINT TURMA_CURSO_FK FOREIGN KEY (codCurso) 
		REFERENCES CURSO (codCurso)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1;


-- --------------------------------------------------------------
-- Tabela matricula (relacionamento n:m entre ALUNO e TURMA)
-- --------------------------------------------------------------
CREATE TABLE matricula (
	idAluno INT NOT NULL,
	codTurma INT NOT NULL,
	CONSTRAINT matricula_UK UNIQUE (idAluno, codTurma),
	CONSTRAINT matricula_ALUNO_FK FOREIGN KEY (idAluno)
		REFERENCES ALUNO (idAluno)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT,
	CONSTRAINT matricula_TURMA_FK  FOREIGN KEY (codTurma)
		REFERENCES TURMA (codTurma)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1;


-- --------------------------------------------------------------
-- Tabela PEDIDO 
-- --------------------------------------------------------------
CREATE TABLE PEDIDO (
	idPedido INT AUTO_INCREMENT NOT NULL,
	dtPedido DATE NOT NULL,
	idCliente INT NOT NULL,
	CONSTRAINT PEDIDO PRIMARY KEY (idPedido),
	CONSTRAINT PEDIDO_CLIENTE_FK FOREIGN KEY (idCliente)
		REFERENCES CLIENTE (idCLIENTE)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1;


-- --------------------------------------------------------------
-- Tabela PRODUTO
-- --------------------------------------------------------------
CREATE TABLE PRODUTO (
	codProd INT AUTO_INCREMENT NOT NULL,
	nome VARCHAR(90) NOT NULL,
	precoCompra DECIMAL(7, 2) NOT NULL,
	precoVenda DECIMAL(7, 2) NOT NULL,
	qtdeEstoque INT NOT NULL,
	descricao VARCHAR(150) NULL,
	CONSTRAINT PRODUTO PRIMARY KEY (codProd)
) ENGINE = InnoDB AUTO_INCREMENT = 1;


-- --------------------------------------------------------------
-- Tabela contem (relacionamento n:m entre PRODUTO e PEDIDO)
-- --------------------------------------------------------------
CREATE TABLE contem (
	idPedido INT NOT NULL,
	codProd INT NOT NULL,
	quantidade INT NOT NULL,
	
	CONSTRAINT contem_UK UNIQUE (idPedido, codProd),
	CONSTRAINT contem_PEDIDO_FK FOREIGN KEY (idPedido)
		REFERENCES PEDIDO (idPedido)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT,
	CONSTRAINT contem_PRODUTO_FK FOREIGN KEY (codProd) 
		REFERENCES PRODUTO (codProd)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
) ENGINE = InnoDB;


-- --------------------------------------------------------------
-- Tabela PACIENTE
-- --------------------------------------------------------------
CREATE TABLE PACIENTE (
	idPaciente INT NOT NULL,
	tipoSangue ENUM('A', 'B', 'AB', 'O') NOT NULL,
	fatorRH ENUM('+', '-') NOT NULL,
	sexo ENUM('M', 'F') NOT NULL,
	dtNascimento DATE NOT NULL,
	CONSTRAINT PACIENTE PRIMARY KEY (idPaciente),
	CONSTRAINT PACIENTE_CLIENTE_FK FOREIGN KEY (idPaciente)
		REFERENCES CLIENTE (idCLIENTE)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
) ENGINE = InnoDB;


-- --------------------------------------------------------------
-- Tabela ATENDIMENTO
-- --------------------------------------------------------------
CREATE TABLE ATENDIMENTO (
	idAtendimento INT AUTO_INCREMENT NOT NULL,
	dtAgendamento DATE NOT NULL,
	hora TIME NOT NULL,
	situacao ENUM('1', '2', '3', '4', '5') NOT NULL DEFAULT '1',
	idPaciente INT NOT NULL,
	CONSTRAINT ATENDIMENTO PRIMARY KEY (idAtendimento),
	CONSTRAINT ATENDIMENTO_PACIENTE_FK FOREIGN KEY (idPaciente)
		REFERENCES PACIENTE (idPaciente)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1;


-- --------------------------------------------------------------
-- Tabela TESTE
-- --------------------------------------------------------------
CREATE TABLE TESTE (
	codTeste INT AUTO_INCREMENT NOT NULL,
	nome VARCHAR(45) NOT NULL,
	descricao VARCHAR(150) NULL,
	CONSTRAINT TESTE PRIMARY KEY (codTeste)
) ENGINE = InnoDB AUTO_INCREMENT = 1;


-- --------------------------------------------------------------
-- Tabela SESSAO_TESTE
-- --------------------------------------------------------------
CREATE TABLE SESSAO_TESTE (
	idAtendimento INT NOT NULL,
	codTeste INT NOT NULL,
	resultado VARCHAR(200) NULL,
	CONSTRAINT SESSAO_TESTE_ATENDIMENTO_FK FOREIGN KEY (idAtendimento)
		REFERENCES ATENDIMENTO (idAtendimento)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT,
	CONSTRAINT SESSAO_TESTE_TESTE_FK FOREIGN KEY (codTeste)
		REFERENCES TESTE (codTeste)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
) ENGINE = InnoDB;


-- --------------------------------------------------------------
-- Tabela CONSULTA
-- --------------------------------------------------------------
CREATE TABLE CONSULTA (
	idAtendimento INT NOT NULL,
	retorno ENUM('S', 'N') NOT NULL,
	anamnese VARCHAR(500) NULL,
	CONSTRAINT CONSULTA PRIMARY KEY (idAtendimento),
	CONSTRAINT CONSULTA_ATENDIMENTO_FK FOREIGN KEY (idAtendimento)
		REFERENCES ATENDIMENTO (idAtendimento)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
) ENGINE = InnoDB;


-- --------------------------------------------------------------
-- Tabela TERAPIA
-- --------------------------------------------------------------
CREATE TABLE TERAPIA (
	codTerapia INT AUTO_INCREMENT NOT NULL,
	nome VARCHAR(45) NOT NULL,
	duracao VARCHAR(10) NOT NULL,
	descricao VARCHAR(150) NULL,
	CONSTRAINT TERAPIA PRIMARY KEY (codTerapia)
) ENGINE = InnoDB AUTO_INCREMENT = 1;


-- --------------------------------------------------------------
-- Tabela SESSAO_TERAPIA
-- --------------------------------------------------------------
CREATE TABLE SESSAO_TERAPIA (
	idAtendimento INT NOT NULL,
	codTerapia INT NOT NULL,
	orientacao VARCHAR(150) NULL,
	CONSTRAINT SESSAO_TERAPIA_ATENDIMENTO_FK FOREIGN KEY (idAtendimento)
		REFERENCES ATENDIMENTO (idAtendimento)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT,
	CONSTRAINT SESSAO_TERAPIA_TERAPIA_FK FOREIGN KEY (codTerapia)
		REFERENCES TERAPIA (codTerapia)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
) ENGINE = InnoDB;


-- --------------------------------------------------------------
-- Tabela RECEITA
-- --------------------------------------------------------------
CREATE TABLE RECEITA (
	codReceita INT AUTO_INCREMENT NOT NULL,
	dtReceita DATE NOT NULL,
	idAtendimento INT NOT NULL,
	orientacao VARCHAR(100) NULL,
	CONSTRAINT RECEITA PRIMARY KEY (codReceita),
	CONSTRAINT RECEITA_CONSULTA_FK FOREIGN KEY (idAtendimento)
		REFERENCES CONSULTA (idAtendimento)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1;


-- --------------------------------------------------------------
-- Tabela demanda (relacionamento n:m entre TESTE e RECEITA)
-- --------------------------------------------------------------
CREATE TABLE demanda (
	codReceita INT NOT NULL,
	codTeste INT NOT NULL,
	CONSTRAINT demanda_UK UNIQUE (codReceita, codTeste),
	CONSTRAINT demanda_RECEITA_FK FOREIGN KEY (codReceita)
		REFERENCES RECEITA (codReceita)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT,
	CONSTRAINT demanda_TESTE_FK FOREIGN KEY (codTeste)
		REFERENCES TESTE (codTeste)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
) ENGINE = InnoDB;


-- -----------------------------------------------------------------------
-- Tabela prescreve (relacionamento n:m entre TERAPIA e RECEITA)
-- -----------------------------------------------------------------------
CREATE TABLE prescreve (
	codReceita INT NOT NULL,
	codTerapia INT NOT NULL,
	numSessao INT NOT NULL,
	CONSTRAINT prescreve_UK UNIQUE (codReceita, codTerapia),
	CONSTRAINT prescreve_RECEITA_FK FOREIGN KEY (codReceita)
		REFERENCES RECEITA (codReceita)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT,
	CONSTRAINT prescreve_TERAPIA_FK FOREIGN KEY (codTerapia)
	REFERENCES TERAPIA (codTerapia)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
) ENGINE = InnoDB;



-- -----------------------------------------------------------------------
-- Tabela tem (relacionamento n:m entre PRODUTO e RECEITA)
-- -----------------------------------------------------------------------
CREATE TABLE tem (
	codReceita INT NOT NULL,
	codProd INT NOT NULL,
	CONSTRAINT tem_UK UNIQUE (codReceita, codProd),
	CONSTRAINT tem_RECEITA_FK FOREIGN KEY (codReceita)
		REFERENCES RECEITA (codReceita)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT,
	CONSTRAINT tem_PRODUTO_FK FOREIGN KEY (codProd)
		REFERENCES PRODUTO (codProd)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
) ENGINE = InnoDB;


-- --------------------------------------------------------------
-- Tabela RECEITA_EXTERNA
-- --------------------------------------------------------------
CREATE TABLE RECEITA_EXTERNA (
	codReceita INT NOT NULL,
	posologia VARCHAR(90) NOT NULL,
	produto VARCHAR(45) NOT NULL,
	quantidade INT NOT NULL,
	CONSTRAINT RECEITA_EXTERNA_RECEITA_FK FOREIGN KEY (codReceita)
		REFERENCES RECEITA (codReceita)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
) ENGINE = InnoDB;

