-- ---------------------  << TF Tema 1 >>   ------------------------ --
-- 																	 --
--                       SCRIPT DE CONTROLE     				     --
-- 																	 --
-- Data Criacao ...........: 12/09/2022								 --
-- Autor(es) ..............: Eduardo Rezende					     --
-- 							 Flávio Vieira Leão						 --
-- Banco de Dados .........: MySQL 8.0 								 --				   
-- Banco de Dados(nome) ...: TF_1E_eduardorezende 		             --
-- 																	 --
-- Ultimas Alteracoes: 18/09/2022 =>                                 --
--   Incluido 3 usuários (um para cada perfil cadastrado)            --
--                                                                   --
-- PROJETO => 01 Base de Dados										 --
--         => 20 Tabelas											 --
-- 																	 --
-- ----------------------------------------------------------------- --
use TF_1E_eduardorezende;

CREATE ROLE proprietario, gerente, funcionario;

-- -----------------------------------------------------------------
-- Perfil proprietario:
-- todos os privilegios na base de dados TFT1
GRANT ALL
ON TF_1E.* 
TO proprietario
WITH GRANT OPTION;

-- ------------------------------------------------------------------
-- Perfil gerente: 
-- privilegios de leitura e escrita na base de dados TFT1
GRANT SELECT, INSERT, UPDATE, DELETE
ON TF_1E.* 
TO gerente
WITH GRANT OPTION;

-- ------------------------------------------------------------------
-- Perfil funcionario:
-- privilegios somente de leitura na base de dados TFT1
GRANT SELECT
ON TF_1E.* 
TO funcionario;

-- -----------------------------------------------------------------

-- Usuário antonia:
-- privilegios de proprietário
CREATE USER antonia IDENTIFIED BY 'Ainotna321@';
GRANT proprietario TO antonia;
-- -----------------------------------------------------------------
-- Usuário cibele:
-- privilegios de gerente
CREATE USER cibele IDENTIFIED BY 'Elebic321@';
GRANT gerente TO cibele;

-- -----------------------------------------------------------------
-- Usuário funcionario01:
-- privilegios de funcionário
CREATE USER funcionario01 IDENTIFIED BY 'Func321@';
GRANT funcionario TO funcionario01;

-- -----------------------------------------------------------------


