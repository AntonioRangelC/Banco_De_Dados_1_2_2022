-- ---------------------  << TF Tema 1 >>   ------------------------ --
-- 																	 --
--                   SCRIPT DE EXCLUSÃO (DDL) 						 --
-- 																	 --
-- Data Criacao ...........: 10/09/2022								 --
-- Autor(es) ..............: Flávio Vieira Leão						 --
-- 							 Eduardo Rezende						 --
-- Banco de Dados .........: MySQL 8.0 								 --				   
-- Banco de Dados(nome) ...: TF_1E_eduardorezende		     		 --
-- 																	 --
-- Ultimas Alteracoes: 
-- 	 11/09/2022 => Incluido drop dos pefis;                          --
-- 	 18/09/2022 => Incluido drop dos usuaŕios;                       --
--
-- PROJETO => 01 Base de Dados										 --
--         => 20 Tabelas											 --
-- 																	 --
-- ----------------------------------------------------------------- --
USE TF_1E_eduardorezende;

DROP TABLE RECEITA_EXTERNA;
DROP TABLE tem;
DROP TABLE prescreve;
DROP TABLE demanda;
DROP TABLE RECEITA;
DROP TABLE SESSAO_TERAPIA;
DROP TABLE TERAPIA;
DROP TABLE CONSULTA;
DROP TABLE SESSAO_TESTE;
DROP TABLE TESTE;
DROP TABLE ATENDIMENTO;
DROP TABLE PACIENTE;
DROP TABLE contem;
DROP TABLE PRODUTO;
DROP TABLE PEDIDO;
DROP TABLE matricula;
DROP TABLE TURMA;
DROP TABLE CURSO;
DROP TABLE ALUNO;
DROP TABLE CLIENTE;
DROP ROLE proprietario;
DROP ROLE gerente;
DROP ROLE funcionario;
DROP USER antonia;
DROP USER cibele;
DROP USER funcionario01;
