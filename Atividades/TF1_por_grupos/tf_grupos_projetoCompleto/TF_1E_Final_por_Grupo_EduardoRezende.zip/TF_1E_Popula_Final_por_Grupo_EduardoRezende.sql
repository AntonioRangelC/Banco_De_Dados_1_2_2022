-- ---------------------  << TF Tema 1 >>   ------------------------ --
-- 																	 --
--                    SCRIPT DE POPULACAO (DML)                      --
-- 																	 --
-- Data Criacao ...........: 10/09/2022								 --
-- Autor(es) ..............: Flávio Vieira Leão						 --
-- 							 Eduardo Rezende						 --
-- Banco de Dados .........: MySQL 8.0 								 --				   
-- Banco de Dados(nome) ...: TF_1E_eduardorezende		  				     		 --
-- 																	 --
--  Ultimas Alteracoes: 18/09/2022 =>                                --
--    Incluido 5 novas(com valores reais) tuplas para cada tabela    --
--                                                                   -- 
-- PROJETO => 01 Base de Dados										 --
--         => 20 Tabelas											 --
-- 																	 --
-- ----------------------------------------------------------------- --

-- BASE DE DADOS
USE  TF_1E_eduardorezende;
-- ----------------------------------------------------------------- --



-- INSERCOES
-- ----------------------------------------------------------------- --
INSERT INTO CLIENTE 
	(nome, telefone, cep, logradouro, cidade, estado, complemento, cpf, rg, email)
VALUES 
	('Pedro Sampaio', 61996580094, 73360459, 'Rua Pirineus Lagoa', 'Gama',       'DF', 'Perto da padaria',            060026622198, '3421651', 'pedrosampaio@gmail.com'),
	('Jose Silveira', 61896580095, 75360432, 'Rua Paulo Linhares', 'Guará',      'DF', 'Perto do Comper',             070026627800, '4421622', 'pedrosilva@gmail.com'),
	('Carlos Rafael', 61926583494, 76360543, 'Rua Costa Moura II', 'Planaltina', 'DF', 'Perto da Delegacia',          089726622155, '5421684', 'carlosrafael@gmail.com'),
	('Jullio Moreno', 61956583392, 77360734, 'Rua Charles Davila', 'Lago Norte', 'DF', 'Perto do Hospital Regional',  090026622133, '6421638', 'juliomorenoo@gmail.com'),
	('Maria Freirer', 61826589993, 78360845, 'Rua Alexandre Jose', 'Paranoa',    'DF', 'Perto do Corpo de Bombeiros', 058026622122, '7421697', 'alessandrafreire@gmail.com'),
    ('Carla Oliveira', 61996589999, 73360460, 'Rua Lourdes Gama', 'Vicente Pires','DF', 'Perto da Mercearia', 060026622198, '3421699', 'carlaoliveira@gmail.com'),
	('Lucimar Maia', 61896580087, 75360487, 'Rua Otavio Mesquita', 'Guará',      'DF', 'Perto do Posto Ipiranga',             070026627887, '4421687', 'lucimarmaia@gmail.com'),
	('Fernando Rezende', 61926583489, 76360589, 'Rua Costa Moura I', 'Planaltina', 'DF', 'Perto do Hospital Albert Einstein',          089726622189, '5421689', 'fernandorezende@gmail.com'),
	('Leticia Mouhamad', 61956583312, 77360712, 'Rua Matin Davila', 'Lago Norte', 'DF', 'Perto da Praça Dombosco',  090026622112, '6421612', 'leticiamouhamad@gmail.com'),
	('Adão Oliveira', 61826589934, 78360834, 'Rua José Henrique', 'Paranoa',    'DF', 'Perto do Quartel da PM', 058026622134, '7421634', 'adaooliveira@gmail.com');


INSERT INTO ALUNO
	(matricula, dtNascimento)
VALUES
	(159293949, '2000-04-23'),
	(169293950, '1998-05-10'),
	(179293951, '1999-06-15'),
	(189293952, '1988-07-17'),
	(199293953, '2005-08-29'),
    (159293912, '2000-04-29'),
	(169293921, '1998-05-27'),
	(179293934, '1999-06-12'),
	(189293943, '1988-07-10'),
	(199293954, '2005-08-23'); 
	
        
INSERT INTO CURSO
	(nome, cargaHoraria, descricao)
VALUES
	('Reiki Iniciante',   5, 'Curso de Reiki para iniciantes'),
	('Karuma Reiki',     10, 'Curso de uma modalidade de Reike focada nos campos  emocionais'),
	('Barras de access', 22, 'Curso completo de uma terapia holistica'),
	('Reiki nivel II',   15, 'Curso de Reiki para intermediarios'),
	('Reiki Avançado',   60, 'Curso de Reiki para avançados'),
    ('Reiki Iniciante II',   5, 'Curso de Reiki para iniciantes - Segundo módulo'),
	('Karuma Reiki II',     10, 'Curso de uma modalidade de Reike focada nos campos  emocionais - Segundo módulo'),
	('Barras de access II', 22, 'Curso completo de uma terapia holistica - Segundo módulo'),
	('Reiki nivel III',   15, 'Curso de Reiki para intermediarios - Terceiro módulo'),
	('Reiki Avançado II',   60, 'Curso de Reiki para avançados - Segundo módulo');


INSERT INTO TURMA
	(dtInicio, dtFim, codCurso)
VALUES
	('2022-04-23', '2022-04-24', '1'),
	('2022-05-13', '2022-05-14', '2'),
	('2022-06-10', '2022-06-11', '3'),
	('2022-07-08', '2022-07-09', '4'),
	('2022-08-15', '2022-08-16', '5'),
    ('2022-04-15', '2022-04-16', '6'),
	('2022-05-08', '2022-05-09', '7'),
	('2022-06-10', '2022-06-11', '8'),
	('2022-07-13', '2022-07-14', '9'),
	('2022-08-23', '2022-08-25', '10');
			
            
INSERT INTO PACIENTE
	(idPaciente, tipoSangue, fatorRH, sexo, dtNascimento)
VALUES
	(1, 'A',  '+', 'M', '2000-04-18'),
	(2, 'B',  '-', 'M', '1987-05-12'),
	(3, 'O',  '+', 'M', '2015-06-13'),
	(4, 'AB', '-', 'M', '1995-07-23'),
	(5, 'A',  '+', 'F', '2003-08-03'),
    (6, 'A',  '+', 'F', '2000-04-29'),
	(7, 'B',  '-', 'F', '1998-05-27'),
	(8, 'O',  '+', 'M', '1999-06-12'),
	(9, 'AB', '-', 'F', '1988-07-10'),
	(10, 'A',  '+', 'M', '2005-08-23');
    

INSERT INTO ATENDIMENTO
	(hora, dtAgendamento, situacao, idPaciente)
VALUES
	('08:30:00','2022-08-31', '1', 1),
	('09:00:00','2022-08-31', '2', 2),
	('09:30:00','2022-08-31', '3', 3),
	('10:00:00','2022-08-31', '4', 4),
	('10:30:00','2022-08-31', '1', 5),
    ('11:00:00','2022-08-31', '1', 6),
	('11:30:00','2022-08-31', '2', 7),
	('14:00:00','2022-08-31', '3', 8),
	('14:30:00','2022-08-31', '4', 9),
	('15:30:00','2022-08-31', '1', 10),
    ('08:30:00','2022-09-10', '1', 1),
	('09:00:00','2022-09-10', '2', 2),
	('09:30:00','2022-09-10', '3', 3),
	('10:00:00','2022-09-10', '4', 4),
	('10:30:00','2022-09-10', '1', 5),
    ('11:00:00','2022-09-10', '1', 6),
	('11:30:00','2022-09-10', '2', 7),
	('14:00:00','2022-09-10', '3', 8),
	('14:30:00','2022-09-10', '4', 9),
	('15:30:00','2022-09-10', '1', 10),
    ('08:30:00','2022-08-12', '1', 1),
	('09:00:00','2022-08-12', '2', 2),
	('09:30:00','2022-08-12', '3', 3),
	('10:00:00','2022-08-12', '4', 4),
	('10:30:00','2022-08-12', '1', 5),
    ('11:00:00','2022-08-12', '1', 6),
	('11:30:00','2022-08-12', '2', 7),
	('14:00:00','2022-08-12', '3', 8),
	('14:30:00','2022-08-12', '4', 9),
	('15:30:00','2022-08-12', '1', 10);


INSERT INTO TESTE
	(nome, descricao)
VALUES
	('Teste Molecular',     'Teste de moléculas quantico'),
	('Teste Celular',       'Teste de células quantico'),
	('Teste de Particulas', 'Teste de particulas quantico'),
	('Teste de Toxinas ',   'Teste de toxinas quantico'),
	('Teste de Energia',    'Teste de energia quantico'),
    ('Teste Molecular Profundo',     'Teste de moléculas quantico profundo'),
	('Teste de luminosidade celular',       'Teste de células quantico com luminometria'),
	('Teste de Cristais Orgânicos', 'Teste de particulas quanticos com cristais'),
	('Teste de Toxinas Especifico',   'Teste de toxinas quanticas especificas'),
	('Teste de Energia e Chakras',    'Teste de energia e chakras quantico');


INSERT INTO SESSAO_TESTE
	(idAtendimento, codTeste, resultado)
VALUES
	(1, 1, 'positivo'),
	(2, 2, 'negativo'),
	(3, 3, 'indeterminado'),
	(4, 4, 'positivo'),
	(5, 5, 'contaminado chumbo'),
    (6, 6, 'positivo'),
	(7, 7, 'negativo'),
	(8, 8, 'indeterminado'),
	(9, 9, 'positivo'),
	(10, 10, 'contaminado cobre');
			

INSERT INTO CONSULTA
	(idAtendimento, retorno, anamnese)
VALUES
	(11, 'N', 'Cefaléia importante; Etilismo; Tabagismo'),
	(12, 'S', 'Apatia ; Etilismo; Tabagismo'),
	(13, 'N', 'Anemia importante; Tabagismo'),
	(14, 'N', 'Cefaléia importante; Etilismo'),
	(15, 'S', 'Epilepsia ; Etilismo; Tabagismo'),
    (16, 'N', 'Cefaléia importante; Etilismo; Tabagismo'),
	(17, 'S', 'Apatia ; Etilismo; Tabagismo'),
	(18, 'N', 'Anemia importante; Tabagismo'),
	(19, 'N', 'Cefaléia importante; Etilismo'),
	(20, 'S', 'Epilepsia ; Etilismo; Tabagismo');


INSERT INTO TERAPIA
	(duracao, nome, descricao)
VALUES
	('50 min', 'Detoxicação Quantica',    'Eliminação de toxinas quanticas'),
	('20 mim', 'Detoxicação Molecular',   'Eliminação de toxinas quanticas molecular'),
	('80 min', 'Detoxicação de Cristais', 'Eliminação de toxinas utilizando cristais quanticas'),
	('30 min', 'Re-energização corpórea', 'Energização de particulas do corpo'),
	('40 min', 'Karuma Reiki III',        'Alinhamento de centros de energia'),
    ('50 min', 'Detoxicação Quantica (Cristais)',    'Eliminação de toxinas quanticas utilizando cristais'),
	('20 mim', 'Detoxicação Molecular (Florais)',   'Eliminação de toxinas quanticas molecular utilizando florais'),
	('80 min', 'Detoxicação de Chakra', 'Eliminação de toxinas no chakra utilizando cristais quanticos '),
	('30 min', 'Re-energização de sistemas', 'Energização de particulas dos sistemas do corpo'),
	('40 min', 'Karuma Reiki II',        'Alinhamento de centros de energia II');


INSERT INTO SESSAO_TERAPIA
	(idAtendimento, codTerapia, orientacao)
VALUES
	('21','5','Tomar agua com limão ao acordar'),
	('22','4','Evitar luz solar'),
	('23','3','Tomar agua com limão ao acordar'),
	('24','2','Ingerir frutas vermelhas diáriamente'),
	('25','1','Tomar agua com limão ao acordar'),
    ('26','6','Tomar agua com limão ao acordar'),
	('27','7','Evitar luz solar'),
	('28','8','Tomar agua com limão ao acordar'),
	('29','9','Ingerir frutas vermelhas diáriamente'),
	('30','10','Tomar agua com limão ao acordar');

    
INSERT INTO RECEITA
	(idAtendimento, dtReceita, orientacao)
VALUES
	(11, '2022-09-20', 'Ingerir os florais indicados em jejum'),
	(12, '2021-10-22', 'Ingerir os florais indicados após o almoço'),
	(13, '2020-01-28', 'Ingerir os florais indicados antes de dormir'),
	(14, '2022-05-12', 'Ingerir os florais indicados após o café da manhã'),
	(15, '2021-07-15', 'Ingerir os florais indicados a cada 12h'),
    (16, '2022-09-20', 'Ingerir os florais indicados em jejum'),
	(17, '2021-10-22', 'Ingerir os florais indicados após o almoço'),
	(18, '2020-01-28', 'Ingerir os florais indicados antes de dormir'),
	(19, '2022-05-12', 'Ingerir os florais indicados após o café da manhã'),
	(20, '2021-07-15', 'Ingerir os florais indicados a cada 12h');
            

INSERT INTO RECEITA_EXTERNA
	(codReceita, produto, posologia, quantidade)
VALUES
	(1, 'Neosaldina 10mg',  'Ingerir sempre que sentir dor', 4),
	(2, 'Fluoxetina 10mg',  'Ingerir sempre que sentir dor', 2),
	(3, 'Dipirona 10mg',    'Ingerir sempre que sentir dor', 1),
	(4, 'Parecetamol 10mg', 'Ingerir sempre que sentir dor', 3),
	(5, 'Neosaldina 20mg',  'Ingerir sempre que sentir dor', 2),
    (6, 'Neosaldina 10mg',  'Ingerir sempre que sentir dor', 4),
	(7, 'Fluoxetina 10mg',  'Ingerir sempre que sentir dor', 2),
	(8, 'Dipirona 10mg',    'Ingerir sempre que sentir dor', 1),
	(9, 'Parecetamol 10mg', 'Ingerir sempre que sentir dor', 3),
	(10, 'Neosaldina 20mg',  'Ingerir sempre que sentir dor', 2);
            
            
INSERT INTO PRODUTO
	(nome, descricao, precoCompra, precoVenda, qtdeEstoque)
Values
	('Floral fluoxetina 50mg', 'Em gotas',      10.00, 19.99, 10),
	('Floral mimulus 20mg',    'Em capsulas',   15.00, 29.99, 25),
	('Floral Rock Rose 10mg',  'Em gotas',      20.00, 39.99, 95),
	('Floral Cherry 30mg',     'Em comprimido', 30.00, 55.99, 45),
	('Floral Aspen 20mg',      'Em capsulas',   40.00, 49.99, 51),
    ('Floral Sete Chakras 50mg', 'Em gotas',      10.00, 19.99, 10),
	('Floral Resgate 20mg',    'Em capsulas',   15.00, 29.99, 25),
	('Floral Foco Fit 10mg',  'Em gotas',      20.00, 39.99, 95),
	('Floral Desmamim 30mg',     'Em comprimido', 30.00, 55.99, 45),
	('Floral Escolare 20mg',      'Em capsulas',   40.00, 49.99, 51);


INSERT INTO PEDIDO
	(dtPedido, idCliente)
VALUES
	('2022-08-29', 1 ),
	('2022-08-30', 2 ),
	('2022-09-30', 3 ),
	('2022-10-25', 4 ),
	('2022-07-20', 5 ),
    ('2022-08-29', 6 ),
	('2022-08-30', 7 ),
	('2022-09-30', 8 ),
	('2022-10-25', 9 ),
	('2022-07-20', 10 );
    
    
INSERT INTO matricula
	(idAluno, codTurma)
VALUES
	(1, 1),
	(2, 2),
	(3, 3),
	(4, 4),
	(5, 5),
    (6, 6),
	(7, 7),
	(8, 8),
	(9, 9),
	(10, 10);
    
    
INSERT INTO contem
	(idPedido, codProd, quantidade)
VALUES
	(1, 5, 1),
	(2, 4, 2),
	(3, 3, 3),
	(4, 2, 4),
	(5, 1, 5),
    (6, 6, 6),
	(7, 7, 7),
	(8, 8, 8),
	(9, 9, 9),
	(10, 10, 10);
            
INSERT INTO demanda
	(codTeste, codReceita)
VALUES
	(1, 5),
	(2, 4),
	(3, 3),
	(4, 2),
	(5, 1),
    (6, 6),
	(7, 7),
	(8, 8),
	(9, 9),
	(10, 10);


INSERT INTO prescreve
	(codReceita, codTerapia, numSessao)
VALUES
	(1, 5, 1),
	(2, 4, 3),
	(3, 3, 2),
	(4, 2, 4),
	(5, 1, 5),
    (6, 6, 6),
	(7, 7, 7),
	(8, 8, 8),
	(9, 9, 9),
	(10, 10, 10);

           
INSERT INTO tem
	(codProd, codReceita)
VALUES
	(1, 5),
	(2, 4),
	(3, 3),
	(4, 2),
	(5, 1),
    (6, 6),
	(7, 7),
	(8, 8),
	(9, 9),
	(10, 10);
			