-- --------  << Trabalho Final Tema 1 >>  ----------
--
--                    SCRIPT DE REMOCAO (DDL)
--
-- Data Criacao ...........: 19/09/2022
-- Autor(es) ..............: Davi Marinho da Silva Campos, André Macedo Rodrigues Alves, Guilherme Brito Vilas - Bôas e Arthur Popov
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1B_davicampos
--
-- PROJETO => 01 Base de Dados
--         => 18 Tabelas
--         => 07 Usuários
--         => 04 Roles
--
-- ---------------------------------------------------------


-- BASE DE DADOS
USE TF_1B_davicampos;

-- TABELAS

DROP TABLE palestra;

DROP TABLE inscrito;

DROP TABLE WORKSHOP;

DROP TABLE TURMA;

DROP TABLE CURSO;

DROP TABLE FORMULARIO;

DROP TABLE PROTOCOLO;

DROP TABLE PRESCRICAO;

DROP TABLE ACOMPANHAMENTO;

DROP TABLE DOCUMENTO;

DROP TABLE SESSAO;

DROP TABLE CONSULTA;

DROP TABLE PALESTRANTE;

DROP TABLE ALUNO;

DROP TABLE compra;

DROP TABLE PACIENTE;

DROP TABLE PESSOA;

DROP TABLE PRODUTO;



-- USERS
DROP USER 'matheus';

DROP USER 'joao';

DROP USER 'marcos';

DROP USER 'paulo';

DROP USER 'pedro';

DROP USER 'ana';

DROP USER 'amanda';

DROP USER 'antonia';

DROP USER 'lucas';

DROP USER 'aline';

DROP USER 'jose';

DROP USER 'rodrigo';

-- ROLES

DROP ROLE 'ADMIN';

DROP ROLE 'GERENTE_LOJA';

DROP ROLE 'DIRETOR_CURSO';

DROP ROLE 'TERAPEUTA';