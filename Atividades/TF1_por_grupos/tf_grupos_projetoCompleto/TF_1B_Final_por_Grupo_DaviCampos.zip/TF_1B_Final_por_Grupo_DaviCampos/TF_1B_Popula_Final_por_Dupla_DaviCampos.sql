-- --------  << Trabalho Final Tema 1 >>  ----------
--
--                    SCRIPT DE INSERCAO (DDL)
--
-- Data Criacao ...........: 19/09/2022
-- Autor(es) ..............: Davi Marinho da Silva Campos, André Macedo Rodrigues Alves, Guilherme Brito Vilas - Bôas e Arthur Popov
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1B_davicampos
--
-- PROJETO => 01 Base de Dados
--         => 18 Tabelas
--         => 04 Perfis
--         => 12 Usuários
--
-- ---------------------------------------------------------

-- BASE DE DADOS
USE TF_1B_davicampos;

-- INSERÇÃO DE PRODUTOS
INSERT INTO PRODUTO (saldoEstoque, precoVenda, precoCusto, descricaoProduto) VALUES
	(5, 20.5, 8.25, 'Cimicifuga (actea racemosa)'),
    (5, 22.5, 10.25, 'Castanha da Índia'), 
    (5, 45.5, 23.25, 'Erva de São João'), 
    (5, 10.5, 5.25, 'Camomila'), 
    (5, 5.5, 3.25, 'Celêndula'),
    (2, 57.00, 42.98,'Liganum 50 ml'),
	(1, 57.00, 42.98,'Linfodetox 50 ml'),
	(1, 73.00, 55.86,'Mentalis 100 ml gel'),
	(1, 130.00, 79.30, 'Multicatal'),
	(4, 57.00, 42.98,'Nefron 50 ml');

-- INSERÇÃO DE PESSOA
INSERT INTO PESSOA (cpf, rg, nome, telefone, dataNascimento, email, sexo, endereco, cidade, cep, complemento) VALUES
	(23026428051, 230493300, 'Pedro Menezes', '5127354497', '1995-09-28', 'pedromenezes@gmail.com', 'M', 'QI 22 LOTE 3', 'GUARA I', 71060274, null),
    (53855000034, 507391147, 'Paulo Vitor Messias', '6835953576', '1983-05-18', 'paulovitorm@gmail.com', 'M', 'QR 135 LOTE 4', 'GUARA II', 71060268, 'Na esquina da Rua'),
    (71305272005, 438084998, 'Julia Lima Moraes', '6128046207', '1996-01-28', 'julinhalm@gmail.com', 'F', 'RUA DAS PALMEIRAS', 'UBERLANDIA', 84510984, 'Perto do Shopping'),
    (91556335016, 251731650, 'Fernando Costa Alves', '6226995344', '1972-10-18', 'ferncosta@gmail.com', 'M', 'QI 22 LOTE 1', 'GUARA II', 71060271, 'Primeira casa da rua'),
    (88808198014, 422156449, 'Matheus Miguel de Bragança', '6727645208', '2003-09-30', 'matmiguelbrag@gmail.com', 'M','QIB 224 LOTE 1', 'OCIDENTAL', 71060264, 'Em frente ao posto Ipiranga'),
    (39977967008, '3465403','Guilherme Brito Vilas - Bôas','61981004207' , '2002-04-26', 'guigui26@gmail.com', 'M', 'QA 84 casa 2', 'GOIANIA', 71060215, 'Casa dos Fundos'),
	(94148340010, '3465480', 'Rogerio da Silva', '61981004206', '1998-10-10', 'rogege@gmail.com', 'M', 'QUADRA 8 LOTE 6', 'CRUZEIRO', 71060845, 'Na esquina da rua 2 com a rua 5'),
	(15168313060, '5760379','Ana Maria da Silva','85981457541',  '1975-05-08','anana@hotmail.com', 'F', 'Rua 1 Chácara 8', 'GAMA', 14510487, 'Perto do Quartel dos Bombeiros'),
	(51162087021, '7845164','Davi Leite', '11984751425' , '1987-08-14', 'davivi@outlook.com', 'M', 'W3 SUL QUADRA 8 APARTAMENTO 120', 'ASA SUL', 78451340, null),
	(56648009098, '84651754' ,'Rosa Fátima','21984514213' , '1954-12-31', 'rosasa@gmail.com', 'F', 'QI 22 LOTE 1', 'ASA NORTE', 75104512, null);
    
-- INSERÇÃO DE PACIENTE
INSERT INTO PACIENTE (cpf, estadoCivil, profissao) VALUES
	(23026428051, 'SOLTEIRO', 'Engenheiro de Software'),
    (53855000034, 'CASADO', 'Fisioterapeuta'),
    (71305272005, 'SOLTEIRO', 'Professor'),
    (91556335016, 'CASADO', 'Administrador de Banco de Dados'),
    (88808198014, 'VIUVO', 'Estudante'),
    (39977967008, 'SOLTEIRO', 'Médico'),
    (94148340010, 'CASADO', 'Policial'),
    (15168313060, 'DIVORCIADO', 'Bombeiro'),
    (51162087021, 'DIVORCIADO', 'Empresário'),
    (56648009098, 'SOLTEIRO', 'Estudante');

-- INSERÇÃO DE ALUNO
INSERT INTO ALUNO (cpf, matriculaCurso) VALUES
	(23026428051, 1),
    (53855000034, 2),
    (71305272005, 3),
    (91556335016, 4),
    (88808198014, 5),
    (39977967008, 3),
    (94148340010, 4),
    (15168313060, 1),
    (51162087021, 3),
    (56648009098, 3);

-- INSERÇÃO DE PALESTRANTE
INSERT INTO PALESTRANTE (cpf, formacao) VALUES
	(23026428051, 'Terapia Ocupacional'),
    (53855000034, 'Reiki'),
    (71305272005, 'Pedagogia'),
    (91556335016, 'Serviço Social'),
    (88808198014, 'Barra de Access'),
    (39977967008, 'Farmácia'),
    (94148340010, 'Medicina'),
    (15168313060, 'Farmácia'),
    (51162087021, 'Fisioterapia'),
    (56648009098, 'Reiki');

-- INSERÇÃO DE CONSULTA
INSERT INTO CONSULTA (cpf, queixaPrincipal, fichaDesintoxicacao) VALUES
(23026428051, 'Dores de cabeça constantes', 'Teste Ortobiomolecular'),
(53855000034, 'Cansaço a todo momento', 'Teste Ortobiomolecular'),
(71305272005, 'Ansiedade', 'Teste Ortobiomolecular'),
(91556335016, 'Depressão', 'Teste Ortobiomolecular'),
(88808198014, 'Dificuldade para dormir', 'Teste Ortobiomolecular'),
(39977967008, 'Dores de cabeça forte','Teste Ortobiomolecular'),
(94148340010, 'Ferroada na barriga e dores nos rins', 'Teste Ortobiomolecular'),
(15168313060, 'Náuseas constantes', 'Teste Ortobiomolecular'),
(51162087021, 'Depressão e andiedade', 'Teste Ortobiomolecular'),
(56648009098, 'Hipertensão e diabetes tipo II', 'Teste Ortobiomolecular');

-- INSERÇÃO DE SESSAO
INSERT INTO SESSAO (tipoTratamento, data, resultadoDesintoxicacao, dataRetorno, especificacoes, queixaPrincipal, cpf) VALUES
('Reiki', '2022-09-01', 'Prediposição a contaminação por chumbo', '2022-01-02', 'Tomar cuidado com estresse', 'Dores de cabeça constantes', 69093000),
('Barra de Access', '2022-09-02', 'Prediposição a contaminação por Arsênico', '2022-01-03', 'Tomar cuidado com o sono', 'Cansaço a todo momento', 85303330),
('Reiki', '2022-09-03', 'Prediposição a contaminação por Mercúrio', '2022-01-04', 'Tomar os remédios do psiquiatra', 'Ansiedade', 78075605),
('Barra de Access', '2022-09-04', 'Prediposição a contaminação por Enxofre', '2022-01-05', 'Tomar remédios prescritos pelo psiquiatra', 'Depressão', 60410465),
('Reiki', '2022-09-05', 'Prediposição a contaminação por Lectina', '2022-01-06', 'Tentar praticar exercícios', 'Dificuldade para dormir', 77445130),
('Reiki', '2022-09-06', 'Prediposição a contaminação por Mercúrio', '2022-01-07', 'Tomar cuidado com estresse', 'Dores de cabeça forte', 39977967008),
('Barra de Access', '2022-09-07', 'Prediposição a contaminação por Arsênico', '2022-01-08', 'Tomar cuidado com a ingestão de água', 'Ferroada na barriga e dores nos rins', 94148340010),
('Reiki', '2022-09-08', 'Prediposição a contaminação por Lectina', '2022-01-09', 'Tomar cuidado com a alimentação', 'Náuseas constantes', 15168313060),
('Barra de Access', '2022-09-09', 'Prediposição a contaminação por Enxofre', '2022-01-10', 'Tomar remédios prescritos pelo psiquiatra', 'Depressão e andiedade', 51162087021),
('Reiki', '2022-09-10', 'Prediposição a contaminação por Chumbo', '2022-01-11', 'Tentar praticar exercícios', 'Hipertensão e diabetes tipo II', 56648009098);

-- INSERÇÃO DE DOCUMENTO
INSERT INTO DOCUMENTO (orientacoes) VALUES
('Evitar grãos'),
('Evitar fibras'),
('Evitar cascas ou verduras cruas'),
('Evitar frutos do mar'),
('Evitar integrais'),
('Evitar carne vermelha'),
('Evitar cereais'),
('Evitar derivados de leite'),
('Evitar frutas ácidas'),
('Evitar integrais');

-- INSERÇÃO DE ACOMPANHAMENTO
INSERT INTO ACOMPANHAMENTO (fase, orgaoChoque, positivoEstojo, orientacoesNeutralizar, contaminacaoPorMetais, florais, observacoes) VALUES
(1, 'rins', 'Veículo inalatorio', 'Tomar banho com argila', 'Chumbo', 'Bioquantic', 'Não ingerir alimentos vermelhos'),
(3, 'pancreas', 'Sistema digestório', 'Minutos de sol palma das mãos', 'Arsênico', 'Hantiver', 'Não ingerir milho'),
(3, 'figado', 'Bioquantico', 'Evitar Preferir verduras cruas', 'Mercúrio', 'Renaldetox', 'Não ingerir açucar'),
(2, 'coração', 'Intestino', 'Preferir chá verde','Enxofre', 'Histamitox', 'Não ingerir cebola, alho'),
(1, 'pulmão', 'Ressonante', 'Evitar cosméticos e perolados', 'Lectina', 'Quelanthus', 'Não ingerir folhosas'),
(2, 'rins', 'Veículo inalatorio', 'Ingerir chá preto', 'Chumbo', 'Bioquantic', 'Não ingerir alimentos vermelhos'),
(2, 'pancreas', 'Sistema digestório', 'Pegar mais Sol', 'Arsênico', 'Hantiver', 'Não ingerir milho'),
(3, 'figado', 'Bioquantico', 'Evitar frituras', 'Mercúrio', 'Renaldetox', 'Não ingerir açucar'),
(1, 'coração', 'Intestino', 'Evitar Chá','Enxofre', 'Histamitox', 'Não ingerir cebola, alho'),
(3, 'pulmão', 'Ressonante', 'Evitar cosméticos e perolados', 'Lectina', 'Quelanthus', 'Não ingerir folhosas');

-- INSERÇÃO DE PRESCRICAO
INSERT INTO PRESCRICAO (tratamentoEnergetico) VALUES
('Floral Quantico'),
('Floral Biogenetico'),
('Floral femininum'),
('Nefron'),
('Fisioquantic detox'),
('Floral femininum'),
('Nefron'),
('Floral Biogenetico'),
('Floral femininum'),
('Nefron');

-- INSERÇÃO DE PROTOCOLO
INSERT INTO PROTOCOLO (receitaFarmaceutica) VALUES 
('Loção Capilar transdérmica'),
('Dermocosmético'),
('Reiki Energy Chakra 5'),
('Polivitamínicos'),
('Creme transdérmico detox'),
('Reiki Energy Chakra 5'),
('Creme transdérmico detox'),
('Vitamina D'),
('Loção Capilar transdérmica'),
('Dermocosmético');

-- INSERÇÃO DE FORMULARIO
INSERT INTO FORMULARIO (assinaturaPaciente) VALUES 
('Pedro Menezes'),
('Paulo Vitor Messias'),
('Julia Lima Moraes'),
('Fernando Costa Alves'),
('Matheus Miguel de Bragança'),
('Guilherme Brito Vilas - Bôas'),
('Rogerio da Silva'),
('Ana Maria da Silva'),
('Davi Leite'),
('Rosa Fátima');


-- INSERÇÃO DE CURSO
INSERT INTO CURSO (nome, grade, certificado) VALUES
	('Curso de barra de access', 'todos os sábados', 'certificado de proficiência em barra de access'),
    ('Curso de reiki', 'todos as terças', 'certificado de proficiência em reiki'),
    ('Curso de técnicas de cura alternativas', 'segunda e quarta', 'certificado de proficiência em técnicas de cura alternativas'),
    ('Curso de terapias integrativas', 'terça e quinta', 'certificado de proficiência em terapias integrativas'),
    ('Curso de técnicas avançadas de reiki', 'aos domingos', 'certificado de proficiência em técnicas avançadas de reiki'),
    ('Curso avançado de barra de access', 'segunda e quarta', 'certificado de proficiência em técnicas avançadas de barra de access'),
    ('Curso de técnicas básicas de reiki', 'aos sábados', 'certificado de proficiência em técnicas básicas de reiki'),
	('Curso de terapias integrativas', 'segunda e quarta', 'certificado de proficiência em terapias integrativas'),
    ('Curso de técnicas de cura alternativas', 'sábados', 'certificado de proficiência em técnicas de cura alternativas'),
    ('Curso de reiki', 'todos os domingos', 'certificado de proficiência em reiki');

INSERT INTO TURMA (codigoCurso, local) VALUES 
    (1, 'Sala 101 da Clínica'),
    (1, 'Sala 102 da Clínica'),
    (2, 'Auditório do Prédio onde a Clínica se Localiza'),
    (2, 'Consultório 1'),
    (3, 'Casa do Palestrante'),
    (4, 'Parque da Cidade - Evento (Semana da Terapia Energetica)'),
    (5, 'Parque da Cidade - Evento (Semana da Terapia Energetica)'),
    (6, 'Auditorio da Escola Marista - Centro'),
    (7, 'Auditorio da Escola Marista - Centro'),
    (9, 'Auditorio do Ibis Hotel');

-- INSERÇÃO DE WORKSHOP
INSERT INTO WORKSHOP (dataRealizacao) VALUES
	('2022-09-22'),
    ('2022-09-23'),
    ('2022-09-24'),
    ('2022-09-25'),
    ('2022-09-26'),
    ('2022-10-07'),
    ('2022-10-11'),
    ('2022-10-12'),
    ('2022-10-18'),
    ('2022-10-20');

-- INSERÇÃO DE compra
INSERT INTO compra (dataVenda, cpf) VALUES
	('2022-05-22',23026428051),
    ('2022-05-23',53855000034),
    ('2022-05-24',71305272005),
    ('2022-05-25',91556335016),
    ('2022-05-27',88808198014),
    ('2022-05-28',39977967008),
    ('2022-05-29',94148340010),
    ('2022-05-30',15168313060),
    ('2022-05-30',51162087021),
    ('2022-05-30',56648009098);
    
-- INSERÇÃO DE inscrito
INSERT INTO inscrito (cpf) VALUES
	(23026428051),
    (53855000034),
    (71305272005),
    (91556335016),
    (88808198014),
	(39977967008),
    (94148340010),
    (15168313060),
    (51162087021),
    (56648009098); 
    
    
-- INSERÇÃO DE palestra
INSERT INTO palestra (cpf) VALUES
	(23026428051),
    (53855000034),
    (71305272005),
    (91556335016),
    (88808198014),
    (39977967008),
    (94148340010),
    (15168313060),
    (51162087021),
    (56648009098); 
