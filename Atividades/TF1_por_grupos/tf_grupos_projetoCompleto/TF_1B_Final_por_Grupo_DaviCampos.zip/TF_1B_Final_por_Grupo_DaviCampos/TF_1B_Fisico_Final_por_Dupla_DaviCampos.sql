-- --------  << Trabalho Final Tema 1 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 19/09/2022
-- Autor(es) ..............: Davi Marinho da Silva Campos, André Macedo Rodrigues Alves, Guilherme Brito Vilas - Bôas e Arthur Popov
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1B_davicampos
--
-- PROJETO => 01 Base de Dados
--         => 18 Tabelas
--         => 04 Perfis
--         => 12 Usuários
--
-- ---------------------------------------------------------

-- BASE DE DADOS
CREATE DATABASE
    IF NOT EXISTS TF_1B_davicampos;

USE TF_1B_davicampos;


-- TABELAS

CREATE TABLE PRODUTO (
	codigoProduto INT AUTO_INCREMENT NOT NULL,
	saldoEstoque INT NOT NULL,
    precoVenda DOUBLE NOT NULL,
    precoCusto DOUBLE NOT NULL,
    descricaoProduto VARCHAR(100) NOT NULL,
    CONSTRAINT PRODUTO_PK PRIMARY KEY (codigoProduto)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PESSOA (
    cpf BIGINT NOT NULL,
    rg INT,
    nome VARCHAR(50) NOT NULL,
    telefone VARCHAR(11),
    dataNascimento DATE NOT NULL,
    email VARCHAR(50) NOT NULL,
    endereco VARCHAR(90) NOT NULL,
    cidade VARCHAR(90) NOT NULL,
    cep INT(8),
    complemento VARCHAR(90),
    sexo ENUM('M', 'F') NOT NULL,
    CONSTRAINT PESSOA_PK PRIMARY KEY (cpf)
)  ENGINE=INNODB;

CREATE TABLE PACIENTE (
    cpf BIGINT NOT NULL,
	estadoCivil ENUM ('CASADO', 'SOLTEIRO', 'SEPARADO', 'DIVORCIADO', 'VIÚVO') NOT NULL,
    profissao VARCHAR(50) NOT NULL,
    CONSTRAINT PACIENTE_PESSOA_FK FOREIGN KEY (cpf) 
		REFERENCES PESSOA (cpf)
) ENGINE = InnoDB;

CREATE TABLE ALUNO (
    cpf BIGINT NOT NULL,
    matriculaCurso INT NOT NULL,
    CONSTRAINT ALUNO_PESSOA_FK FOREIGN KEY (cpf)
        REFERENCES PESSOA (cpf)
)  ENGINE=INNODB;

CREATE TABLE PALESTRANTE (
	cpf BIGINT NOT NULL,
    formacao VARCHAR(50) NOT NULL,
    CONSTRAINT PALESTRANTE_PESSOA_FK FOREIGN KEY (cpf)
		REFERENCES PESSOA(cpf)
) ENGINE = InnoDB;

CREATE TABLE CONSULTA (
	idConsulta INT AUTO_INCREMENT NOT NULL,
	cpf BIGINT NOT NULL,
    queixaPrincipal VARCHAR(100) NOT NULL,
    fichaDesintoxicacao VARCHAR(100) NOT NULL,
    CONSTRAINT CONSULTA_PK PRIMARY KEY (idConsulta)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE SESSAO (
	idSessao INT AUTO_INCREMENT,
    idConsulta INT,
	tipoTratamento VARCHAR(100) NOT NULL,
    data DATE NOT NULL,
    resultadoDesintoxicacao VARCHAR(100) NOT NULL,
    dataRetorno DATE NOT NULL,
    especificacoes VARCHAR(100) NOT NULL,
    queixaPrincipal VARCHAR(100) NOT NULL,
    cpf BIGINT,
    CONSTRAINT SESSAO_PK PRIMARY KEY (idSessao),
    CONSTRAINT SESSAO_CONSULTA_FK FOREIGN KEY (idConsulta) REFERENCES CONSULTA (idConsulta)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE DOCUMENTO (
	idDocumento INT NOT NULL AUTO_INCREMENT,
    orientacoes VARCHAR(100) NOT NULL,
    CONSTRAINT DOCUMENTO_PK PRIMARY KEY (idDocumento)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE ACOMPANHAMENTO (
	idDocumento INT NOT NULL AUTO_INCREMENT,
    fase VARCHAR(25) NOT NULL,
    orgaoChoque VARCHAR(100) NOT NULL,
    positivoEstojo VARCHAR(100) NOT NULL,
    orientacoesNeutralizar VARCHAR(100) NOT NULL,
    contaminacaoPorMetais VARCHAR(100) NOT NULL,
    florais VARCHAR(100) NOT NULL,
    observacoes VARCHAR(100),
    CONSTRAINT ACOMPANHAMENTO_DOCUMENTO_FK FOREIGN KEY (idDocumento) REFERENCES DOCUMENTO (idDocumento)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PRESCRICAO (
	tratamentoEnergetico VARCHAR(100) NOT NULL,
    idDocumento INT,
    CONSTRAINT PRESCRICAO_DOCUMENTO_FK FOREIGN KEY (idDocumento) REFERENCES DOCUMENTO (idDocumento)
) ENGINE = InnoDB;

CREATE TABLE PROTOCOLO (
	receitaFarmaceutica VARCHAR(100) NOT NULL,
	idDocumento INT,
    CONSTRAINT PROTOCOLO_DOCUMENTO_FK FOREIGN KEY (idDocumento) REFERENCES DOCUMENTO (idDocumento)
) ENGINE = InnoDB;

CREATE TABLE FORMULARIO (
	assinaturaPaciente VARCHAR(100) NOT NULL,
	idDocumento INT,
    CONSTRAINT FORMULARIO_DOCUMENTO_FK FOREIGN KEY (idDocumento) REFERENCES DOCUMENTO (idDocumento)
) ENGINE = InnoDB;

CREATE TABLE CURSO (
	codigoCurso INT AUTO_INCREMENT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    grade VARCHAR(50) NOT NULL,
    certificado VARCHAR(100),
    CONSTRAINT CURSO_PK PRIMARY KEY (codigoCurso)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE TURMA (
	codigoTurma INT AUTO_INCREMENT NOT NULL,
    codigoCurso INT,
    local VARCHAR(100) NOT NULL, 
    CONSTRAINT TURMA_PK PRIMARY KEY (codigoTurma),
    CONSTRAINT TURMA_CURSO_FK FOREIGN KEY (codigoCurso) REFERENCES CURSO(codigoCurso)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE WORKSHOP (
	codigoCurso INT,
    dataRealizacao DATE NOT NULL,
    CONSTRAINT WORKSHOP_CURSO_FK FOREIGN KEY (codigoCurso) REFERENCES CURSO(codigoCurso)
) ENGINE = InnoDB;

CREATE TABLE compra (
	dataVenda DATE NOT NULL,
    cpf BIGINT NOT NULL,
    codigoProduto INT,
	CONSTRAINT compra_PACIENTE_FK FOREIGN KEY (cpf) REFERENCES PACIENTE(cpf),
    CONSTRAINT compra_PRODUTO_FK FOREIGN KEY (codigoProduto) REFERENCES PRODUTO (codigoProduto)
) ENGINE = InnoDB;

CREATE TABLE inscrito (
	cpf BIGINT,
    codigoTurma INT,
    CONSTRAINT inscrito_ALUNO_FK FOREIGN KEY (cpf) REFERENCES ALUNO(cpf),
    CONSTRAINT inscrito_TURMA_FK FOREIGN KEY (codigoTurma) REFERENCES TURMA(codigoTurma)
) ENGINE = InnoDB;

CREATE TABLE palestra (
	cpf BIGINT,
    codigoCurso INT,
    CONSTRAINT inscrito_PALESTRANTE_FK FOREIGN KEY (cpf) REFERENCES PALESTRANTE(cpf),
    CONSTRAINT inscrito_CURSO_FK FOREIGN KEY (codigoCurso) REFERENCES CURSO(codigoCurso)
) ENGINE = InnoDB;