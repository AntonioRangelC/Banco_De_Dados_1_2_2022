-- --------  << Trabalho Final Tema 1 >>  ----------
--
--                    SCRIPT DE INSERCAO (DDL)
--
-- Data Criacao ...........: 19/09/2022
-- Autor(es) ..............: Davi Marinho da Silva Campos, André Macedo Rodrigues Alves, Guilherme Brito Vilas - Bôas e Arthur Popov
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1B_davicampos
--
-- PROJETO => 01 Base de Dados
--         => 18 Tabelas
--         => 04 Perfis
--         => 12 Usuários
--
-- ---------------------------------------------------------

-- BASE DE DADOS
USE TF_1B_davicampos;

-- Cria o perfil 'ADMIN' e garante a ele todos os privilégios
CREATE ROLE 'ADMIN';
GRANT ALL PRIVILEGES ON TF_1B_davicampos TO 'ADMIN' WITH GRANT OPTION;

-- Cria o perfil 'GERENTE_LOJA' e garante a ele todos os privilégios nas tabelas que fazem parte da loja
CREATE ROLE 'GERENTE_LOJA';
GRANT ALL PRIVILEGES ON TF_1B_davicampos.PRODUTOS TO 'GERENTE_LOJA' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON TF_1B_davicampos.compra TO 'GERENTE_LOJA' WITH GRANT OPTION;

-- Cria o perfil 'DIRETOR_CURSO' e garante a ele todos os privilégios nas tabelas que fazem parte dos cursos
CREATE ROLE 'DIRETOR_CURSO';
GRANT ALL PRIVILEGES ON TF_1B_davicampos.ALUNO TO 'DIRETOR_CURSO' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON TF_1B_davicampos.inscrito TO 'DIRETOR_CURSO' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON TF_1B_davicampos.TURMA TO 'DIRETOR_CURSO' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON TF_1B_davicampos.pertence TO 'DIRETOR_CURSO' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON TF_1B_davicampos.CURSO TO 'DIRETOR_CURSO' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON TF_1B_davicampos.WORKSHOP TO 'DIRETOR_CURSO' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON TF_1B_davicampos.PALESTRANTE TO 'DIRETOR_CURSO' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON TF_1B_davicampos.palestra TO 'DIRETOR_CURSO' WITH GRANT OPTION;

-- Cria o perfil 'TERAPEUTA' e garante a ele todos os privilégios nas tabelas que fazem parte da terapia
CREATE ROLE 'TERAPEUTA';
GRANT ALL PRIVILEGES ON TF_1B_davicampos.PACIENTE TO 'TERAPEUTA' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON TF_1B_davicampos.CONSULTA TO 'TERAPEUTA' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON TF_1B_davicampos.SESSAO TO 'TERAPEUTA' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON TF_1B_davicampos.DOCUMENTO TO 'TERAPEUTA' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON TF_1B_davicampos.ACOMPANHAMENTO TO 'TERAPEUTA' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON TF_1B_davicampos.PRESCRICAO TO 'TERAPEUTA' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON TF_1B_davicampos.PROTOCOLO TO 'TERAPEUTA' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON TF_1B_davicampos.FORMULARIO TO 'TERAPEUTA' WITH GRANT OPTION;

-- Criação dos usuários
CREATE USER 'matheus' IDENTIFIED BY 'password';
CREATE USER 'joao' IDENTIFIED BY 'password';
CREATE USER 'marcos' IDENTIFIED BY 'password';
CREATE USER 'paulo' IDENTIFIED BY 'password';
CREATE USER 'pedro' IDENTIFIED BY 'password';
CREATE USER 'ana' IDENTIFIED BY 'password';
CREATE USER 'amanda' IDENTIFIED BY 'password';
CREATE USER 'antonia' IDENTIFIED BY 'password';
CREATE USER 'lucas' IDENTIFIED BY 'password';
CREATE USER 'aline' IDENTIFIED BY 'password';
CREATE USER 'jose' IDENTIFIED BY 'password';
CREATE USER 'rodrigo' IDENTIFIED BY 'password';


-- Garantindo privilégios de ADMIN
GRANT 'ADMIN' TO 'joao', 'matheus', 'pedro';

-- Garantindo privilégios de GERENTE_LOJA
GRANT 'GERENTE_LOJA' TO 'marcos', 'ana', 'antonia';

-- Garantindo privilégios de DIRETOR_CURSO
GRANT 'DIRETOR_CURSO' TO 'jose', 'marcos', 'amanda';

-- Garantindo privilégios de TERAPEUTA
GRANT 'TERAPEUTA' TO 'lucas', 'rodrigo', 'aline';