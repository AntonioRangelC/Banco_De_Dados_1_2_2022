-- ------------------------   << Trabalho Final (TF) - Tema 3 - Ludoteca  >>   ------------------------
--
--                    					SCRIPT DE APAGAR (DDL)  
--
-- Data Criacao ...........: 31/08/2022
-- Autor(es) ..............: Maria Eduarda Barbosa Santos, Victor de Souza Cabral, Wengel Rodrigues Farias e Wesley Pedrosa dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_3B_victorcabral
--
-- Ultimas Alteracoes
--   11/09/2022 => Alteração no nome da Base de Dados.
--   11/09/2022 => Adição do DROP das tabelas FORNECEDOR e fornece.
--   11/09/2022 => Alteração na ordem em que ocorre o DROP das tabelas.
--   18/09/2022 => Adição do DROP da tabela CONTRATANTE.
--   18/09/2022 => Alteração na ordem em que ocorre o DROP das tabelas.
--   19/09/2022 => Adição dos DROPS de USERs e ROLEs.
-- PROJETO => 01 Base de Dados
--         => 30 Tabelas
--         => 03 Usuários
--         => 03 Perfis
--
-- ----------------------------------------------------------------------------------------------------

-- BASE DE DADOS
USE TF_3B_victorcabral;

DROP TABLE fornece;
DROP TABLE realiza;
DROP TABLE utiliza;
DROP TABLE possui;
DROP TABLE consta;
DROP TABLE auxilia;
DROP TABLE serve;
DROP TABLE FORNECEDOR;
DROP TABLE INSUMO;
DROP TABLE LANCHE;
DROP TABLE DEFEITO;
DROP TABLE ACESSORIO;
DROP TABLE QUADRINHO;
DROP TABLE JOGO;
DROP TABLE CATEGORIA;
DROP TABLE PRODUTO;
DROP TABLE CLUBE;
DROP TABLE AVULSA;
DROP TABLE ALUGUEL;
DROP TABLE TESTEMUNHA;
DROP TABLE CONTRATO;
DROP TABLE PONTUACAO;
DROP TABLE CARTAO;
DROP TABLE GARCOM;
DROP TABLE MONITOR;
DROP TABLE FUNCIONARIO;
DROP TABLE MESA;
DROP TABLE CLIENTE;
DROP TABLE CONTRATANTE;
DROP TABLE PESSOA;
DROP ROLE GARCOM;
DROP ROLE MONITOR;
DROP ROLE ADMINISTRADOR;
DROP USER joao;
DROP USER carla;
DROP USER charlon;
