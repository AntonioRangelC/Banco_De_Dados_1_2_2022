-- ------------------------   << Trabalho Final (TF) - Tema 3 - Ludoteca  >>   ------------------------
--
--                    					SCRIPT DE CRIACAO (DDL) 
--
-- Data Criacao ...........: 31/08/2022
-- Autor(es) ..............: Maria Eduarda Barbosa Santos, Victor de Souza Cabral, Wengel Rodrigues Farias e Wesley Pedrosa dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_3B_victorcabral
--
-- Ultimas Alteracoes
--   11/09/2022 => Alteração no nome da Base de Dados.
--   11/09/2022 => Adição das tabelas FORNECEDOR e fornece.
--   11/09/2022 => Adição de mais atributos conforme atualização nos documentos.
--   11/09/2022 => Adição e alteração no tamanho de alguns atributos.
--   11/09/2022 => Alteração no nome de alguns atributos.
--   11/09/2022 => Adição de novas UNIQUE.
--   18/09/2022 => Adição da tabela CONTRATANTE.
--   18/09/2022 => Alteração nas relações da tabela PESSOA. Algumas relações agora são ligadas a CONTRATANTE.
--   18/09/2022 => Acrécimo de novos atributos em QUADRINHO e CONTRATO conforme atualização nos documentos.
--   18/09/2022 => Alteração no nome de atributos em CATEGORIA e MESA conforme atualização nos documentos.
--   18/09/2022 => Alteração no tamanho de alguns atributos.
--   19/09/2022 => Alteração na ordem do AUTO_INCREMENT e NOT NULL em atributos que aparecem ambos.
--
-- PROJETO => 01 Base de Dados
--         => 30 Tabelas
--         => 03 Usuários
--         => 03 Perfis
--
-- ----------------------------------------------------------------------------------------------------

-- BASE DE DADOS
CREATE DATABASE IF NOT EXISTS TF_3B_victorcabral
    DEFAULT CHARACTER SET utf8
    DEFAULT COLLATE utf8_general_ci;
USE TF_3B_victorcabral;

-- TABELAS
CREATE TABLE PESSOA (
	idPessoa INT(11) NOT NULL AUTO_INCREMENT, 
    cpf BIGINT(11) NOT NULL,
    nomeCompleto VARCHAR(100) NOT NULL,
	telefone BIGINT(13) NOT NULL,
	email VARCHAR(255) NOT NULL,
    dtNascimento DATE NOT NULL,

    CONSTRAINT PESSOA_PK PRIMARY KEY (idPessoa),
    CONSTRAINT PESSOA_UK UNIQUE (cpf, email)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE CONTRATANTE(
    idContratante INT(11) NOT NULL, 
    profissaoContratante VARCHAR(50),
	
	CONSTRAINT CONTRATANTE_PK PRIMARY KEY (idContratante),
    CONSTRAINT CONTRATANTE_PESSOA_FK FOREIGN KEY (idContratante)
        REFERENCES PESSOA (idPessoa)
) ENGINE = InnoDB;


CREATE TABLE CLIENTE (
	idCliente INT(11) NOT NULL AUTO_INCREMENT,
    nomeCliente VARCHAR(100),
    telefoneCliente BIGINT(13),

    CONSTRAINT CLIENTE_PK PRIMARY KEY (idCliente)

) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE MESA (
    idMesa INT(2) NOT NULL AUTO_INCREMENT,
    dataHoraMesa DATETIME NOT NULL,
	idCliente INT(11) NOT NULL,

    CONSTRAINT MESA_PK PRIMARY KEY (idMesa),
    
    CONSTRAINT MESA_CLIENTE_FK FOREIGN KEY (idCliente)
        REFERENCES CLIENTE (idCliente)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE FUNCIONARIO (
    idFuncionario INT(11) NOT NULL,
    cargoFuncionario VARCHAR(30) NOT NULL,
	salario DOUBLE(6, 2) NOT NULL,
    dtContratacao DATE NOT NULL,

    CONSTRAINT FUNCIONARIO_PK PRIMARY KEY (idFuncionario),

    CONSTRAINT FUNCIONARIO_PESSOA_FK FOREIGN KEY (idFuncionario)
        REFERENCES PESSOA (idPessoa)
) ENGINE = InnoDB;

CREATE TABLE MONITOR (
    idMonitor INT(11) NOT NULL,

    CONSTRAINT MONITOR_PK PRIMARY KEY (idMonitor),

    CONSTRAINT MONITOR_FUNCIONARIO_FK FOREIGN KEY (idMonitor)
        REFERENCES FUNCIONARIO (idFuncionario)
) ENGINE = InnoDB;

CREATE TABLE GARCOM (
    idGarcom INT(11) NOT NULL,
    CONSTRAINT GARCOM_PK PRIMARY KEY (idGarcom),

    CONSTRAINT GARCOM_FUNCIONARIO_FK FOREIGN KEY (idGarcom)
        REFERENCES FUNCIONARIO (idFuncionario)
) ENGINE = InnoDB;

CREATE TABLE CARTAO (
    numeroCartao BIGINT(19) NOT NULL,
    validade DATE NOT NULL,
    nomeCartao VARCHAR(50) NOT NULL,
	codigoSeguranca INT(4) NOT NULL,
	idContratante INT(11) NOT NULL,

    CONSTRAINT CARTAO_PK PRIMARY KEY (numeroCartao),

    CONSTRAINT CARTAO_CONTRATANTE_FK FOREIGN KEY (idContratante)
        REFERENCES CONTRATANTE (idContratante)
) ENGINE = InnoDB;

CREATE TABLE PONTUACAO (
    idPontuacao INT(5) NOT NULL AUTO_INCREMENT,
    nomeJogador VARCHAR(100) NOT NULL,
    numeroPontuacao INT(5) NOT NULL,	
    idMesa INT(2) NOT NULL,

    CONSTRAINT PONTUACAO_PK PRIMARY KEY (idPontuacao),

    CONSTRAINT PONTUACAO_MESA_FK FOREIGN KEY (idMesa)
        REFERENCES MESA (idMesa)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE CONTRATO (
    numContrato INT(11) NOT NULL AUTO_INCREMENT,
    dataAssinatura DATE NOT NULL,
    multa DOUBLE(6, 2) NOT NULL,
	valorContrato DOUBLE(6, 2) NOT NULL,
    idFuncionario INT(11) NOT NULL,
    idContratante INT(11) NOT NULL,
    

    CONSTRAINT CONTRATO_PK PRIMARY KEY (numContrato),
    
    CONSTRAINT CONTRATO_FUNCIONARIO_FK FOREIGN KEY (idFuncionario)
        REFERENCES FUNCIONARIO (idFuncionario),
    CONSTRAINT CONTRATO_CONTRATANTE_FK FOREIGN KEY (idContratante)
        REFERENCES CONTRATANTE (idContratante)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE TESTEMUNHA (
    idTestemunha INT(11) NOT NULL AUTO_INCREMENT,
    rgNumeroTestemunha INT(10) NOT NULL,
    rgEstadoTestemunha VARCHAR(2) NOT NULL,
    nomeTestemunha VARCHAR(100) NOT NULL,
    numContrato INT(11) NOT NULL,

    CONSTRAINT TESTEMUNHA_PK PRIMARY KEY (idTestemunha),
    CONSTRAINT TESTEMUNHA_UK UNIQUE (rgNumeroTestemunha),
    
    CONSTRAINT TESTEMUNHA_CONTRATO_FK FOREIGN KEY (numContrato)
        REFERENCES CONTRATO (numContrato)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE ALUGUEL (
    idAluguel INT(11) NOT NULL AUTO_INCREMENT,
    numContrato INT(11) NOT NULL,

    CONSTRAINT ALUGUEL_PK PRIMARY KEY (idAluguel),
    
    CONSTRAINT ALUGUEL_CONTRATO_FK FOREIGN KEY (numContrato)
        REFERENCES CONTRATO (numContrato)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE AVULSA (
    idAvulsa INT(11) NOT NULL,
    prazoDevolucao DATE NOT NULL,    
	valorLocacao DOUBLE(6, 2) NOT NULL,

    CONSTRAINT AVULSA_PK PRIMARY KEY (idAvulsa),
    
    CONSTRAINT AVULSA_ALUGUEL_FK FOREIGN KEY (idAvulsa)
        REFERENCES ALUGUEL (idAluguel)
) ENGINE = InnoDB;

CREATE TABLE CLUBE (
    idClube INT(11) NOT NULL,
    tipoAssinatura ENUM('C', 'B', 'H') NOT NULL,
    numeroCartao BIGINT(19) NOT NULL,
    
    CONSTRAINT CLUBE_PK PRIMARY KEY (idClube),
    
    CONSTRAINT CLUBE_ALUGUEL_FK FOREIGN KEY (idClube)
        REFERENCES ALUGUEL (idAluguel),
    CONSTRAINT CLUBE_CARTAO_FK FOREIGN KEY (numeroCartao)
        REFERENCES CARTAO (numeroCartao)
) ENGINE = InnoDB;

CREATE TABLE PRODUTO (
    codProduto INT(11) NOT NULL AUTO_INCREMENT,
    nomeProduto VARCHAR(100) NOT NULL,
    marcaProduto VARCHAR(30) NOT NULL,
	numeroCopia INT(3) NOT NULL,
    situacaoProduto ENUM('A', 'V', 'N') NOT NULL,
	vezesAlugado INT(5),
	vezesProdutoVendido INT(5) NOT NULL,
	custoProduto DOUBLE(6, 2) NOT NULL,
	precoProduto DOUBLE(6, 2) NOT NULL,
	idCliente INT(11),
	idAluguel INT(11),

    CONSTRAINT PRODUTO_PK PRIMARY KEY (codProduto),

    CONSTRAINT PRODUTO_CLIENTE_FK FOREIGN KEY (idCliente)
        REFERENCES CLIENTE (idCliente),
    CONSTRAINT PRODUTO_ALUGUEL_FK FOREIGN KEY (idAluguel)
        REFERENCES ALUGUEL (idAluguel)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE CATEGORIA (
    corCategoria VARCHAR(30) NOT NULL,
	precoDanoCategoria DOUBLE(6, 2) NOT NULL,

    CONSTRAINT CATEGORIA_PK PRIMARY KEY (corCategoria)
) ENGINE = InnoDB;

CREATE TABLE JOGO (
    codJogo INT(11) NOT NULL,
	corCategoria VARCHAR(30) NOT NULL,

    CONSTRAINT JOGO_PK PRIMARY KEY (codJogo),

    CONSTRAINT JOGO_PRODUTO_FK FOREIGN KEY (codJogo)
        REFERENCES PRODUTO (codProduto),
    CONSTRAINT JOGO_CATEGORIA_FK FOREIGN KEY (corCategoria)
        REFERENCES CATEGORIA (corCategoria)
) ENGINE = InnoDB;

CREATE TABLE QUADRINHO (
    codQuadrinho INT(11) NOT NULL,
    precoDanoQuadrinho DOUBLE(6, 2) NOT NULL,

    CONSTRAINT QUADRINHO_PK PRIMARY KEY (codQuadrinho),

    CONSTRAINT QUADRINHO_PRODUTO_FK FOREIGN KEY (codQuadrinho)
        REFERENCES PRODUTO (codProduto)
) ENGINE = InnoDB;

CREATE TABLE ACESSORIO (
    codAcessorio INT(11) NOT NULL,

    CONSTRAINT ACESSORIO_PK PRIMARY KEY (codAcessorio),

    CONSTRAINT ACESSORIO_PRODUTO_FK FOREIGN KEY (codAcessorio)
        REFERENCES PRODUTO (codProduto)
) ENGINE = InnoDB;

CREATE TABLE DEFEITO (
    idDefeito INT(3) NOT NULL AUTO_INCREMENT,
    descricaoDefeito VARCHAR(50) NOT NULL,

    CONSTRAINT DEFEITO_PK PRIMARY KEY (idDefeito)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE LANCHE (
    idLanche INT(3) NOT NULL AUTO_INCREMENT,
    tipoLanche ENUM('C', 'B') NOT NULL,    
    nomeLanche VARCHAR(30) NOT NULL,
    descricaoLanche VARCHAR(50) NOT NULL,
	vezesLancheVendido INT(5) NOT NULL,
	custoLanche DOUBLE(6, 2) NOT NULL,
	precoLanche DOUBLE(6, 2) NOT NULL,
	idMesa INT(2) NOT NULL,

    CONSTRAINT LANCHE_PK PRIMARY KEY (idLanche),

    CONSTRAINT LANCHE_MESA_FK FOREIGN KEY (idMesa)
        REFERENCES MESA (idMesa)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE INSUMO (
    idInsumo INT(5) NOT NULL AUTO_INCREMENT,
    nomeInsumo VARCHAR(30) NOT NULL,

    CONSTRAINT INSUMO_PK PRIMARY KEY (idInsumo)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE FORNECEDOR (
    idFornecedor INT(11) NOT NULL AUTO_INCREMENT,
    nomeFornecedor VARCHAR(50) NOT NULL,
    cnpjFornecedor BIGINT(14) NOT NULL,
	emailFornecedor VARCHAR(255) NOT NULL,

    CONSTRAINT FORNECEDOR_PK PRIMARY KEY (idFornecedor),
    CONSTRAINT FORNECEDOR_UK UNIQUE (cnpjFornecedor, emailFornecedor)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE serve (
    idMesa INT(2) NOT NULL,
    idGarcom INT(11) NOT NULL,

    CONSTRAINT serve_UK UNIQUE (idMesa, idGarcom),

    CONSTRAINT serve_MESA_FK FOREIGN KEY (idMesa)
        REFERENCES MESA (idMesa),
    CONSTRAINT serve_GARCOM_FK FOREIGN KEY (idGarcom)
        REFERENCES GARCOM (idGarcom)
) ENGINE = InnoDB;

CREATE TABLE auxilia (
    idMonitor INT(11) NOT NULL,
    idMesa INT(2) NOT NULL,

    CONSTRAINT auxilia_UK UNIQUE (idMonitor, idMesa),

    CONSTRAINT auxilia_MONITOR_FK FOREIGN KEY (idMonitor)
        REFERENCES MONITOR (idMonitor),
    CONSTRAINT auxilia_MESA_FK FOREIGN KEY (idMesa)
        REFERENCES MESA (idMesa)
) ENGINE = InnoDB;

CREATE TABLE consta (
    idLanche INT(3) NOT NULL,
    idInsumo INT(5) NOT NULL,

    CONSTRAINT consta_UK UNIQUE (idLanche, idInsumo),

    CONSTRAINT consta_LANCHE_FK FOREIGN KEY (idLanche)
        REFERENCES LANCHE (idLanche),
    CONSTRAINT consta_INSUMO_FK FOREIGN KEY (idInsumo)
        REFERENCES INSUMO (idInsumo)
) ENGINE = InnoDB;

CREATE TABLE possui (
    codProduto INT(11) NOT NULL,
    idDefeito INT(3) NOT NULL,

    CONSTRAINT possui_UK UNIQUE (codProduto, idDefeito),

    CONSTRAINT possui_PRODUTO_FK FOREIGN KEY (codProduto)
        REFERENCES PRODUTO (codProduto),
    CONSTRAINT possui_DEFEITO_FK FOREIGN KEY (idDefeito)
        REFERENCES DEFEITO (idDefeito)
) ENGINE = InnoDB;

CREATE TABLE utiliza (
    idMesa INT(2) NOT NULL,
    codProduto INT(11) NOT NULL,

    CONSTRAINT serve_UK UNIQUE (idMesa, codProduto),

    CONSTRAINT utiliza_MESA_FK FOREIGN KEY (idMesa)
        REFERENCES MESA (idMesa),
    CONSTRAINT utiliza_PRODUTO_FK FOREIGN KEY (codProduto)
        REFERENCES PRODUTO (codProduto)
) ENGINE = InnoDB;

CREATE TABLE realiza (
    idContratante INT(11) NOT NULL,
    idAluguel INT(11) NOT NULL,

    CONSTRAINT realiza_UK UNIQUE (idContratante, idAluguel),

    CONSTRAINT realiza_CONTRATANTE_FK FOREIGN KEY (idContratante)
        REFERENCES CONTRATANTE (idContratante),
    CONSTRAINT realiza_ALUGUEL_FK FOREIGN KEY (idAluguel)
        REFERENCES ALUGUEL (idAluguel)
) ENGINE = InnoDB;

CREATE TABLE fornece (
    codProduto INT(11) NOT NULL,
    idFornecedor INT(11) NOT NULL,

    CONSTRAINT fornece_UK UNIQUE (codProduto, idFornecedor),

    CONSTRAINT fornece_PRODUTO_FK FOREIGN KEY (codProduto)
        REFERENCES PRODUTO (codProduto),
    CONSTRAINT fornece_FORNECEDOR_FK FOREIGN KEY (idFornecedor)
        REFERENCES FORNECEDOR (idFornecedor)
) ENGINE = InnoDB;