-- ------------------------   << Trabalho Final (TF) - Tema 3 - Ludoteca  >>   ------------------------
--
--                                         	SCRIPT DE CONTROLE
--
-- Data Criacao ...........: 11/09/2022
-- Autor(es) ..............: Maria Eduarda Barbosa Santos, Victor de Souza Cabral, Wengel Rodrigues Farias e Wesley Pedrosa dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_3B_victorcabral
--
-- PROJETO => 01 Base de Dados
--         => 30 Tabelas
--         => 03 Usuários
--         => 03 Perfis
--
-- ----------------------------------------------------------------------------------------------------

-- BASE DE DADOS 
USE TF_3B_victorcabral;

-- Usuarios
CREATE USER charlon
	IDENTIFIED BY 'carlon321';

CREATE USER carla
	IDENTIFIED BY 'alarac303';
    
CREATE USER joao
	IDENTIFIED BY 'joao4402j';

-- Perfis
CREATE ROLE ADMINISTRADOR;
CREATE ROLE MONITOR;
CREATE ROLE GARCOM;

-- Privilegios
GRANT ALL
	ON TF_3B_victorcabral
    TO ADMINISTRADOR;

GRANT
	SELECT, INSERT
    ON TF_3B_victorcabral.*
	TO MONITOR;
    
GRANT
	SELECT, INSERT, UPDATE
    ON TF_3B_victorcabral.*
	TO GARCOM;

-- Trabalhando com Papéis para os usuários
GRANT ADMINISTRADOR TO charlon;
GRANT MONITOR TO carla;
GRANT GARCOM TO joao;
