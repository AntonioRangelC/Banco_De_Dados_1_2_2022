-- --------  << Eleicao >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Pedro Lucas Cassiano Martins
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: PedroMartins
--
-- Ultimas Alteracoes
--
-- PROJETO => 01 Base de Dados
--         => 11 Tabelas
-- ---------------------------------------------------------

CREATE DATABASE 
	IF NOT EXISTS PedroMartins;

USE PedroMartins;

CREATE TABLE PESSOA (
	tituloEleitor INT(12) NOT NULL,
	CONSTRAINT PESSOA_PK PRIMARY KEY (tituloEleitor)
)ENGINE=INNODB;

CREATE TABLE ELEITOR (
	tituloEleitor INT(12) NOT NULL,
    nomeCompleto VARCHAR(100) NOT NULL,
    dtNasc DATE NOT NULL,
	CONSTRAINT PESSOA_PK PRIMARY KEY (tituloEleitor),
    CONSTRAINT PESSOA_ELEITOR_FK FOREIGN KEY (tituloEleitor) REFERENCES PESSOA(tituloEleitor)
)ENGINE=INNODB;

CREATE TABLE GOVERNADOR (
	tituloELeitor INT(12) NOT NULL,
    numGovernador INT(2) NOT NULL,
    CONSTRAINT GOVERNADOR_PK PRIMARY KEY (numGovernador),
	CONSTRAINT PESSOA_GOVERNADOR_FK FOREIGN KEY(tituloEleitor) REFERENCES PESSOA(tituloEleitor)
)ENGINE=INNODB;

CREATE TABLE VOTO (
	idVoto INT NOT NULL AUTO_INCREMENT,
	tituloELeitor INT(12) NOT NULL,
    numGovernador INT(2),
    tipoVoto enum('R','J') NOT NULL,
    CONSTRAINT VOTO_PK PRIMARY KEY (idVoto),
    CONSTRAINT GOVERNADOR_VOTO_FK FOREIGN KEY(numGovernador) REFERENCES GOVERNADOR(numGovernador),
	CONSTRAINT ELEITOR_VOTO_FK FOREIGN KEY(tituloEleitor) REFERENCES PESSOA(tituloEleitor)
)ENGINE=INNODB AUTO_INCREMENT=1;

CREATE TABLE REALIZADO (
	idVoto INT NOT NULL,
	tituloEleitor INT(12) NOT NULL,
    numGovernador INT(2) NOT NULL,
    CONSTRAINT REALIZADO_PK PRIMARY KEY (idVoto)
)ENGINE=INNODB;

CREATE TABLE JUSTIFICADO (
	idVoto INT NOT NULL,
	tituloELeitor INT(12) NOT NULL,
    justificativa VARCHAR(500) NOT NULL,
    CONSTRAINT JUSTIFICADO_PK PRIMARY KEY (idVoto)
)ENGINE=INNODB;