--
-- ﻿-- --------  << Eleicao >>  ----------
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Pedro Lucas Cassiano Martins
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: PedroMartins
--
-- Ultimas Alteracoes
--
-- PROJETO => 01 Base de Dados
--         => 11 Tabelas
-- ---------------------------------------------------------

USE PedroMartins;

INSERT INTO PESSOA (tituloELeitor) VALUES
	(000000000001),
    (000000000002),
    (000000000003),
    (000000000004),
    (000000000005),
    (000000000006),
    (000000000007);

INSERT INTO ELEITOR (tituloELeitor, nomeCompleto, dtNasc) VALUES
	(000000000001, "Jimin Jaimes Junior", "1998-05-12"),
    (000000000002, "Gustavo Ronaldo Silva", "1994-07-17"),
    (000000000003, "Iasmin Oliveira Souza", "2000-04-21"),
    (000000000004, "Jenifer Martins de Sousa", "1998-11-12");

INSERT INTO GOVERNADOR (numGovernador, tituloELeitor) VALUES
    (000000000005, 12),
    (000000000006, 17),
    (000000000007, 13);

INSERT INTO VOTO (idVoto, tituloELeitor, numGovernador, tipoVoto) VALUES
	(1, 000000000001, 12, 'R'),
    (2, 000000000002, 13, 'R'),
    (3, 000000000003, null , 'J'),
    (4, 000000000004, 17, 'R');

INSERT INTO REALIZADO (idVoto, tituloELeitor, numGovernador) VALUES
	(1, 000000000001, 12),
    (2, 000000000002, 13),
    (4, 000000000004, 17);

INSERT INTO JUSTIFICADO (idVoto, tituloEleitor, justificativa) VALUES
	(3, 000000000003, "ESTAVA COM COVID");
