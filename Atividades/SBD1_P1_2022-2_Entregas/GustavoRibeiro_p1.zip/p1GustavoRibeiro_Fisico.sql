-- ﻿-------  << GustavoRibeiro >>  --------
--
--  	SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Gustavo Martins Ribeiro
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: GustavoRibeiro
--
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--
-- ---------------------------------
CREATE DATABASE GustavoRibeiro;

USE GustavoRibeiro;

CREATE TABLE ELEITOR (
    titulo decimal(12),
    dataNasc date,
    nome varchar(100),
    CONSTRAINT ELEITOR_PK PRIMARY KEY (titulo)
)engine = InnoDB;

CREATE TABLE REGULAR (
    titulo decimal(12) ,
    justificativa varchar(200),
    eleicao date,
    CONSTRAINT REGULAR_titulo_UK UNIQUE KEY (titulo)
)engine = InnoDB;

CREATE TABLE PARTICIPANTE (
    titulo decimal(12),
    dataEleicao date,
    voto decimal(2),
    tituloCandidato decimal(12),
    CONSTRAINT PARTICIPANTE_titulo_UK UNIQUE KEY (titulo)
)engine = InnoDB;

CREATE TABLE CANDIDATO (
    titulo decimal(12),
    numeroCandidato decimal(2),
    dataEleicao date,
    CONSTRAINT CANDIDATO_PK PRIMARY KEY (titulo)
)engine = InnoDB;
 