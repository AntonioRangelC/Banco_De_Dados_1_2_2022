-- ﻿-------  << GustavoRibeiro >>  --------
--
--  	SCRIPT DE CRIACAO (DML)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Gustavo Martins Ribeiro
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: GustavoRibeiro
--
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--
-- ---------------------------------

USE GustavoRibeiro;

INSERT INTO ELEITOR(titulo,dataNasc,nome) VALUES (123456789111,'1990-07-02',"Gustavo Martins Ribeiro");
INSERT INTO ELEITOR(titulo,dataNasc,nome) VALUES (123456789112,'1995-03-02',"Rodrigo Alves Ribeiro");
INSERT INTO ELEITOR(titulo,dataNasc,nome) VALUES (123456799111,'1997-05-02',"Gustavo Martins Ribeiro");
INSERT INTO ELEITOR(titulo,dataNasc,nome) VALUES (123466689111,'1991-02-02',"Gustavo Martins Ribeiro");

INSERT INTO CANDIDATO(titulo,numeroCandidato,dataEleicao) VALUES (123456789332,12, "2020-08-12");
INSERT INTO CANDIDATO(titulo,numeroCandidato,dataEleicao) VALUES (123458889332,13, "2020-08-12");

INSERT INTO REGULAR(titulo,dataEleicao,voto,tituloCandidato) VALUES (123456789111,"2020-08-12",12,123456789332);
INSERT INTO REGULAR(titulo,dataEleicao,voto,tituloCandidato)  VALUES (
INSERT INTO REGULAR(titulo,dataEleicao,voto,tituloCandidato)  VALUES (

INSERT INTO PARTICIPANTE(titulo,dataNasc,nome) VALUES (123466689111,'1997-05-02',"Gustavo Martins Ribeiro");
INSERT INTO PARTICIPANTE(titulo,dataNasc,nome) VALUES (123466689111,'1997-05-02',"Gustavo Martins Ribeiro");