-- ----  Prova 1 SBD1 / Eleicao - VictorLeao  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Victor Hugo Oliveira Leão
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: VictorLeao
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--
-- ---------------------------------------------------------

CREATE DATABASE IF NOT EXISTS VictorLeao;

USE VictorLeao;

CREATE TABLE ELEITOR(
	tituloEleitor       BIGINT(12)  NOT NULL,
    nomeEleitor         VARCHAR(30) NOT NULL,
    dtNascimentoEleitor DATE        NOT NULL,
    CONSTRAINT ELEITOR_PK PRIMARY KEY(tituloEleitor)
) ENGINE=InnoDB;

CREATE TABLE VOTO(
	idVoto        INT            NOT NULL AUTO_INCREMENT,
    formaVoto     ENUM('P', 'R') NOT NULL,
    dataEleicao   DATE           NOT NULL,
    tituloEleitor BIGINT(12)     NOT NULL,
    CONSTRAINT VOTO_PK PRIMARY KEY(idVoto),
    CONSTRAINT VOTO_ELEITOR_FK FOREIGN KEY(tituloEleitor)
    REFERENCES ELEITOR (tituloEleitor)
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE REGULARIZANDO(
	idVoto        INT          NOT NULL,
    justificativa VARCHAR(200) NOT NULL,
    CONSTRAINT REGULARIZANDO_VOTO_FK FOREIGN KEY (idVoto)
    REFERENCES VOTO (idVoto)
) ENGINE=InnoDB;

CREATE TABLE CANDIDATO(
	idCandidato     INT        NOT NULL AUTO_INCREMENT,
    tituloCandidato BIGINT(12) NOT NULL,
    dataEleicao     DATE       NOT NULL,
    CONSTRAINT CANDIDATO_PK PRIMARY KEY(idCandidato)
) ENGINE=InnoDB AUTO_INCREMENT=10;

CREATE TABLE PARTICIPANDO(
	idVoto        INT NOT NULL,
    idCandidato   INT NOT NULL,
    CONSTRAINT PARTICIPANDO_VOTO_FK FOREIGN KEY (idVoto)
    REFERENCES VOTO (idVoto),
    CONSTRAINT PARTICIPANDO_CANDIDATO_FK FOREIGN KEY (idCandidato)
    REFERENCES CANDIDATO (idCandidato)
) ENGINE=InnoDB;