-- ----  Prova 1 SBD1 / Eleicao - VictorLeao  ----------
--
--                    SCRIPT DE POPULA (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Victor Hugo Oliveira Leão
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: VictorLeao
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--
-- ---------------------------------------------------------

USE VictorLeao;

INSERT INTO ELEITOR VALUES
(123456789123, 'Victor Leao', '2002-03-12'),
(567812349123, 'Gabriel Martins', '1999-02-10'),
(912356781234, 'Vinicius Vaz', '1989-10-10'),
(987654321123, 'Joao Camargo', '2001-12-12');

INSERT INTO VOTO(formaVoto, dataEleicao, tituloEleitor) VALUES
('P', '2020-08-08', 123456789123),
('P', '2020-08-08', 567812349123),
('R', '2020-08-08', 912356781234),
('R', '2020-08-08', 987654321123);

INSERT INTO REGULARIZANDO VALUES
(3, 'Viajando'),
(4, 'Em cárcere');

INSERT INTO CANDIDATO (tituloCandidato, dataEleicao) VALUES
(123491235678, '2020-08-08'),
(123567812349, '2020-08-08');

INSERT INTO PARTICIPANDO VALUES
(1, 10),
(2, 11);