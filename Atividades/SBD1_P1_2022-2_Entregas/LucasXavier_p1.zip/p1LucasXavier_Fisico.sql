/*
				<<LucasXavier>>
			SCRIPT DE CRIACAO (DDL)
            
Data Criacao ...........: 21/03/2018
Autor(es) ..............: Lucas Braun Vieira Xavier
Banco de Dados .........: MySQL 8.0
Base de Dados (nome) ...: LucasXavier

PROJETO=> 01 Base de Dados
		  05 Tabelas
*/

CREATE DATABASE IF NOT EXISTS LucasXavier;
USE LucasXavier;

CREATE TABLE ELEITOR (
    titulo decimal(12) not null,
    nascimento date not null,
    nome varchar(50) not null,
    constraint ELEITOR_PK PRIMARY KEY(titulo)
) ENGINE=InnoDB;

CREATE TABLE VOTO (
    idVoto int not null auto_increment,
    dataEleicao date not null,
    tituloEleitor decimal(12) not null,
    constraint VOTO_PK PRIMARY KEY(idVoto),
    constraint VOTO_ELEITOR_FK foreign key(tituloEleitor) references ELEITOR(titulo)
)ENGINE=InnoDB;

CREATE TABLE VOTOREGULARIZANDO (
    justificativa varchar(200) not null,
    idRegular int not null auto_increment,
    idVoto int not null,
    constraint VOTOREGULARIZANDO_PK PRIMARY KEY(idRegular),
    constraint VOTOREGULARIZANDO_VOTO_FK foreign key(idVoto) references VOTO(idVoto)
)ENGINE=InnoDB;

CREATE TABLE CANDIDATO (
    idCandidato decimal(2) not null,
    titulo decimal(12) not null,
    constraint CANDIDATO_PK PRIMARY KEY(idCandidato),
    constraint CANDIDATO_ELEITOR_FK foreign key(titulo) references ELEITOR(titulo)
)ENGINE=InnoDB;

CREATE TABLE VOTOPARTICIPANDO (
    idParticipa int not null auto_increment,
    idVoto int not null,
    idCandidato decimal(2) not null,
    constraint VOTOPARTICIPANDO_PK PRIMARY KEY(idParticipa),
    constraint VOTOPARTICIPANDO_VOTO_FK foreign key(idVoto) references VOTO(idVoto),
    constraint VOTOPARTICIPANDO_CANDIDATO_FK foreign key(idCandidato) references CANDIDATO(idCandidato)
)ENGINE=InnoDB;
