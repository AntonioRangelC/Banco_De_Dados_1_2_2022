/*
				<<LucasXavier>>
			SCRIPT DE POPULACAO
            
Data Criacao ...........: 21/03/2018
Autor(es) ..............: Lucas Braun Vieira Xavier
Banco de Dados .........: MySQL 8.0
Base de Dados (nome) ...: LucasXavier

PROJETO=> 01 Base de Dados
		  05 Tabelas
*/

USE LucasXavier;

INSERT INTO ELEITOR VALUES
	(123456789101, '2000-12-12', "João Lucas Alexandre"),
    (111314151698, '1995-02-02', "Ana França"),
    (568433122463, '1985-02-20', "Murilo Pedro");

INSERT INTO VOTO(dataEleicao, tituloEleitor) VALUES
	('2018-10-10', 123456789101),
    ('2022-10-10', 123456789101),
    ('2014-10-20', 111314151698),
    ('2018-10-20', 568433122463);

INSERT INTO VOTOREGULARIZANDO(idVoto, justificativa) VALUES
	(1, "Menor de idade."),
    (2, "Estava em viagem.");

INSERT INTO CANDIDATO VALUES
	(10, 111314151698),
    (21, 568433122463);

INSERT INTO VOTOPARTICIPANDO(idVoto, idCandidato) VALUES
	(3, 10),
    (4, 21);