/-- --------  << PROVA1>>  ---/------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Guilherme Nishimura da Silva
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: GUILHERMESILVA
--   PROJETO => 01 Base de Dados
--         => 12 tabelas 
--        
--     
--
-- ---------------------------------------------------------

CREATE TABLE PARTICIPANDO (
    justificativa VARCHAR(200) not null,
   idVoto BIGINT not null auto_increment,
 constraint VOTO_PK primary key (idvoto)
);

CREATE TABLE REGULARIZANDO (
    IdVoto BIGINT PRIMARY KEY,
    numeroCanditado int(2),
    constraint voto_canditado_fk  foreign key
    
);

CREATE TABLE CANDIDATO (
    numeroCanditado INT(2),
    dataeleicao DATE,
    tituloEleitor BIGINT(12),
    IdVoto BIGINT,
    PRIMARY KEY (numeroCanditado, tituloEleitor)
);

CREATE TABLE ELEITOR (
    tituloEleitor BIGINT(12) PRIMARY KEY,
    idade int(2),
    nome VARCHAR(20),
    dtNascimento DATE
);

CREATE TABLE ELEICAO (
    IdEleicao BIGINT PRIMARY KEY,
    estado VARCHAR(20),
    idVoto BIGINT,
    tituloEleitor BIGINT(12)
);

CREATE TABLE VOTO (
    dataeleicao DATE,
    IdVoto BIGINT PRIMARY KEY,
    tituloEleitor BIGINT(12)
);
 
ALTER TABLE PARTICIPANDO ADD CONSTRAINT FK_PARTICIPANDO_2
    FOREIGN KEY (dVoto)
    REFERENCES ??? (???);
 
ALTER TABLE REGULARIZANDO ADD CONSTRAINT FK_REGULARIZANDO_2
    FOREIGN KEY (IdVoto, numeroCanditado???)
    REFERENCES ??? (???);
 
ALTER TABLE CANDIDATO ADD CONSTRAINT FK_CANDIDATO_2
    FOREIGN KEY (tituloEleitor)
    REFERENCES ??? (???);
 
ALTER TABLE CANDIDATO ADD CONSTRAINT FK_CANDIDATO_3
    FOREIGN KEY (IdVoto)
    REFERENCES REGULARIZANDO (IdVoto)
    ON DELETE RESTRICT;
 
ALTER TABLE ELEICAO ADD CONSTRAINT FK_ELEICAO_2
    FOREIGN KEY (idVoto???, tituloEleitor???)
    REFERENCES ??? (???);
 
ALTER TABLE VOTO ADD CONSTRAINT FK_VOTO_2
    FOREIGN KEY (tituloEleitor???)
    REFERENCES ??? (???);