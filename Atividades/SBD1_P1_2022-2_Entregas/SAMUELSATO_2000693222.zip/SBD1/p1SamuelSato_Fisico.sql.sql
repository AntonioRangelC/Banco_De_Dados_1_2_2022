-- --------  << físico >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 01/08/2022
-- Autor(es) ..............: Samuel Alves Sato
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula6exer4Evolucao2
--

--
-- PROJETO => 1 Base de Dados
--         => 6 Tabelas
--
-- ---------------------------------------------------------

-- BASE DE DADOS

CREATE TABLE IF NOT EXISTS PROVA1;

USE PROVA1;

CREATE TABLE ELEICAO (
    idEleicao INT,
    dataEleicao DATE,
    CONSTRAINT ELEICAO_PK  PRIMARY KEY (idEleicao)
);

CREATE TABLE ELEITOR (
    idEleitor int,
    nomeCompleto VARCHAR(100),
    dtNasci DATE,
    tituloEleitor char(12),
    CONSTRAINT ELEITOR_PK  PRIMARY KEY (idEleitor)
);

CREATE TABLE CANDIDATO (
    numeroCandidato INT(2),
    tituloEleitor char(12),
    ELEICAO_idEleicao INT,
    CONSTRAINT CANDIDATO_PK  PRIMARY KEY (numeroCandidato),
    CONSTRAINT CANDIDATO_ELEICAO_FK FOREIGN KEY (ELEICAO_idEleicao) REFERENCES ELEICAO (idEleicao)
);

CREATE TABLE VOTO (
    tipo CHAR(1),
    idVoto INT,
    idEleicao INT,
    idEleitor int,
    CONSTRAINT VOTO_PK  PRIMARY KEY (idVoto, idEleicao),
    CONSTRAINT VOTO_ELEICAO_FK FOREIGN KEY (idEleicao) REFERENCES ELEICAO (idEleicao),
    CONSTRAINT VOTO_ELEITOR_FK FOREIGN KEY (idEleitor) REFERENCES ELEITOR (idEleitor)
);

CREATE TABLE REGULARIZADO (
    justificativa VARCHAR(200),
    idVoto INT PRIMARY KEY,
    CONSTRAINT REGULARIZADO_VOTO_FK FOREIGN KEY (idVoto) REFERENCES VOTO (idVoto)
);

CREATE TABLE PARTICIPANDO (
    idVoto INT PRIMARY KEY,
    numeroCandidato INT(2),
    CONSTRAINT PARTICIPANDO_VOTO_FK FOREIGN KEY (idVoto) REFERENCES VOTO (idVoto),
    CONSTRAINT PARTICIPANDO_CANDIDATO_FK FOREIGN KEY (numeroCandidato) REFERENCES CANDIDATO (numeroCandidato)
);
