--------  << Artur Nunes >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Artur Vinicius Dias Nunes
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: ArturNunes
--
-- PROJETO => 01 Base de Dados
--         => 4 Tabelas
--
-- ---------------------------------------------------------

CREATE DATABASE IF NOT EXISTS ArturNunes;
use ArturNunes;

CREATE TABLE ELEITOR (
    numeroTitulo decimal (12),
    nomeCompleto varchar (50),
    dtNascimento date,
    CONSTRAINT ELEITOR_PK PRIMARY KEY (numeroTitulo)
)ENGINE = InnoDB;

CREATE TABLE CANDIDATO (
    numeroCandidato int (2) auto_increment,
    dtEleicao date,
    numeroTitulo decimal (12),
    CONSTRAINT CANDIDATO_PK PRIMARY KEY (numeroCandidato, numeroTitulo)
)ENGINE = InnoDB auto_increment = 10;

CREATE TABLE PARTICIPANTE (
    codigoVoto int auto_increment,
    numeroCandidato int (2),
    numeroTitulo decimal (12),
    dtEleicao date,
    CONSTRAINT PARTICIPANTE_PK PRIMARY KEY (codigoVoto),
    CONSTRAINT PARTICIPANTE_ELEITOR_FK foreign key (numeroTitulo) REFERENCES ELEITOR (numeroTitulo),
    CONSTRAINT PARTICIPANTE_CANDIDATO_FK foreign key (numeroCandidato) REFERENCES CANDIDATO (numeroCandidato)
)ENGINE = InnoDB auto_increment = 1;

CREATE TABLE REGULARIZANTE (
    justificativa varchar (200),
    codigoVoto int auto_increment,
    numeroTitulo decimal (12),
    dtEleicao date,
    CONSTRAINT REGULARIZANTE_PK PRIMARY KEY (codigoVoto),
    CONSTRAINT REGULARIZANTE_ELEITOR_FK foreign key (numeroTitulo) REFERENCES ELEITOR (numeroTitulo)
)ENGINE = InnoDB auto_increment = 1;