-- ﻿-------  << revisaoP1 >>  --------
--
--  	SCRIPT DE POPULA (DML)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Mateus de Almeida Dias
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: mateusdias
--
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
--
-- ---------------------------------

-- BASE DE DADOS
USE mateusdias;

-- TABELAS
INSERT INTO ELEITOR (nomeCompleto, dtNasc, regulador, tituloEleitor) VALUES
	('Gabriel Marques','2000-10-23', 'P', 123456789101),
    ('Matheus Garcia', '1990-08-15', 'R', 123456789102);
    
INSERT INTO CANDIDATO (idCandidato, dtEleicao, tituloEleitor) VALUES
	('12','2009-10-23',  123456789101),
    ('13', '1999-08-15',  123456789102);


    