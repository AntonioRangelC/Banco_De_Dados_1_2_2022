-- --------  << eleicao prefeito >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Mateus de Almeida Dias
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: mateusdias
--
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
-- ---------------------------------------------------------

-- BASE DE DADOS
CREATE DATABASE
  IF NOT EXISTS mateusdias;

USE mateusdias;


-- TABELAS
CREATE TABLE ELEITOR (
    nomeCompleto 	VARCHAR(50) 	NOT NULL,
    dtNasc			DATE 			NOT NULL,
    regulador		ENUM('P','R') 	NOT NULL,
    tituloEleitor 	INT				NOT NULL,
    CONSTRAINT ELEITOR_PK PRIMARY KEY(tituloEleitor)
) ENGINE = InnoDB;

CREATE TABLE CANDIDATO (
    idCandidato 	INT 	NOT NULL,
    dtEleicao		DATE 	NOT NULL,
    tituloEleitor 	INT		NOT NULL,
    CONSTRAINT CANDIDATO_PK PRIMARY KEY(idCandidato),
	CONSTRAINT CANDIDATO_ELEITOR_FK FOREIGN KEY (tituloEleitor) REFERENCES ELEITOR (tituloEleitor)
) ENGINE = InnoDB;

CREATE TABLE PARTICIPANDO (
	dtEleicao		DATE 	NOT NULL,
    voto 			INT 	NOT NULL,
    tituloEleitor 	INT		NOT NULL,
    idCandidato 	INT 	NOT NULL,
    CONSTRAINT PARTICIPANDO_ELEITOR_FK FOREIGN KEY (tituloEleitor) REFERENCES ELEITOR (tituloEleitor),
	CONSTRAINT vota_CANDIDATO_FK FOREIGN KEY (idCandidato) REFERENCES CANDIDATO (idCandidato)
) ENGINE =  InnoDB AUTO_INCREMENT = 1;


CREATE TABLE REGULARIZANDO (
    eleicaoRegularizando 	VARCHAR(20) 	 NOT NULL,
    justificativa 			VARCHAR(200)	 NOT NULL,
    tituloEleitor 	INT		NOT NULL,
	CONSTRAINT REGULARIZANDO_ELEITOR_FK FOREIGN KEY (tituloEleitor) REFERENCES ELEITOR (tituloEleitor)
) ENGINE = InnoDB;


