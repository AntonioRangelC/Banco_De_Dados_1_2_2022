-- --------  << P1 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Eduardo Rodrigues de Farias
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: provav1
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--
-- ---------------------------------------------------------

CREATE DATABASE IF NOT EXISTS EduardoFarias;
USE EduardoFarias;

CREATE TABLE ELEITOR (
    tituloEleitor BIGINT(12) NOT NULL,
    dataNascimento DATE NOT NULL,
    nomeCompleto VARCHAR(100) NOT NULL,
    CONSTRAINT eleitor_pk PRIMARY KEY (tituloEleitor)
);

CREATE TABLE CANDIDATO (
    numero INT(2) NOT NULL,
    tituloEleitor BIGINT(12) NOT NULL,
    CONSTRAINT candidato_pk PRIMARY KEY (numero),
    CONSTRAINT candidato_eleitor_fk FOREIGN KEY (tituloEleitor) REFERENCES ELEITOR(tituloEleitor)
);

CREATE TABLE ELEICAO (
    dataEleicao DATE NOT NULL,
    CONSTRAINT eleicao_pk PRIMARY KEY (dataEleicao)
);

CREATE TABLE VOTO (
    justificativa VARCHAR(500),
    situacao ENUM("R", "J") NOT NULL,
    tituloEleitor BIGINT(12) NOT NULL,
    dataEleicao DATE NOT NULL,
    numeroCandidato INT(2),
    CONSTRAINT tituloEleitor_numeroCandidato_UK UNIQUE KEY (tituloEleitor, numeroCandidato),
    CONSTRAINT voto_eleitor_fk FOREIGN KEY (tituloEleitor) REFERENCES ELEITOR(tituloEleitor),
    CONSTRAINT voto_eleicao_fk FOREIGN KEY (dataEleicao) REFERENCES ELEICAO(dataEleicao),
    CONSTRAINT voto_candidato_fk FOREIGN KEY (numeroCandidato) REFERENCES CANDIDATO(numero)
);

CREATE TABLE participa (
    numeroCandidato INT(2) NOT NULL,
    dataEleicao DATE NOT NULL,
    CONSTRAINT participa_candidato_fk FOREIGN KEY (numeroCandidato) REFERENCES CANDIDATO(numero),
    CONSTRAINT participa_eleicao_fk FOREIGN KEY (dataEleicao) REFERENCES ELEICAO(dataEleicao)
);
