-- --------  << Prova 1 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: letícia Araújo
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: leticiaaraujo
--
-- Ultimas Alteracoes
--   09/08/2022 => Criação de banco de dados e tabelas.
--
-- PROJETO => 01 Base de Dados
--         => 5 Tabelas
-- ---------------------------------------------------------

create database leticiaaraujo;
use leticiaaraujo;

CREATE TABLE `leticiaaraujo`.`eleitor` (
  `tituloEleitor` INT ,
  `dataNascimento` DATETIME NOT NULL,
  `nomeCompleto` VARCHAR(45) NOT NULL,
  `idade` INT(10) NOT NULL,
  PRIMARY KEY (`tituloEleitor`))
ENGINE = InnoDB;

CREATE TABLE `leticiaaraujo`.`candidato` (
  `idcandidato` INT,
  `dataEleicao` DATE NULL,
  `idade` INT NULL,
  PRIMARY KEY (`idcandidato`))
ENGINE = InnoDB;

CREATE TABLE `leticiaaraujo`.`registro` (
  `idcandidato` INT,
  `tituloEleitor` INT,
  PRIMARY KEY (`idcandidato`,  `tituloEleitor`))
ENGINE = InnoDB;