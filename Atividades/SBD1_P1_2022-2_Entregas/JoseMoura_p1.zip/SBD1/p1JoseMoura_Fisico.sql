﻿-- --------  << P1 >>  ----------
--
--                    SCRIPT DE CRIACAO
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: José Guilherme Fernandes Moura
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: JoseMoura
--
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--
-- ---------------------------------------------------------

CREATE DATABASE
	IF NOT EXISTS JoseMoura;
    
USE JoseMoura;
    
CREATE TABLE ELEITOR(
	tituloDeEleitor INT NOT NULL PRIMARY KEY,
    nomeCompleto VARCHAR(100) NOT NULL,
    dataNascimento DATE NOT NULL,
    idade INT
) ENGINE = InnoDB, AUTO_INCREMENT = 1;

CREATE TABLE CANDIDATO(
	numeroCandidato INT(12) NOT NULL PRIMARY KEY,
	dataEleicao DATE NOT NULL,
    tituloDeEleitor INT(12) NOT NULL,
    CONSTRAINT CANDIDATO_ELEITOR_FK FOREIGN KEY(tituloDeEleitor) REFERENCES ELEITOR(tituloDeEleitor)
) ENGINE = InnoDB, AUTO_INCREMENT = 1;

CREATE TABLE VOTO(
	dataEleicao DATE NOT NULL,
    formaVOTO ENUM('P', 'R') NOT NULL,
    tituloDeEleitor INT(12) NOT NULL,
    CONSTRAINT VOTO_ELEITOR_FK FOREIGN KEY(tituloDeEleitor) REFERENCES ELEITOR(tituloDeEleitor)
);

CREATE TABLE REGULARIZANDO(
	justificativa VARCHAR(200),
    dataEleicao DATE NOT NULL,
    tituloDeEleitor INT(12) NOT NULL,
    CONSTRAINT REGULARIZADO_ELEITOR_FK FOREIGN KEY(tituloDeEleitor) REFERENCES ELEITOR(tituloDeEleitor)
);

CREATE TABLE PARTICIPANDO(
	numeroCandidato INT(2),
    dataEleicao DATE NOT NULL,
    tituloDeEleitor INT(12) NOT NULL,
    CONSTRAINT PARTICIPANDO_ELEITOR_FK FOREIGN KEY(tituloDeEleitor) REFERENCES ELEITOR(tituloDeEleitor)
);

