﻿-- --------  << LuizaSantos >>  ----------
--
--                    SCRIPT DE POPULAÇÃO (DML)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Luíza Esteves dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: LuizaSantos
--
--
-- PROJETO => 01 Base de Dados
--         => 11 Tabelas
--
-- ---------------------------------------------------------

use LuizaSantos;

INSERT INTO ELEITOR(titulo, nome, dtNasc) values
	(123456789019,'Maria Clara Ribeiro', '2000-10-09'),
    (876945678923,'José Alberto dos Santos Rodrigues', '2000-10-09');