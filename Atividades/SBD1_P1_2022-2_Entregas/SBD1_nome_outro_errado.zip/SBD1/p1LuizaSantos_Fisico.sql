﻿-- --------  << LuizaSantos >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Luíza Esteves dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: LuizaSantos
--
--
-- PROJETO => 01 Base de Dados
--         =>  Tabelas
--
-- ---------------------------------------------------------
create database if not exists LuizaSantos;
use LuizaSantos;

create table ELEITOR(
	titulo bigint not null,
    nome varchar(60) not null,
    dtNasc date not null,
    
    constraint ELEITOR_PK primary key(titulo)
);

