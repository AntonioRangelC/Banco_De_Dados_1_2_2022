﻿-- --------    ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Guilherme Brito Vilas Boas
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: guilhermeBoas
--
-- PROJETO => 01 Base de Dados
--         => 02 Tabelas
--
-- ---------------------------------------------------------

CREATE DATABASE IF NOT EXISTS guilhermeboas;

CREATE TABLE ELEITOR(
	tituloEleitor 	int(12)	not null,
    nomeCompleto	varchar(50) not null,
    dtNascimento	date	not null
) ENGINE = InnoDB;

CREATE TABLE CANDIDATO(
	tituloEleitor	int(12)	not null,
    CONSTRAINT FOREIGN KEY CANDIDATO_ELEITOR_FK(tituloEleitor) REFERENCES ELEITOR(tituloEleitor)
) ENGINE = InnoDB;




