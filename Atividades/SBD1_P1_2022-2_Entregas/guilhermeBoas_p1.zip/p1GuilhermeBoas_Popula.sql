﻿-- --------  << COLOCAR O NOME DE SEU PROJETO >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 
-- Autor(es) ..............: 
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: 
--
-- PROJETO => 01 Base de Dados
--         => 11 Tabelas
--
-- ---------------------------------------------------------


