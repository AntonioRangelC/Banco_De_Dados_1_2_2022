﻿/*
--------  ELEICAO  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Rodolfo Cabral Nevs
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: eleicao
--
--
--
-- --------------------------------------------------------- */

CREATE DATABASE IF NOT EXISTS eleicao;

USE eleicao;
CREATE TABLE IF NOT EXISTS ELEITOR  (
    tituloEleitor INT,
    nomeCompleto VARCHAR(100),
    dataNascimento DATE,
    candidato_eleitor_fk INT,
    candidato_pk INT,
    ELEITOR_TIPO INT,
    FK_VOTO_voto_pk INT,
    PRIMARY KEY (tituloEleitor, candidato_pk)
);

CREATE TABLE IF NOT EXISTS VOTO (
    voto_pk INT PRIMARY KEY,
    eleitor_eleicao_fk INT,
    dataEleicao DATE,
    situacao CHAR,
    voto_candidato_fk INT,
    participando_voto_fk INT,
    participando_tituloEleitor_fk INT,
    regularizar_voto_fk INT,
    regularizar_tituloEleitor_fk INT,
    justificativa VARCHAR(200),
    VOTO_TIPO INT
);
 
ALTER TABLE ELEITOR ADD CONSTRAINT FK_ELEITOR_2
    FOREIGN KEY (FK_VOTO_voto_pk)
    REFERENCES VOTO (voto_pk)
    ON DELETE RESTRICT;