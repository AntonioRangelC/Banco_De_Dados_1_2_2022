﻿-- --------  << Prova 1 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Cibele Freitas Goudinho
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: CibeleGoudinho
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
--
-- ---------------------------------------------------------

CREATE DATABASE
	IF NOT EXISTS CibeleGoudinho;
    
USE DATABASE CibeleGoudinho;

CREATE TABLE ELEITOR(
	tituloEleitor INT NOT NULL,
    nomeCompleto VARCHAR(50) NOT NULL,
    dtNasc DATE NOT NULL,
    dtEleicao DATE NOT NULL,
    CONSTRAINT ELEITOR_PK PRIMARY KEY (tituloEleitor),
)ENGINE= InnoDB;

CREATE TABLE CANDIDATO(
	tituloCandidato INT NOT NULL, 
	numeroCandidato INT NOT NULL,
    dtEleicao DATE NOT NULL,
    CONSTRAINT CANDIDATO_PK PRIMARY KEY (numeroCandidato),
)ENGINE = InnoDB;

CREATE TABLE VOTO(
	dtEleicao DATE NOT NULL,
    idVoto INT NOT NULL,
    tituloEleitor INT NOT NULL,
    CONSTRAINT VOTO_PK PRIMARY KEY (idVoto),
    CONSTRAINT VOTO_ELEITOR_FK FOREIGN KEY (tituloEleitor) REFERENCES ELEITOR(tituloEleitor),
)ENGINE = InnoDB;
    

CREATE TABLE REALIZADO(
	numeroCandidato INT NOT NULL,
    idVoto INT NOT NULL,
    CONSTRAINT REALIZADO_CANDIDATO_FK FOREIGN KEY (numeroCandidato) REFERENCES CANDIDATO(numeroCandidato),
    CONSTRAINT REALIZADO_VOTO_FK FOREIGN KEY (idVoto) REFERENCES VOTO(idVoto),
)ENGINE = InnoDB;

CREATE TABLE JUSTIFICADO(
	justificativa VARCHAR NOT NULL,
    idVoto INT NOT NULL,
    CONSTRAINT JUSTIFICADO_VOTO_FK FOREIGN KEY (idVoto) REFERENCES VOTO(idVoto),
)ENGINE = InnoDB;


