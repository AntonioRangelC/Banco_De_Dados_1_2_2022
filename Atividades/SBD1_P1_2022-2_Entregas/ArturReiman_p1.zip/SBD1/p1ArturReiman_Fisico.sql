-- --------  << ArturReiman_p1 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Artur Seppa Reiman
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: ArturReiman_p1
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
--
-- ---------------------------------------------------------
CREATE DATABASE IF NOT exists ArturReiman_p1;

USE  ArturReiman_p1;

CREATE TABLE PESSOA(
    tituloEleitor BIGINT NOT NULL,
    nome VARCHAR(40) NOT NULL,
    PRIMARY KEY PESSOA(tituloEleitor)
);

CREATE TABLE ELEITOR(
    dtNasc date NOT NULL,
    constraint ELEITOR_PESSOA_FK foreign key PESSOA(tituloEleitor) references PESSOA(tituloEleitor) 
);