-- ------------------- << p1MariaSantos >> ---------------
--
--       		SCRIPT DE CRIACAO
--
-- Data Criacao ..............: 09/08/2022
-- Autor(es) .................: Maria Eduarda Barbosa Santos
-- Banco de Dados ............: MySQL 8.0
-- Base de dados (nome) ......: mariasantos
--
-- Ultimas alteracoes
-- PROJETO => 01 Base de dados
-- 		   => 05 tabelas
--
-- ------------------------------------------
CREATE DATABASE 
	IF NOT EXISTS mariasantos;
    
USE mariasantos;
    
CREATE TABLE CANDIDATO (
    numCandidato BIGINT(2) NOT NULL,
    dtEleicao DATE NOT NULL,
    tituloEleitorCantidato BIGINT(12) NOT NULL,
    CONSTRAINT CANDIDATO_PK PRIMARY KEY(numCandidato)
) ENGINE = InnoDB;

CREATE TABLE ELEITOR (
    tituloEleitor BIGINT(12) NOT NULL,
    nome VARCHAR(100) NOT NULL,
    dtNascimento DATE NOT NULL,
    numCandidato BIGINT(2) NOT NULL,
    CONSTRAINT CANDIDATO_PK PRIMARY KEY(tituloEleitor),
    CONSTRAINT ELEITOR_CANDIDATO_FK FOREIGN KEY(numCandidato) REFERENCES CANDIDATO(numCandidato)
) ENGINE = InnoDB;

CREATE TABLE REGISTRO (
    tituloEleitor BIGINT(12) NOT NULL,
    dtEleicao DATE NOT NULL,
    tipoVoto ENUM('P', 'R') NOT NULL,
    numCandidato BIGINT(12) NOT NULL,
    CONSTRAINT REGISTRO_ELEITOR_FK FOREIGN KEY(tituloEleitor) REFERENCES ELEITOR(tituloEleitor),
	CONSTRAINT REGISTRO_CANDIDATO_FK FOREIGN KEY(numCandidato) REFERENCES CANDIDATO(numCandidato)
) ENGINE = InnoDB;

CREATE TABLE PARTICIPANDO (
    tituloEleitor BIGINT(12) NOT NULL,
    numCandidato BIGINT(2) NOT NULL,
    dtEleicao DATE NOT NULL,
    CONSTRAINT PARTICIPANDO_CANDIDATO_FK FOREIGN KEY(numCandidato) REFERENCES CANDIDATO(numCandidato),
    CONSTRAINT PARTICIPANDO_ELEITOR_FK FOREIGN KEY(tituloEleitor) REFERENCES ELEITOR(tituloEleitor),
    CONSTRAINT PARTICIPANDO_UK UNIQUE KEY(tituloEleitor)	
) ENGINE = InnoDB;

CREATE TABLE REGULARIZANDO (
    tituloEleitor BIGINT(12) NOT NULL,
    justificativa VARCHAR(200) NOT NULL,
    eleicao VARCHAR(80) NOT NULL,
    CONSTRAINT REGULARIZANDO_ELEITOR_FK FOREIGN KEY(tituloEleitor) REFERENCES ELEITOR(tituloEleitor),
    CONSTRAINT REGULARIZANDO_ELEITOR_UK UNIQUE KEY(tituloEleitor)
) ENGINE = InnoDB;
