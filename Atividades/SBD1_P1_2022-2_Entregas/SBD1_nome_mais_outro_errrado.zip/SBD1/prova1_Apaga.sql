-- --------     << Eleicao >>     ------------
-- 
--                    SCRIPT DE APAGAR (DDL)
-- 
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Mariana Rio
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: prova1_Apaga
-- 
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- -----------------------------------------------------------------

use prova1;

DROP TABLE IF EXISTS ELEITOR;
DROP TABLE IF EXISTS CANDIDATO;
DROP TABLE IF EXISTS VOTO;
DROP TABLE IF EXISTS HISTORICO;
DROP TABLE IF EXISTS gera;