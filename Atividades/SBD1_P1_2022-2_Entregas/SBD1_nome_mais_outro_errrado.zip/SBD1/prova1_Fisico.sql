-- ------------------     << Eleicao  >>     ------------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Mariana Oliveira Pires do Rio
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: prova1_Fisico
-- 
-- PROJETO => 01 Base de Dados
--         => 0 Tabelas
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS prova1_Fisico
DEFAULT CHARACTER SET utf8
DEFAULT COLLATE prova1_Fisico;

USE prova1;

CREATE TABLE IF NOT EXISTS ELEITOR (
    tituloEleitor INT(12) NOT NULL AUTO_INCREMENT,
    dataNasc DATE NOT NULL,
    nomeCompleto CHAR(30) NOT NULL,
    
    CONSTRAINT ELEITOR_PK PRIMARY KEY (tituloEleitor)
) ENGINE = InnoDB AUTO_INCREMENT = 1, DEFAULT CHARSET utf8 ;

CREATE TABLE IF NOT EXISTS CANDIDATO (
   numCadidato INT(2) NOT NULL AUTO_INCREMENT,
   dataEleicao DATE NOT NULL,

    CONSTRAINT CANDIDATO_PK PRIMARY KEY (numCadidato),
    
    CONSTRAINT HISTORICO_FK FOREIGN KEY (dataEleicao)
        REFERENCES HSTORICO (dataEleicao)
    
) ENGINE = InnoDB AUTO_INCREMENT = 1, DEFAULT CHARSET utf8 ;

CREATE TABLE IF NOT EXISTS VOTO (
    tipo CHAR(1) NOT NULL,
    justificativa CHAR(500) NOT NULL,
    tituloEleitor INT(12) NOT NULL,
    dataEleicao DATE NOT NULL,
    numCandidato INT(2) NOT NULL,

    CONSTRAINT ELEITOR_FK FOREIGN KEY (tituloEleitor)
        REFERENCES ELEITOR (tituloEleitor),
	CONSTRAINT HISTORICO_FK FOREIGN KEY (dataEleicao)
        REFERENCES HSTORICO (dataEleicao),
	CONSTRAINT CANDICATO_FK FOREIGN KEY (numCandidato)
        REFERENCES CANDIDATO (numCandidato)
) ENGINE = InnoDB, DEFAULT CHARSET utf8;

CREATE TABLE IF NOT EXISTS HISTORICO (
    dataEleicao DATE NOT NULL,
    resultado INT(2) NOT NULL,

    CONSTRAINT HISTORICO_PK PRIMARY KEY (dataEleicao)

) ENGINE = InnoDB, DEFAULT CHARSET utf8;


CREATE TABLE IF NOT EXISTS gera (
    dataEleicao DATE NOT NULL,
   
    CONSTRAINT gera_HISTORICO_PK FOREIGN KEY (dataEleicao)
        REFERENCES HISTORICO (dataEleicao)
) ENGINE = InnoDB, DEFAULT CHARSET utf8;