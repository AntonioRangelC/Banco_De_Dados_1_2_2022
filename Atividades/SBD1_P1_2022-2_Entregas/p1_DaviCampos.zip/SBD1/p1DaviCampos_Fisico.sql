-- ﻿-------  << P1 >>  --------
--
--  	SCRIPT FISICO
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Davi Marinho da Silva Campos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: davicampos
--
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--
-- ---------------------------------

-- BASE DE DADOS 

CREATE DATABASE
	IF NOT EXISTS davicampos;
    
    USE davicampos;

CREATE TABLE ELEITOR (
    tituloEleitor BIGINT,
    dataNascimento DATE,
    nome VARCHAR(100),
    CONSTRAINT ELEITOR_PK PRIMARY KEY (tituloEleitor),
    CONSTRAINT ELEITOR_UK UNIQUE KEY (tituloEleitor)
) ENGINE = InnoDB;

CREATE TABLE CANDIDATO (
    numCandidato VARCHAR(2),
    dataEleicao DATE,
    tituloEleitor BIGINT,
	CONSTRAINT CANDIDATO_PK PRIMARY KEY (numCandidato, tituloEleitor),
	CONSTRAINT ELEITOR_CANDIDATO_FK FOREIGN KEY (tituloEleitor)
	REFERENCES ELEITOR (tituloEleitor)
) ENGINE = InnoDB;

CREATE TABLE REGISTRO (
    registro VARCHAR(11),
    idRegistro BIGINT AUTO_INCREMENT,
    tituloEleitor BIGINT,
    CONSTRAINT REGISTRO_PK PRIMARY KEY (idRegistro)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE JUSTIFICADO (
    justificativa VARCHAR(500),
    idRegistro BIGINT,
    CONSTRAINT JUSTIFICADO_PK PRIMARY KEY (idRegistro),
    CONSTRAINT REGISTRO_JUSTIFICADO_FK FOREIGN KEY (idRegistro)
		REFERENCES REGISTRO (idRegistro)
) ENGINE = InnoDB;

CREATE TABLE REALIZADO (
    candidatoEscolhido VARCHAR(2),
    idRegistro BIGINT,
    CONSTRAINT REALIZADO_PK PRIMARY KEY (idRegistro),
    CONSTRAINT REGISTRO_REALIZADO_FK FOREIGN KEY (idRegistro)
		REFERENCES REGISTRO (idRegistro)
) ENGINE = InnoDB;

CREATE TABLE vota (
    tituloEleitor BIGINT,
    numCandidato VARCHAR(2),
	CONSTRAINT ELEITOR_vota_FK FOREIGN KEY (tituloEleitor)
		REFERENCES ELEITOR (tituloEleitor),
	CONSTRAINT CANDIDATO_vota_FK FOREIGN KEY (numCandidato)
		REFERENCES CANDIDATO (numCandidato)
) ENGINE = InnoDB;

CREATE TABLE gera (
    tituloEleitor BIGINT,
    idRegistro BIGINT,
    CONSTRAINT ELEITOR_gera_FK FOREIGN KEY (tituloEleitor)
		REFERENCES ELEITOR (tituloEleitor),
    CONSTRAINT REGISTRO_gera_FK FOREIGN KEY (idRegistro)
    		REFERENCES REGISTRO (idRegistro)
) ENGINE = InnoDB;