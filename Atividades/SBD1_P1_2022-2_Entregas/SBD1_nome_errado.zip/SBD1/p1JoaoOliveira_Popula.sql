/* p1JoaoOliveira_Logico: */

CREATE TABLE ELEITOR (
    tituloEleitor INT PRIMARY KEY,
    dataNascimento DATE,
    nomeCompleto VARCHAR,
    dataEleicao DATE
);

CREATE TABLE CANDIDATO (
    numeroCandidato INT 2,
    dataEleicao DATE,
    tituloEleitor INT,
    tituloEleitor INT,
    dataEleicao DATE,
    PRIMARY KEY (numeroCandidato, dataEleicao)
);

CREATE TABLE PARTICIPACAO (
    numeroCandidato INT,
    tituloEleitor INT,
    dataEleicao DATE,
    PRIMARY KEY (tituloEleitor, dataEleicao)
);

CREATE TABLE REGULARIZACAO (
    justificativa VARCHAR,
    tituloEleitor INT,
    dataEleicao DATE,
    PRIMARY KEY (tituloEleitor, dataEleicao)
);
 
ALTER TABLE CANDIDATO ADD CONSTRAINT FK_CANDIDATO_2
    FOREIGN KEY (tituloEleitor)
    REFERENCES ELEITOR (tituloEleitor)
    ON DELETE CASCADE;
 
ALTER TABLE CANDIDATO ADD CONSTRAINT FK_CANDIDATO_3
    FOREIGN KEY (tituloEleitor, dataEleicao)
    REFERENCES PARTICIPACAO (tituloEleitor, dataEleicao)
    ON DELETE RESTRICT;
 
ALTER TABLE PARTICIPACAO ADD CONSTRAINT FK_PARTICIPACAO_2
    FOREIGN KEY (tituloEleitor, dataEleicao)
    REFERENCES ??? (???);
 
ALTER TABLE REGULARIZACAO ADD CONSTRAINT FK_REGULARIZACAO_2
    FOREIGN KEY (tituloEleitor, dataEleicao)
    REFERENCES ??? (???);