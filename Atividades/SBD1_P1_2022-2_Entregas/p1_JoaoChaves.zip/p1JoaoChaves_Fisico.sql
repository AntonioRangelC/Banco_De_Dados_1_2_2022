﻿-- --------  << p1JoaoChaves >>  ----------
--
--             SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: João Pedro Alves da Silva Chaves
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: JoaoChaves
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--
-- -------------------------------------------------------

CREATE DATABASE IF NOT EXISTS JoaoChaves;

use JoaoChaves;

CREATE TABLE ELEITOR (
    tituloEleitor VARCHAR(12) NOT NULL,
    dtNasc DATE NOT NULL,
    nome VARCHAR(50) NOT NULL,
    CONSTRAINT ELEITOR_PK PRIMARY KEY (tituloEleitor)
) ENGINE = InnoDB;

CREATE TABLE VOTO (
    dtEleicao DATE NOT NULL,
    tipo ENUM('R', 'J') NOT NULL,
    idVoto INT NOT NULL auto_increment,
    tituloEleitor VARCHAR(12) NOT NULL,
	CONSTRAINT VOTO_ELEITOR_FK FOREIGN KEY (tituloEleitor) REFERENCES ELEITOR (tituloEleitor),
    CONSTRAINT VOTO_PK PRIMARY KEY (idVoto)
) ENGINE = InnoDB auto_increment = 1;

CREATE TABLE CANDIDATO (
    idCandidato DECIMAL(2),
    dtEleicao DATE NOT NULL,
    tituloEleitorCandidato VARCHAR(12) NOT NULL,
    CONSTRAINT CANDIDATO_PK PRIMARY KEY (idCandidato)
) ENGINE = InnoDB;

CREATE TABLE REALIZADO (
    idVoto INT NOT NULL,
    idCandidato DECIMAL(2),
    CONSTRAINT REALIZADO_CANDIDATO_FK FOREIGN KEY (idCandidato) REFERENCES CANDIDATO (idCandidato)
) ENGINE = InnoDB;

CREATE TABLE JUSTIFICADO (
    descricao VARCHAR(500) NOT NULL,
    idVoto INT NOT NULL
) ENGINE = InnoDB;
