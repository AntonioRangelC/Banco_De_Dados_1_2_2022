﻿-- --------  << alanSousa >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 21/03/2018
-- Autor(es) ..............: Alan Marques Sousa
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: alanSousa
--
-- Ultimas Alteracoes
--   28/04/2018 => Criação das tabelas do banco de dados
--
-- PROJETO => 01 Base de Dados
--         => 11 Tabelas
--
-- ---------------------------------------------------------

CREATE DATABASE IF NOT EXISTS alanSousa;

USE alanSousa;

CREATE TABLE ELEITOR (
    nomeCompleto varchar(100) not null,
    dataNasc date NOT NULL,
    tituloEleitor int(11) NOT NULL,
    CONSTRAINT ELEITOR_PK PRIMARY KEY (tituloEleitor)
);

CREATE TABLE ELEICAO (
    anoEleicao int(4),
    dataEleicao date,
    CONSTRAINT ELEITOR_PK PRIMARY KEY (anoEleicao, dataEleicao)
);

CREATE TABLE CANDIDATO (
    numeroCandidato int(2) not null,
    tituloEleitor int(11) not null,
    anoEleicao int(4) not null,
    dataEleicao date not null,
    CONSTRAINT ELEITOR_PK PRIMARY KEY (numeroCandidato),
    CONSTRAINT CANDIDATO_ELEICAO_FK FOREIGN KEY (FK_ELEICAO_anoEleicao, FK_ELEICAO_dataEleicao)
    REFERENCES ELEICAO (anoEleicao, dataEleicao)
);

CREATE TABLE VOTO (
    tituloEleitor int(11) not null,
    anoEleicao int(4) not null,
    dataEleicao date not null,
    CONSTRAINT VOTO PRIMARY KEY (tituloEleitor, anoEleicao, dataEleicao),
    CONSTRAINT VOTO_ELEICAO_FK FOREIGN KEY (anoEleicao, dataEleicao) REFERENCES ELEICAO (anoEleicao, dataEleicao),
    CONSTRAINT VOTO_ELEITOR_FK FOREIGN KEY (tituloEleitor) REFERENCES ELEITOR (tituloEleitor)
);

CREATE TABLE PARTICIPANDO (
    numeroCandidato int(2) not null,
    CONSTRAINT PARTICIPANDO_CANDIDATO FOREIGN KEY (numeroCandidato) REFERENCES CANDIDATO (numeroCandidato)
);