-- ---------------------     << Prova 01 >>     ---------------------
--
--                    SCRIPT DE POPULA (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Débora Caires de Souza Moreira
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: prova1
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--
-- -----------------------------------------------------------------

USE prova1;

INSERT INTO ELEITOR SET ('numeroTitulo', idade, 'dataNascimento', 'nomeCompleto') VALUES ('123546789123', 19, '31/03/1999', 'Debora Caires de Souza Moreira');

