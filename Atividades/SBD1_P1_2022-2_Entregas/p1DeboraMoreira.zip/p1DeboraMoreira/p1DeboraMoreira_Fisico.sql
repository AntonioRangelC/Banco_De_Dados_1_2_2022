-- ---------------------     << Prova 01 >>     ---------------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Débora Caires de Souza Moreira
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: prova1
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--
-- -----------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS prova1;
USE prova1;

CREATE TABLE ELEITOR (
    idEleitor INT NOT NULL AUTO_INCREMENT,
    numeroTitulo VARCHAR(12) UNIQUE NOT NULL,
    idade INT NOT NULL,
    dataNascimento DATE NOT NULL,
    nomeCompleto VARCHAR(120) NOT NULL,
    
    CONSTRAINT ELEITOR_PK PRIMARY KEY (idEleitor)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE CANDIDATO (
    idCandidato INT NOT NULL AUTO_INCREMENT,
    numeroCandidato INT UNIQUE NOT NULL,
    idEleitor INT NOT NULL,
    
    CONSTRAINT CANDIDATO_PK PRIMARY KEY (idCandidato),
    CONSTRAINT ser_ELEITOR_FK FOREIGN KEY (idEleitor) REFERENCES ELEITOR(idEleitor)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE VOTO (
    idVoto INT NOT NULL AUTO_INCREMENT,
    idEleitor INT NOT NULL,
    dataEleicao DATE NOT NULL,
    opcaoEfetuacao VARCHAR(10),
    
    CONSTRAINT VOTO_PK PRIMARY KEY (idVoto),
    CONSTRAINT registra_ELEITOR_FK FOREIGN KEY (idEleitor) REFERENCES ELEITOR(idEleitor)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE REGULARIZAR (
    idRegulariza INT NOT NULL AUTO_INCREMENT,
    idVoto INT NOT NULL,
    justificativa VARCHAR(10),
    
    CONSTRAINT REGULARIZAR_PK PRIMARY KEY (idRegulariza),
    CONSTRAINT justifica_ELEITOR_FK FOREIGN KEY (idVoto) REFERENCES VOTO(idVoto),
    CONSTRAINT relaciona_UK UNIQUE (idVoto , idRegulariza)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PARTICIPAR (
    idParticipa INT NOT NULL AUTO_INCREMENT,
    idVoto INT NOT NULL,
    numeroCandidato VARCHAR(10),
    
    CONSTRAINT PARTICIPAR_PK PRIMARY KEY (idParticipa),
    CONSTRAINT salva_ELEITOR_FK FOREIGN KEY (idVoto) REFERENCES VOTO(idVoto),
    CONSTRAINT possui_CANDIDATO_FK FOREIGN KEY (numeroCandidato) REFERENCES CANDIDATO(numeroCandidato),
    CONSTRAINT relaciona_UK UNIQUE (idVoto , idParticipa)
) ENGINE = InnoDB AUTO_INCREMENT = 1;


