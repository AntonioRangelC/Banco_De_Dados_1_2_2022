-- ---------------------     << Prova 01 >>     ---------------------
--
--                    SCRIPT DE APAGA (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Débora Caires de Souza Moreira
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: prova1
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--
-- -----------------------------------------------------------------
USE prova1;

DROP TABLE PARTICIPA;
DROP TABLE REGULARIZA;
DROP TABLE VOTO;
DROP TABLE CANDIDATO;
DROP TABLE ELEITOR;