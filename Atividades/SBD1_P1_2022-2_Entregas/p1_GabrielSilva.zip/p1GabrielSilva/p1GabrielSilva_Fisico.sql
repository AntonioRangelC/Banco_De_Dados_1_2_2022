-- ---------- << Prova 1 >> ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Gabriel Mariano da Silva
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: gabrielsilva
--
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--
-- ---------------------------------------------------------

-- BASE DE DADOS
CREATE database
	IF NOT EXISTS gabrielsilva;
    
USE gabrielsilva;

-- TABELAS
CREATE TABLE ELEITOR (
	tituloEleitor DECIMAL(12, 0) NOT NULL,
    dtNasc DATE NOT NULL,
    nome  varchar(50),
    constraint ELEITOR_PK primary key (tituloEleitor),
    constraint ELEITOR_dtNasc_nome_UK unique key (dtNasc, nome)
) ENGINE = InnoDB;

CREATE TABLE VOTO (
	tipoVoto ENUM('R', 'J') NOT NULL,
    dataEleicao	DATE NOT NULL,
    tituloEleitor DECIMAL(12, 0),
    idVoto INT auto_increment NOT NULL,
    constraint VOTO_PK primary key (idVoto),
    constraint VOTO_ELEITOR_FK foreign key (tituloEleitor) references ELEITOR (tituloEleitor),
    constraint VOTO_dataEleicao_tituloEleitor_UK unique key (dataEleicao, tituloEleitor)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

