﻿-- --------  << Prova 1 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Kevin Luis Apolinario Batis
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: kevinbatista
--
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
--
-- ---------------------------------------------------------

create database if not exists kevinbatista;
use kevinbatista;

create table ELEITOR(
    tituloEleitor BIGINT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(50) NOT NULL,
    dtNascimento DATE NOT NULL,
    
    CONSTRAINT ELEITOR_PK PRIMARY KEY (tituloEleitor)
) ENGINE = InnoDB auto_increment = 1;

create table ELEICAO(
	idEleicao INT NOT NULL,
    dtEleicao DATE NOT NULL UNIQUE,
    
    CONSTRAINT ELEICAO_PK PRIMARY KEY (idEleicao)
) ENGINE = InnoDB auto_increment = 1;

create table CANDIDATO (
    codigoCandidato INT NOT NULL,
    tituloEleitor BIGINT NOT NULL,
    
    CONSTRAINT CANDIDATO_PK PRIMARY KEY (codigoCandidato),
    CONSTRAINT CANDIDATO_PK FOREIGN KEY (tituloEleitor) REFERENCES ELEITOR (tituloEleitor)
) ENGINE = InnoDB;
 
create table VOTO (
    idVoto BIGINT NOT NULL AUTO_INCREMENT,
	tipoVoto ENUM('P','R') NOT NULL,
    tituloEleitor BIGINT NOT NULL,
    idEleicao INT NOT NULL,

    
    CONSTRAINT VOTO_PK PRIMARY KEY (idVoto),
    CONSTRAINT VOTO_ELEITOR_FK FOREIGN KEY (tituloEleitor) REFERENCES ELEITOR (tituloEleitor),
    CONSTRAINT VOTO_ELEICAO_FK FOREIGN KEY (idEleicao) REFERENCES ELEICAO (idEleicao)
) ENGINE = InnoDB auto_increment = 1;

create table REGULARIZA (
    idVoto BIGINT NOT NULL,
	justificativa VARCHAR(200) NOT NULL,

    CONSTRAINT REGULARIZA_VOTO_FK FOREIGN KEY (idVoto) REFERENCES VOTO (idVoto)
) ENGINE = InnoDB;

create table PARTICIPA (
    idVoto BIGINT NOT NULL,
	idCandidato BIGINT NOT NULL,

    CONSTRAINT PARTICIPA_VOTO_FK FOREIGN KEY (idVoto) REFERENCES VOTO (idVoto),
    CONSTRAINT PARTICIPA_CANDIDATO_FK FOREIGN KEY (codigoCandidato) REFERENCES CANDIDATO (codigoCandidato)
) ENGINE = InnoDB;
