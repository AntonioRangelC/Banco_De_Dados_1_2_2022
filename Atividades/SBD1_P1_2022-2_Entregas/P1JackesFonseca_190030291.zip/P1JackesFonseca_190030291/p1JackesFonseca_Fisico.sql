-- --------  << P1 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Jackes Tiago Ferreira da Fonseca
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: JackesFonseca

-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
-- ---------------------------------------------------------

CREATE DATABASE JackesFonseca;

USE JackesFonseca;

CREATE TABLE PESSOA (
	tituloEleitor INT NOT NULL,
    
    CONSTRAINT PESSOA_PK PRIMARY KEY(tituloEleitor)
)Engine = InnoDB;

CREATE TABLE ELEITOR (
	nomeCompleto VARCHAR(30) NOT NULL,
    dtNascimento DATE NOT NULL
)Engine = InnoDB;

CREATE TABLE CANDIDATO (
	numeroCandidato INT,
    dtEleicao DATE,

    CONSTRAINT CANDIDATO_UK UNIQUE KEY (numeroCandidato)
)Engine = InnoDB;

CREATE TABLE VOTO (
	idVoto INT NOT NULL,
    numeroCandidato INT NOT NULL,
    tituloEleitor INT NOT NULL,
    situacaoVoto ENUM('R', 'J'),
    
    CONSTRAINT VOTO_CANDIDATO_FK FOREIGN KEY VOTO(numeroCandidato) REFERENCES CANDIDATO(numeroCandidato),
	CONSTRAINT VOTO_ELEITOR_FK FOREIGN KEY VOTO(tituloEleitor) REFERENCES PESSOA(tituloEleitor)
)Engine = InnoDB;

CREATE TABLE ELEICAO (
	idEleicao INT NOT NULL,
	dtEleicao DATE NOT NULL,
	
    CONSTRAINT ELEICAO_PK PRIMARY KEY (idEleicao) 
)Engine = InnoDB;

CREATE TABLE possui (
	idVoto INT NOT NULL,
    idEleicao INT NOT NULL
)Engine = InnoDB;

