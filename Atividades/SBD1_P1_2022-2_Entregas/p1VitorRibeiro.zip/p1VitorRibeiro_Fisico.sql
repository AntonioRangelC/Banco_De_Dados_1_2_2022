﻿-- --------  << PROVA 1 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Vitor Ribeiro
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: vitorribeiro
--
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--    
-- ---------------------------------------------------------

CREATE DATABASE IF NOT EXISTS vitorribeiro;

USE vitorribeiro;

CREATE TABLE ELEITOR(
	tituloEleitor VARCHAR(12) NOT NULL PRIMARY KEY,
    dtNasc DATE NOT NULL,
    nome VARCHAR(500) NOT NULL
);

CREATE TABLE CANDIDATO(
	codigoCandidato INT NOT NULL PRIMARY KEY,
    tituloEleitor VARCHAR(12) NOT NULL,
    dtEleicao DATE NOT NULL
);

CREATE TABLE VOTO(
	idVoto INT NOT NULL PRIMARY KEY,
    tituloEleitor VARCHAR(12) NOT NULL,
    dtEleicao DATE NOT NULL
);