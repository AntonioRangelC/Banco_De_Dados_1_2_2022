﻿-- --------  << PROVA1 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Vinicius Assumpcao de Araujo
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: PROVA1
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
-- ---------------------------------------------------------


CREATE DATABASE IF NOT EXISTS PROVA1;

USE PROVA1;
CREATE TABLE ELEITOR(
	tituloEleitor DECIMAL(12) NOT NULL,
    dataNascimento DATE NOT NULL,
    nome VARCHAR(30)	NOT NULL,
    dataEleicaoAtual DATE NOT NULL,
    idCandidato INT(2) ,
    
    CONSTRAINT ELEITOR_PK primary key(tituloEleitor),
    CONSTRAINT ELEITOR_VOTO_FK foreign key(dataEleicaoAtual) REFERENCES VOTO(dataEleicaoAtual),
    CONSTRAINT ELEITOR_CANDIDATOPREFEITO_FK foreign key(idCandidato) REFERENCES CANDIDATOPREFEITO( idCandidato )
)ENGINE=InnoDB;

CREATE TABLE VOTO(
	dataEleicaoAtual DATE NOT NULL,
    tipoVoto	ENUM('P','R') NOT NULL,
    tituloEleitor DECIMAL(12) NOT NULL,

	 CONSTRAINT VOTO_PK primary key(dataEleicaoAtual),
	CONSTRAINT VOTO_ELEITOR_FK foreign key(tituloEleitor) REFERENCES ELEITOR(tituloEleitor)
     
)ENGINE=InnoDB;

CREATE TABLE VOTOPART(
	dataEleicaoAtual DATE NOT NULL,
	tituloEleitor DECIMAL(12) NOT NULL,
    idCandidato		INT(2) NOT NULL,
		CONSTRAINT VOTOPART_VOTO_FK foreign key(dataEleicaoAtual) REFERENCES VOTO(dataEleicaoAtual),
		CONSTRAINT VOTOPART_ELEITOR_FK foreign key(tituloEleitor) REFERENCES ELEITOR(tituloEleitor),
        CONSTRAINT VOTOPART_CANDIDATOPREFEITO_FK foreign key(idcandidato) REFERENCES CANDIDATO(idCandidato)

)ENGINE=InnoDB;

CREATE TABLE VOTOREG(
	dataEleicaoAtual DATE NOT NULL,
	justificativaNaoVota VARCHAR(200),
	tituloEleitor DECIMAL(12) NOT NULL,
    
    CONSTRAINT VOTOREG_ELEITOR_FK foreign key(tituloEleitor) REFERENCES ELEITOR(tituloEleitor),
    CONSTRAINT VOTOREG_VOTO_FK foreign key(dataEleicaoAtual) REFERENCES VOTO(dataEleicaoAtual)
)ENGINE=InnoDB;

CREATE TABLE CANDIDATOPREFEITO(
	idCandidato INT(2)	NOT NULL,
    
    CONSTRAINT  CANDIDATOPREFEITO_PK primary key(idCandidato)

);
