﻿-- --------  << PROVA1 >>  ----------
--
--                    SCRIPT DE POPULACAO (DML)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Vinicius Assumpcao de Araujo
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: PROVA1
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
-- ---------------------------------------------------------
USE PROVA1;

INSERT INTO ELEITOR VALUES
(123456789123,'2002-06-03','Wagner','2022-06-03'),
(123456787123,'2001-06-03','Kassabdra','2022-06-03');

INSERT INTO VOTO VALUES
('2022-06-03','P',123456789123),
('2022-06-03','R',123456787123);

INSERT INTO VOTOPART VALUES
('2022-06-03',123456789123),
('2022-06-03',123456787123);

INSERT INTO VOTOREG VALUES
('2022-06-03','titulo eleitoral invalido',123456789123),
('2022-06-03','titulo eleitoral invalido',123456787123);

INSERT INTO CANDIDATOPREFEITO VALUES
(11),
(15);