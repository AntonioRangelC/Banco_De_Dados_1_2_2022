-- --------  << aula4exer5Evolucao6Apaga >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 26/07/2022
-- Autor(es) ..............: Antonio Rangel Chaves
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao6Fisico
--
-- Ultimas alterações
-- 26/07/2022 => Criação do script
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
--
-- ---------------------------------------------------------

USE aula4exer5Evolucao6Fisico;
DROP TABLE telefone;
DROP TABLE contem;
DROP TABLE MEDICAMENTO;
DROP TABLE PRESCRICAO;
DROP TABLE CONSULTA;
DROP TABLE PACIENTE;
DROP TABLE possui;
DROP TABLE ESPECIALIDADE;
DROP TABLE MEDICO;

